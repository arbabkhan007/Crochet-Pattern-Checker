NOVALITY CROCHET PATTERN COLLECTION - BUNDLE
=============================================
Novality Store · Novality Crochet Studio · (c) 2026

WHAT'S INSIDE
  pdf/                 10 patterns x 2 editions (full-colour retail + greyscale print)
  html/                10 web-ready pattern pages + index.html catalog (self-contained,
                       mobile-friendly, print-friendly - images inlined)
  validated_sources/   the validated machine-readable source of every pattern
                       (the exact data the PDFs and HTML were generated from)
  VALIDATION_REPORT.md full findings log: every check run on every pattern

VALIDATION
  Every stitch count was verified with deterministic math (round-by-round
  production vs consumption, stated counts, and every size claim recomputed
  from the stated gauge). 419 rounds and 46 size claims checked. All 10
  patterns PASS. See VALIDATION_REPORT.md.

LICENSE (short form - full terms inside each pattern)
  (c) 2026 Novality Store. All rights reserved.
  YOU MAY: make finished items for yourself, gifts or charity, and sell them
  in small batches with credit to "Novality Store".
  YOU MAY NOT: resell, share, redistribute, translate, rewrite, publish or
  upload the patterns or their contents. No mass production without written
  permission.

SAFETY
  These patterns have not been tested to ASTM F963 / EN 71. Do not market
  finished toys as "baby-safe". Follow the safety box in each pattern
  (safety-eye ages, supervision notes, seam reinforcement).

Happy crocheting!  #NovalityStore
