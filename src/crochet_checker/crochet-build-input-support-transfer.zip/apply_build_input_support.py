#!/usr/bin/env python3
"""Install the external, checksum-verified build-input fetch flow.

This modifies working-tree files only. It never stages, commits, or pushes.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import subprocess
import sys
import tempfile
from pathlib import Path

EXPECTED_BRANCH = "multi-ai-consensus"
EXPECTED_HEAD = "49d69daeb8d7a2462d5e5bef5394a4ff5d170a3b"
PATCHED_NOTE_MARKER = "Source photos and font binaries are not tracked"

README_NOTE = """**Published binary note:** The linked PDFs, completed audio/video, and Etsy images are served from the immutable mirror commit `144397801c155fa7e11288bd14e27de134924c26` and checksummed in [external-media-manifest.json](external-media-manifest.json). Those generated binaries are intentionally omitted from `multi-ai-consensus`. Pattern data, listing metadata, and chapter-audio source inputs remain in the checkout; source photos and font binaries are also omitted, but the build tools fetch their verified inputs from pinned base commit `49d69daeb8d7a2462d5e5bef5394a4ff5d170a3b` into an external cache (`~/.cache/crochet-pattern-checker/49d69daeb8d7a2462d5e5bef5394a4ff5d170a3b` by default; override with `CROCHET_BUILD_CACHE`). `python build_all.py [slugs]` hydrates the Novality inputs and writes intermediates/outputs to that cache; the crochet-checker publish command hydrates its fonts there and writes PDFs to its cache by default (an explicit `--out` can override this). See [the build-input guide](../docs/BUILD_INPUTS.md) for manual fetch and offline details."""

COMMON_OLD = '''ROOT = Path(__file__).resolve().parent.parent          # novality_kits/
FONTS = ROOT / "assets" / "fonts"
IMG_ROOT = ROOT / "assets" / "img"
IMG_PDF_ROOT = ROOT / "assets" / "img_pdf"
OUT_ROOT = ROOT / "out"'''
COMMON_NEW = '''ROOT = Path(__file__).resolve().parent.parent          # novality_kits/
# Large source assets and generated outputs live outside the checkout.
CACHE_ROOT = Path(os.environ.get(
    "CROCHET_BUILD_CACHE",
    Path.home() / ".cache" / "crochet-pattern-checker" / "49d69daeb8d7a2462d5e5bef5394a4ff5d170a3b",
)).expanduser().resolve()
FONTS = CACHE_ROOT / "novality_kits" / "assets" / "fonts"
IMG_ROOT = CACHE_ROOT / "novality_kits" / "assets" / "img"
IMG_PDF_ROOT = CACHE_ROOT / "novality_kits" / "assets" / "img_pdf"
OUT_ROOT = CACHE_ROOT / "novality_kits" / "out"'''

BUILD_ALL_OLD = '''    slugs = [a for a in sys.argv[1:] if not a.startswith("--")] or SLUGS
    run("engine/verify.py", *slugs)'''
BUILD_ALL_NEW = '''    slugs = [a for a in sys.argv[1:] if not a.startswith("--")] or SLUGS
    run(str(HERE.parent / "tools" / "fetch_build_inputs.py"), "--group", "novality")
    run("engine/verify.py", *slugs)'''

PUBLISH_BUILD_OLD_MAIN = '''def main():
    ap = argparse.ArgumentParser(description="Build Novality Store pattern PDFs")
    ap.add_argument("--slug", default=None, help="build a single pattern")
    ap.add_argument("--out", default="final_patterns", help="output directory")
    args = ap.parse_args()
    root = Path(__file__).resolve().parents[3]
    out_dir = root / args.out
    paths = build_all(root, out_dir, slug=args.slug)
    for p in paths:
        print(f"built: {p}")'''
PUBLISH_BUILD_NEW_MAIN = '''def main():
    ap = argparse.ArgumentParser(description="Build Novality Store pattern PDFs")
    ap.add_argument("--slug", default=None, help="build a single pattern")
    ap.add_argument("--out", default=None, help="output directory (default: external build cache)")
    args = ap.parse_args()
    root = Path(__file__).resolve().parents[3]
    fetcher = root / "tools" / "fetch_build_inputs.py"
    subprocess.run([sys.executable, str(fetcher), "--group", "publish"], check=True, cwd=root)
    from .novality_pdf import build_all

    if args.out is None:
        cache_root = Path(os.environ.get(
            "CROCHET_BUILD_CACHE",
            Path.home() / ".cache" / "crochet-pattern-checker" / "49d69daeb8d7a2462d5e5bef5394a4ff5d170a3b",
        )).expanduser().resolve()
        out_dir = cache_root / "src" / "crochet_checker" / "publish" / "output"
    else:
        out_dir = Path(args.out)
        if not out_dir.is_absolute():
            out_dir = root / out_dir
    paths = build_all(root, out_dir, slug=args.slug)
    for p in paths:
        print(f"built: {p}")'''


def git(repo: Path, *args: str) -> str:
    result = subprocess.run(["git", *args], cwd=repo, text=True, capture_output=True)
    if result.returncode:
        raise RuntimeError(result.stderr.strip() or f"git {' '.join(args)} failed")
    return result.stdout.strip()


def replace_once(text: str, old: str, new: str, label: str, already: str) -> str:
    if already in text:
        return text
    count = text.count(old)
    if count != 1:
        raise RuntimeError(f"expected exactly one {label} anchor, found {count}; no files changed")
    return text.replace(old, new, 1)


def patch_readme(text: str) -> str:
    if PATCHED_NOTE_MARKER in text:
        return text
    start = text.find("**Published binary note:**")
    if start < 0:
        raise RuntimeError("README published-binary note not found; no files changed")
    end = text.find("\n\n## Corrections applied", start)
    if end < 0:
        raise RuntimeError("README section boundary not found; no files changed")
    return text[:start] + README_NOTE + text[end:]


def build_transforms(repo: Path) -> dict[Path, bytes]:
    results: dict[Path, bytes] = {}

    common = repo / "novality_kits" / "engine" / "common.py"
    text = common.read_text(encoding="utf-8")
    if "import os\n" not in text:
        text = replace_once(text, "import importlib\nimport re\n", "import importlib\nimport os\nimport re\n", "common.py os import", "import os\n")
    text = replace_once(text, COMMON_OLD, COMMON_NEW, "common.py asset-root block", "CACHE_ROOT = Path(os.environ.get(")
    results[common] = text.encode("utf-8")

    build_all = repo / "novality_kits" / "build_all.py"
    text = build_all.read_text(encoding="utf-8")
    text = replace_once(
        text, "HERE = Path(__file__).parent", "HERE = Path(__file__).resolve().parent",
        "build_all.py absolute script directory", "HERE = Path(__file__).resolve().parent",
    )
    text = replace_once(
        text, BUILD_ALL_OLD, BUILD_ALL_NEW, "build_all.py input-fetch hook",
        'run(str(HERE.parent / "tools" / "fetch_build_inputs.py")',
    )
    results[build_all] = text.encode("utf-8")

    novality_pdf = repo / "src" / "crochet_checker" / "publish" / "novality_pdf.py"
    text = novality_pdf.read_text(encoding="utf-8")
    if "import os\n" not in text:
        text = replace_once(text, "import textwrap\n", "import os\nimport textwrap\n", "novality_pdf.py os import", "import os\n")
    text = replace_once(
        text,
        'HERE = Path(__file__).parent\nFONTS = HERE / "fonts"',
        '''HERE = Path(__file__).parent
CACHE_ROOT = Path(os.environ.get(
    "CROCHET_BUILD_CACHE",
    Path.home() / ".cache" / "crochet-pattern-checker" / "49d69daeb8d7a2462d5e5bef5394a4ff5d170a3b",
)).expanduser().resolve()
FONTS = CACHE_ROOT / "src" / "crochet_checker" / "publish" / "fonts"''',
        "novality_pdf.py font-root block",
        'FONTS = CACHE_ROOT / "src" / "crochet_checker" / "publish" / "fonts"',
    )
    results[novality_pdf] = text.encode("utf-8")

    publish_build = repo / "src" / "crochet_checker" / "publish" / "build.py"
    text = publish_build.read_text(encoding="utf-8")
    publish_hook = 'subprocess.run([sys.executable, str(fetcher), "--group", "publish"], check=True, cwd=root)'
    if publish_hook not in text:
        text = replace_once(
            text,
            '"""Build all Novality Store pattern PDFs into final_patterns/.\n',
            '"""Build Novality Store PDFs into the external cache by default.\n',
            "publish build docstring",
            '"""Build Novality Store PDFs into the external cache by default.\n',
        )
        text = replace_once(text, "import argparse\n", "import argparse\nimport os\nimport subprocess\nimport sys\n", "publish build imports", "import os\n")
        eager_import = "\nfrom .novality_pdf import build_all\n"
        if text.count(eager_import) != 1:
            raise RuntimeError("expected one eager PDF-builder import; no files changed")
        text = text.replace(eager_import, "\n", 1)
        text = replace_once(text, PUBLISH_BUILD_OLD_MAIN, PUBLISH_BUILD_NEW_MAIN, "publish build main", publish_hook)
    results[publish_build] = text.encode("utf-8")

    updater = repo / "novality_kits" / "engine" / "update_readme.py"
    text = updater.read_text(encoding="utf-8")
    text = replace_once(
        text,
        "    relative = path.relative_to(ROOT).as_posix()",
        '    relative = f"out/{path.relative_to(Path(OUT_ROOT)).as_posix()}"',
        "update_readme.py cached output path",
        'relative = f"out/{path.relative_to(Path(OUT_ROOT)).as_posix()}"',
    )
    results[updater] = text.encode("utf-8")

    readme = repo / "novality_kits" / "README.md"
    results[readme] = patch_readme(readme.read_text(encoding="utf-8")).encode("utf-8")
    return results


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", required=True, type=Path, help="Codespaces checkout path")
    args = parser.parse_args()
    repo = args.repo.resolve()
    if not repo.is_dir():
        raise SystemExit(f"Repository directory not found: {repo}")

    branch = git(repo, "rev-parse", "--abbrev-ref", "HEAD")
    head = git(repo, "rev-parse", "HEAD")
    if branch != EXPECTED_BRANCH or head != EXPECTED_HEAD:
        raise SystemExit(f"Preflight failed: expected {EXPECTED_BRANCH} at {EXPECTED_HEAD}; found {branch} at {head}")
    staged = subprocess.run(["git", "diff", "--cached", "--quiet"], cwd=repo).returncode
    if staged != 0:
        raise SystemExit("Preflight failed: staged changes exist; unstage/review them before installing this support update")

    payload_root = Path(__file__).resolve().parent / "payload"
    new_paths = [
        payload_root / "tools" / "fetch_build_inputs.py",
        payload_root / "tools" / "build-inputs-manifest.json",
        payload_root / "docs" / "BUILD_INPUTS.md",
    ]
    new_files: dict[Path, bytes] = {}
    for source in new_paths:
        if not source.is_file():
            raise SystemExit(f"Transfer payload is incomplete: {source}")
        relative = source.relative_to(payload_root)
        target = repo / relative
        data = source.read_bytes()
        if target.exists() and hashlib.sha256(target.read_bytes()).digest() != hashlib.sha256(data).digest():
            raise SystemExit(f"Refusing to overwrite a different existing file: {target}")
        new_files[target] = data

    try:
        manifest = json.loads(new_files[repo / "tools" / "build-inputs-manifest.json"].decode("utf-8"))
        if len(manifest["files"]) != 57 or manifest["groups"]["novality"]["count"] != 49 or manifest["groups"]["publish"]["count"] != 8:
            raise ValueError("unexpected input counts")
    except Exception as exc:
        raise SystemExit(f"Invalid build-input manifest: {exc}") from exc

    changes = build_transforms(repo)
    for path, data in changes.items():
        if path.suffix == ".py":
            compile(data.decode("utf-8"), str(path), "exec")
    compile(new_files[repo / "tools" / "fetch_build_inputs.py"].decode("utf-8"),
            str(repo / "tools" / "fetch_build_inputs.py"), "exec")

    originals: dict[Path, bytes | None] = {}
    all_updates = {**changes, **new_files}
    for path in all_updates:
        originals[path] = path.read_bytes() if path.exists() else None
    try:
        for path, data in all_updates.items():
            path.parent.mkdir(parents=True, exist_ok=True)
            fd, temp_name = tempfile.mkstemp(prefix=f".{path.name}.", suffix=".tmp", dir=path.parent)
            with os.fdopen(fd, "wb") as stream:
                stream.write(data)
            os.replace(temp_name, path)
    except Exception:
        for path, original in originals.items():
            if original is None:
                try:
                    path.unlink()
                except FileNotFoundError:
                    pass
            else:
                path.write_bytes(original)
        raise

    print(f"Preflight OK: {repo}")
    print(f"Base: {branch} at {head}")
    print("Installed external input cache support: novality (49 files) and publish (8 files)")
    print("All fetched files go under CROCHET_BUILD_CACHE or ~/.cache; deleted repository paths stay absent.")
    print(f"Working-tree files updated: {len(changes)}; support files added: {len(new_files)}")
    print("No files staged; no commit or push performed.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
