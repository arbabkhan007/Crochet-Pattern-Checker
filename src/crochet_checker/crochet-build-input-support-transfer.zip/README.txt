Build-input support transfer

Purpose
Keep the reviewed media deletions, while retaining a working build workflow. This update does NOT restore the omitted files inside the Git checkout. It adds a checksum-verified fetcher that hydrates the required source images/fonts into an external cache, changes the builders to use that cache, and corrects the Novality README's claim that those inputs remain tracked.

Target
/workspaces/Crochet-Pattern-Checker
Branch: multi-ai-consensus
Expected HEAD: 49d69daeb8d7a2462d5e5bef5394a4ff5d170a3b

Install in Codespaces
1. Extract this ZIP into a temporary directory, for example /tmp/crochet-build-input-support.
2. Run:
   python3 /tmp/crochet-build-input-support/apply_build_input_support.py --repo /workspaces/Crochet-Pattern-Checker
3. The installer checks branch/HEAD, refuses staged changes or unexpected existing files, validates patch anchors, and changes working-tree files only. It never stages, commits, or pushes.
4. Review git status and the generated diff before staging.

The support update adds:
- tools/fetch_build_inputs.py
- tools/build-inputs-manifest.json
- docs/BUILD_INPUTS.md

It updates novality_kits/engine/common.py, novality_kits/build_all.py, novality_kits/engine/update_readme.py, src/crochet_checker/publish/novality_pdf.py, src/crochet_checker/publish/build.py, and the Novality README. Both builders write generated media outside the checkout by default. The 57 build inputs are pinned to exact SHA-256/byte sizes and the original base commit. The fetcher stores them outside the checkout at ~/.cache/crochet-pattern-checker/49d69daeb8d7a2462d5e5bef5394a4ff5d170a3b by default. Set CROCHET_BUILD_CACHE to another external path.

After installation, first run the non-destructive checks from the repository root:
   python3 tools/fetch_build_inputs.py --group novality --dry-run
   python3 tools/fetch_build_inputs.py --group publish --dry-run
   python3 -m py_compile tools/fetch_build_inputs.py novality_kits/engine/common.py novality_kits/build_all.py novality_kits/engine/update_readme.py src/crochet_checker/publish/novality_pdf.py src/crochet_checker/publish/build.py

A dry run only lists missing inputs. Do not run a full build until ready to download roughly 104 MB. The standard Novality and crochet-checker publish entry points automatically fetch only their relevant input groups when the build is invoked.
