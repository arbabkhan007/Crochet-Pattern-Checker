"""FastAPI web application for crochet pattern checker."""

from __future__ import annotations

from pathlib import Path

from fastapi import BackgroundTasks, FastAPI, File, HTTPException, Query, UploadFile
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from ..parser.parser import CrochetParser
from ..pdf import TEMPLATES, PDFConfig, PDFGenerator
from ..simulation import analyze_pattern_shape, simulate_surface
from ..simulation.assembly_map import assembly_map_svg, written_assembly
from ..simulation.geometry_map import geometry_map_svg, written_geometry
from ..simulation.stitch_sim import stitch_model_obj
from ..simulation.stitch_sim import simulate_stitches, stitch_map_svg
from .import_url import ImportError_, import_pattern_page
from ..validation import validate_pattern
from ..visualization import measure_pattern, render_2d_preview

app = FastAPI(title="Crochet Pattern Checker", version="0.5.0")

# Optional web companion ("studio"). Built from web/studio with `npm run build`.
# Mounted only when the bundle exists, so the API works with or without it.
# The Python engine in this module stays authoritative: the studio calls
# /api/check rather than reimplementing validation, and its own scoring is
# labelled in the UI as a browser-side pre-check.
_STUDIO_DIR = Path(__file__).resolve().parents[3] / "web" / "studio" / "dist"
if _STUDIO_DIR.is_dir():
    app.mount("/studio", StaticFiles(directory=str(_STUDIO_DIR), html=True), name="studio")


class CheckRequest(BaseModel):
    pattern_text: str


class ConsensusRunRequest(BaseModel):
    pattern_text: str = Field(min_length=1, max_length=100_000)


class DraftChangeRequest(BaseModel):
    from_text: str = Field(min_length=1, max_length=5_000)
    to_text: str = Field(max_length=5_000)
    reason: str = Field(min_length=1, max_length=2_000)


class ConsensusDraftRequest(BaseModel):
    changes: list[DraftChangeRequest] = Field(min_length=1, max_length=20)


@app.get("/", response_class=HTMLResponse)
async def index():
    return get_frontend_html()


@app.post("/api/check")
async def check_pattern(request: CheckRequest):
    try:
        pattern = CrochetParser().parse(request.pattern_text)
        report = validate_pattern(pattern)
        m = measure_pattern(pattern)
        return {
            "status": report.overall_status,
            "score": report.score,
            "errors": [
                {"message": e.message, "location": e.location} for e in report.errors
            ],
            "warnings": [
                {"message": w.message, "location": w.location} for w in report.warnings
            ],
            "rounds": m.total_rounds,
            "max_stitches": m.max_stitch_count,
            "max_diameter_inches": round(m.max_diameter_inches, 2),
            "total_height_inches": round(m.total_height_inches, 2),
        }
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e)) from e


class ImportUrlRequest(BaseModel):
    url: str


@app.post("/api/import/url")
async def import_url(request: ImportUrlRequest):
    """Fetch a public pattern page and return its text.

    This returns text only. Whether that text is a pattern, and whether its
    counts are consistent, is decided by /api/check - not here.
    """
    try:
        page = import_pattern_page(request.url)
    except ImportError_ as error:
        raise HTTPException(status_code=error.status, detail=str(error)) from error
    return {
        "url": page.url,
        "title": page.title,
        "text": page.text,
        "content_type": page.content_type,
        "truncated": page.truncated,
    }


@app.post("/api/upload")
async def upload_pattern(file: UploadFile = File(...)):
    try:
        text = (await file.read()).decode("utf-8")
    except Exception:
        raise HTTPException(status_code=400, detail="Could not read file") from None
    try:
        pattern = CrochetParser().parse(text)
        report = validate_pattern(pattern)
        m = measure_pattern(pattern)
        return {
            "status": report.overall_status,
            "score": report.score,
            "errors": [
                {"message": e.message, "location": e.location} for e in report.errors
            ],
            "warnings": [
                {"message": w.message, "location": w.location} for w in report.warnings
            ],
            "rounds": m.total_rounds,
            "max_stitches": m.max_stitch_count,
            "max_diameter_inches": round(m.max_diameter_inches, 2),
            "total_height_inches": round(m.total_height_inches, 2),
        }
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e)) from e



def _written_views(pattern):
    stitch_sim = simulate_stitches(pattern)
    assembly = written_assembly(pattern)
    geometry = written_geometry(pattern)
    return {
        "stitch_svg": stitch_map_svg(stitch_sim, "Stitch map"),
        "stitch_obj": stitch_model_obj(stitch_sim),
        "stitches": stitch_sim.stitch_count,
        "joins": stitch_sim.join_count,
        "assembly_svg": assembly_map_svg(assembly, "Assembly map"),
        "piece_joins": len(assembly.edges),
        "geometry_svg": geometry_map_svg(geometry, "Geometry map"),
        "geometry_note": geometry.notes[0],
        "note": stitch_sim.notes[0],
    }


@app.post("/api/render")
async def render_pattern(request: CheckRequest):
    try:
        pattern = CrochetParser().parse(request.pattern_text)
        report = validate_pattern(pattern)
        svg = render_2d_preview(pattern, report)
        views = _written_views(pattern)
        return {
            "svg": svg,
            "status": report.overall_status,
            **views,
        }
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e)) from e


@app.post("/api/simulate")
async def simulate_pattern(request: CheckRequest):
    try:
        pattern = CrochetParser().parse(request.pattern_text)
        analysis = analyze_pattern_shape(pattern)
        mesh = simulate_surface(pattern)
        views = _written_views(pattern)
        return {
            "shape": analysis.detected_shape.value,
            "confidence": round(analysis.confidence, 2),
            "vertices": len(mesh.vertices),
            "faces": len(mesh.faces),
            "assembly_note": "An assembly line is drawn only when two written pieces are named.",
            "status": "success",
            **views,
        }
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e)) from e


class PdfRequest(BaseModel):
    pattern_text: str
    designer: str | None = None
    template: str = "minimal"
    page_size: str = "A4"
    copyright_text: str = ""
    pattern_version: str = "1.0"
    include_cover: bool = True
    include_charts: bool = True
    include_validation: bool = True
    include_checklist: bool = True
    include_color_key: bool = True
    include_materials: bool = True
    include_abbreviations: bool = True
    include_measurements: bool = True
    large_print: bool = False
    ink_saver: bool = False
    landscape: bool = False
    binding: str = "none"
    compact: bool = False
    include_marks: bool = True
    include_change: bool = True
    include_index: bool = True
    include_ruled_notes: bool = True
    include_used_stitches: bool = True
    duplex: bool = False
    cards: bool = False
    crop_marks: bool = False
    include_ladder: bool = True
    include_parse: bool = True
    include_maker: bool = True
    include_map: bool = True


@app.post("/api/pdf")
async def generate_pdf(request: PdfRequest, designer: str | None = None):
    try:
        pattern = CrochetParser().parse(request.pattern_text)
        report = validate_pattern(pattern)
        page_size = request.page_size if request.page_size in {"A4", "Letter", "A5", "Legal"} else "A4"
        binding = request.binding if request.binding in {"none", "left"} else "none"
        template = request.template if request.template in TEMPLATES else "minimal"
        config = PDFConfig(
            designer_name=designer or request.designer or "",
            template=template,
            page_size=page_size,
            copyright_text=request.copyright_text,
            pattern_version=request.pattern_version,
            include_cover=request.include_cover,
            include_charts=request.include_charts,
            include_validation=request.include_validation,
            include_checklist=request.include_checklist,
            include_color_key=request.include_color_key,
            include_materials=request.include_materials,
            include_abbreviations=request.include_abbreviations,
            include_measurements=request.include_measurements,
            large_print=request.large_print,
            ink_saver=request.ink_saver,
            landscape=request.landscape,
            binding=binding,
            compact=request.compact,
            include_marks=request.include_marks,
            include_change=request.include_change,
            include_index=request.include_index,
            include_ruled_notes=request.include_ruled_notes,
            include_used_stitches=request.include_used_stitches,
            duplex=request.duplex,
            cards=request.cards,
            crop_marks=request.crop_marks,
            include_ladder=request.include_ladder,
            include_parse=request.include_parse,
            include_maker=request.include_maker,
            include_map=request.include_map,
        )
        html = PDFGenerator(config).generate(pattern, report)
        return {"html": html, "status": "success", "template": template, "page_size": page_size, "large_print": bool(request.large_print), "landscape": bool(request.landscape), "duplex": bool(request.duplex), "cards": bool(request.cards)}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e)) from e


@app.get("/api/health")
async def health():
    return {"status": "ok", "version": "0.5.0"}


def _consensus_service():
    """Lazily create the local history/provider service; credentials stay server-side."""
    service = getattr(app.state, "consensus_service", None)
    if service is None:
        from ..ai_providers.service import ConsensusService

        service = ConsensusService()
        app.state.consensus_service = service
    return service


@app.get("/consensus", response_class=HTMLResponse)
async def consensus_dashboard():
    """Small, dependency-free dashboard for provider runs and revision history."""
    return _consensus_dashboard_html()


@app.get("/api/consensus/providers")
async def consensus_provider_status():
    service = _consensus_service()
    settings = service.settings
    return {
        "status": service.catalog.public_status(),
        "settings": {
            "min_participating_models": settings.min_participating_models,
            "min_participation_ratio": settings.min_participation_ratio,
            "consensus_threshold": settings.consensus_threshold,
            "cross_examination_enabled": settings.enable_cross_examination,
            "adversarial_review_enabled": settings.enable_adversarial_review,
            "strict_required_participation": settings.strict_required_participation,
            "max_revisions": settings.max_revisions,
            "required_roles": list(settings.required_roles),
        },
        "security_note": "Local configuration status only; no live model availability is probed. Credentials are never returned.",
    }


@app.post("/api/consensus/runs", status_code=202)
async def create_consensus_run(request: ConsensusRunRequest, background_tasks: BackgroundTasks):
    if not request.pattern_text.strip():
        raise HTTPException(status_code=422, detail="pattern_text must contain non-whitespace text")
    service = _consensus_service()
    run_id = service.create_run(request.pattern_text)
    background_tasks.add_task(service.execute, run_id)
    record = service.store.get_run(run_id) or {}
    return {"run_id": run_id, "status": "queued", "pattern_hash": record.get("pattern_hash"), "progress": record.get("progress"), "status_url": f"/api/consensus/runs/{run_id}"}


@app.post("/api/consensus/check")
async def run_consensus_now(request: ConsensusRunRequest):
    if not request.pattern_text.strip():
        raise HTTPException(status_code=422, detail="pattern_text must contain non-whitespace text")
    return await _consensus_service().run_now(request.pattern_text)


@app.get("/api/consensus/runs")
async def list_consensus_runs(limit: int = Query(default=50, ge=1, le=200)):
    service = _consensus_service()
    return {"runs": service.store.list_runs(limit), "limit": limit}


@app.get("/api/consensus/runs/{run_id}")
async def get_consensus_run(run_id: str):
    run = _consensus_service().store.get_run(run_id)
    if run is None:
        raise HTTPException(status_code=404, detail="Consensus run not found")
    return run


@app.post("/api/consensus/runs/{run_id}/drafts", status_code=202)
async def create_consensus_draft(run_id: str, request: ConsensusDraftRequest, background_tasks: BackgroundTasks):
    service = _consensus_service()
    try:
        child_id, metadata = service.create_revision(run_id, [item.model_dump() for item in request.changes])
    except KeyError as error:
        raise HTTPException(status_code=404, detail="Parent consensus run not found") from error
    except ValueError as error:
        raise HTTPException(status_code=409, detail=str(error)) from error
    background_tasks.add_task(service.execute, child_id)
    return {"draft": metadata, "status_url": f"/api/consensus/runs/{child_id}"}


def _consensus_dashboard_html() -> str:
    from .consensus_dashboard import dashboard_html

    return dashboard_html()


def get_frontend_html() -> str:
    return """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Crochet Pattern Checker</title>
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;background:linear-gradient(135deg,#667eea 0%,#764ba2 100%);min-height:100vh;padding:20px}
.container{max-width:1200px;margin:0 auto}
header{text-align:center;color:white;padding:40px 0}
header h1{font-size:2.5em;margin-bottom:10px}
header p{font-size:1.2em;opacity:.9}
.main-grid{display:grid;grid-template-columns:1fr 1fr;gap:20px;margin-top:20px}
.panel{background:white;border-radius:12px;padding:25px;box-shadow:0 10px 40px rgba(0,0,0,.2)}
.panel h2{color:#333;margin-bottom:15px;font-size:1.3em}
textarea{width:100%;height:300px;border:2px solid #e0e0e0;border-radius:8px;padding:15px;font-family:monospace;font-size:14px;resize:vertical}
textarea:focus{outline:none;border-color:#667eea}
.btn{background:linear-gradient(135deg,#667eea 0%,#764ba2 100%);color:white;border:none;padding:12px 30px;border-radius:8px;font-size:16px;cursor:pointer;margin:10px 5px 10px 0}
.btn:hover{opacity:.9}
.result-box{margin-top:20px;padding:20px;border-radius:8px;background:#f8f9fa}
.status-pass{background:#d4edda;color:#155724;border:1px solid #c3e6cb}
.status-warn{background:#fff3cd;color:#856404;border:1px solid #ffeaa7}
.status-error{background:#f8d7da;color:#721c24;border:1px solid #f5c6cb}
.status-badge{display:inline-block;padding:5px 15px;border-radius:20px;font-weight:bold;font-size:14px}
.score{font-size:48px;font-weight:bold;text-align:center;margin:20px 0}
.stats{display:grid;grid-template-columns:repeat(2,1fr);gap:10px;margin-top:15px}
.stat-card{background:white;padding:15px;border-radius:8px;text-align:center}
.stat-value{font-size:24px;font-weight:bold;color:#667eea}
.stat-label{font-size:12px;color:#666;margin-top:5px}
.errors-list{margin-top:15px;padding:15px;border-radius:8px;background:#f8d7da}
.warnings-list{margin-top:15px;padding:15px;border-radius:8px;background:#fff3cd}
.errors-list li{color:#721c24;margin:5px 0}
.warnings-list li{color:#856404;margin:5px 0}
.svg-container{margin-top:20px;background:white;padding:20px;border-radius:8px;text-align:center}
.svg-container svg{max-width:100%;height:auto}
.upload-zone{border:2px dashed #ccc;border-radius:8px;padding:30px;text-align:center;cursor:pointer;margin-bottom:15px}
.upload-zone:hover,.upload-zone.dragover{border-color:#667eea;background:#f0f4ff}
footer{text-align:center;color:white;padding:40px 0 20px;opacity:.8}
</style>
</head>
<body>
<div class="container">
<header><h1>\xf0\x9f\xa7\xb6 Crochet Pattern Checker</h1><p>Validate, visualize, and publish your crochet patterns | <a href="/consensus" style="color:white;text-decoration:underline">Multi-AI written review dashboard</a></p></header>
<div class="main-grid">
<div class="panel"><h2>\xf0\x9f\x93\x9d Enter Your Pattern</h2>
<div class="upload-zone" id="dropZone"><p>\xf0\x9f\x93\x81 Drop a .txt file here or click to upload</p><input type="file" id="fileInput" accept=".txt" style="display:none"></div>
<textarea id="patternInput" placeholder="Round 1: 6 sc into magic ring (6)\nRound 2: inc x 6 (12)\nRound 3: (sc, inc) x 6 (18)\nRound 4: (2 sc, inc) x 6 (24)..."></textarea>
<button class="btn" onclick="checkPattern()">Check Pattern</button>
<button class="btn" onclick="renderPattern()">Render</button>
<button class="btn" onclick="simulatePattern()">3D Simulate</button> <label><input id="pdfLarge" type="checkbox"> Large print</label> <label><input id="pdfInk" type="checkbox"> Ink saver</label> <label><input id="pdfLand" type="checkbox"> Landscape</label> <label><input id="pdfBind" type="checkbox"> Binding</label> <label><input id="pdfDuplex" type="checkbox"> Duplex</label> <label><input id="pdfCards" type="checkbox"> Round cards</label> <label><input id="pdfCrop" type="checkbox"> Crop marks</label> <label>Page <select id="pdfPage"><option>A4</option><option>Letter</option><option>A5</option><option>Legal</option></select></label> <button class="btn" onclick="makePdf()">Make PDF sheet</button>
</div>
<div class="panel"><h2>\xf0\x9f\x93\x8a Results</h2><div id="results"><p style="color:#999;text-align:center;padding:50px 0">Enter a pattern and click "Check Pattern" to see results</p></div></div>
</div>
<div class="panel" style="margin-top:20px" id="diagramPanel" hidden><h2>Pattern Diagram</h2><div class="svg-container" id="svgContainer"></div></div>
<footer><p>Crochet Pattern Checker v0.5.0 | Built with FastAPI</p></footer>
</div>
<script>
const dropZone=document.getElementById('dropZone'),fileInput=document.getElementById('fileInput'),patternInput=document.getElementById('patternInput');
dropZone.addEventListener('click',()=>fileInput.click());
dropZone.addEventListener('dragover',e=>{e.preventDefault();dropZone.classList.add('dragover')});
dropZone.addEventListener('dragleave',()=>dropZone.classList.remove('dragover'));
dropZone.addEventListener('drop',e=>{e.preventDefault();dropZone.classList.remove('dragover');if(e.dataTransfer.files[0])readFile(e.dataTransfer.files[0])});
fileInput.addEventListener('change',e=>{if(e.target.files[0])readFile(e.target.files[0])});
function readFile(f){const r=new FileReader();r.onload=e=>patternInput.value=e.target.result;r.readAsText(f)}
async function checkPattern(){const t=patternInput.value;if(!t.trim())return alert('Enter a pattern');const res=document.getElementById('results');res.innerHTML='<p style="text-align:center;padding:20px">Checking...</p>';try{const r=await fetch('/api/check',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({pattern_text:t})});const d=await r.json();if(!r.ok){res.innerHTML='<div class="result-box status-error"><b>Error:</b> '+d.detail+'</div>';return}const c=d.status.includes('PASS')&&!d.status.includes('WARNING')?'status-pass':d.status.includes('WARNING')?'status-warn':'status-error';let h='<div class="result-box '+c+'"><div style="text-align:center"><span class="status-badge">'+d.status+'</span><div class="score">'+d.score+'/100</div></div><div class="stats"><div class="stat-card"><div class="stat-value">'+d.rounds+'</div><div class="stat-label">Rounds</div></div><div class="stat-card"><div class="stat-value">'+d.max_stitches+'</div><div class="stat-label">Max Stitches</div></div><div class="stat-card"><div class="stat-value">'+d.max_diameter_inches+'"\'</div><div class="stat-label">Estimate, not measured</div></div><div class="stat-card"><div class="stat-value">'+d.total_height_inches+'"\'</div><div class="stat-label">Estimate, not measured</div></div></div></div>';if(d.errors&&d.errors.length>0){h+='<div class="errors-list"><b>Errors:</b><ul>';d.errors.forEach(e=>h+='<li>['+e.location+'] '+e.message+'</li>');h+='</ul></div>'}if(d.warnings&&d.warnings.length>0){h+='<div class="warnings-list"><b>Warnings:</b><ul>';d.warnings.forEach(w=>h+='<li>['+w.location+'] '+w.message+'</li>');h+='</ul></div>'}res.innerHTML=h}catch(e){res.innerHTML='<div class="result-box status-error"><b>Error:</b> '+e.message+'</div>'}}
async function renderPattern(){const t=patternInput.value;if(!t.trim())return alert('Enter a pattern');const p=document.getElementById('diagramPanel'),c=document.getElementById('svgContainer');p.hidden=false;c.innerHTML='<p style="text-align:center;padding:20px">Generating...</p>';try{const r=await fetch('/api/render',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({pattern_text:t})});const d=await r.json();c.innerHTML=d.svg+(d.stitch_svg?'<p style="font-size:12px;color:#5c6b7a">Stitch map: '+d.stitches+' written stitches. Not a measured size.</p>\'+d.stitch_svg:'')+(d.assembly_svg?'<p style="font-size:12px;color:#5c6b7a">Assembly map: '+(d.piece_joins||0)+' written piece joins. Not a stitch map.</p>'+d.assembly_svg:'')+(d.geometry_svg?'<p style="font-size:12px;color:#5c6b7a">Geometry map. '+(d.geometry_note||'Not a millimetre measurement.')+'</p>'+d.geometry_svg:'')}catch(e){c.innerHTML='<p style="color:red">Error: '+e.message+'</p>'}}
async function simulatePattern(){const t=patternInput.value;if(!t.trim())return alert('Enter a pattern');const res=document.getElementById('results');res.innerHTML='<p style="text-align:center;padding:20px">Simulating...</p>';try{const r=await fetch('/api/simulate',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({pattern_text:t})});const d=await r.json();if(!r.ok){res.innerHTML='<div class="result-box status-error"><b>Error:</b> '+d.detail+'</div>';return}res.innerHTML='<div class="result-box status-pass"><h3 style="text-align:center;margin-bottom:15px">3D Simulation</h3><div class="stats"><div class="stat-card"><div class="stat-value">'+d.shape+'</div><div class="stat-label">Detected Shape</div></div><div class="stat-card"><div class="stat-value">'+(d.confidence*100).toFixed(0)+'%</div><div class="stat-label">Confidence</div></div><div class="stat-card"><div class="stat-value">'+d.vertices+'</div><div class="stat-label">Vertices</div></div><div class="stat-card"><div class="stat-value">'+d.faces+'</div><div class="stat-label">Faces</div></div></div><div class="stat-card"><div class="stat-value">'+(d.piece_joins||0)+'</div><div class="stat-label">Written piece joins</div></div><div class="stat-card"><div class="stat-value">'+(d.stitches||0)+'</div><div class="stat-label">Written stitches</div></div></div><p style="font-size:12px;color:#5c6b7a">'+(d.note||'Not a measured size. Not a photo.')+'</p><p style="font-size:12px;color:#5c6b7a">'+(d.assembly_note||'Not a stitch map.')+'</p></div>';if(d.assembly_svg){const p=document.getElementById('diagramPanel'),c=document.getElementById('svgContainer');p.hidden=false;c.innerHTML='<p style="font-size:12px;color:#5c6b7a">Assembly map: '+(d.piece_joins||0)+' written piece joins. Not a stitch map.</p>'+d.assembly_svg+(d.geometry_svg?'<p style="font-size:12px;color:#5c6b7a">Geometry map. '+(d.geometry_note||'Not a millimetre measurement.')+'</p>'+d.geometry_svg:'')}}catch(e){res.innerHTML='<div class="result-box status-error"><b>Error:</b> '+e.message+'</div>'}}

async function makePdf(){const t=patternInput.value;if(!t.trim())return alert('Enter a pattern');const res=document.getElementById('results');res.innerHTML='<p style="text-align:center;padding:20px">Making sheet...</p>';try{const r=await fetch('/api/pdf',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({pattern_text:t,template:'craft',page_size:(document.getElementById('pdfPage')||{}).value||'A4',large_print:!!(document.getElementById('pdfLarge')&&document.getElementById('pdfLarge').checked),ink_saver:!!(document.getElementById('pdfInk')&&document.getElementById('pdfInk').checked),landscape:!!(document.getElementById('pdfLand')&&document.getElementById('pdfLand').checked),binding:(document.getElementById('pdfBind')&&document.getElementById('pdfBind').checked)?'left':'none',duplex:!!(document.getElementById('pdfDuplex')&&document.getElementById('pdfDuplex').checked),cards:!!(document.getElementById('pdfCards')&&document.getElementById('pdfCards').checked),crop_marks:!!(document.getElementById('pdfCrop')&&document.getElementById('pdfCrop').checked)})});const d=await r.json();if(!r.ok){res.innerHTML='<div class="result-box status-error"><b>Error:</b> '+d.detail+'</div>';return}const blob=new Blob([d.html],{type:'text/html'});const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='pattern-sheet.html';a.click();res.innerHTML='<div class="result-box status-pass"><b>Sheet ready.</b> The download is HTML. Open it and print. Template: '+d.template+'.</div>'}catch(e){res.innerHTML='<div class="result-box status-error"><b>Error:</b> '+e.message+'</div>'}}
</script>
</body>
</html>"""
