"""Deterministic stages the text checker can prove.

These stages read written pattern text. They do not call a vision model,
a hosted language model, or a cluster. A photo is never assigned a stitch
count here.
"""

from __future__ import annotations

import re

from .batch import batch_findings, batch_names
from .span import COUNTS_AS, HOOK_GAP, HOOKS, TURN_MIN, span_findings, span_names
from dataclasses import dataclass, field


# Craft Yarn Council crochet single-crochet ranges per 4 inches.
# Source: https://www.craftyarncouncil.com/standards/yarn-weight-system
# A tight amigurumi gauge is common, so only a count outside half to
# double that published band warns. Lace is not banded: the Council says
# a lace range is hard to determine.
_WEIGHTS = (
    ("super bulky", (7, 9)),
    ("super fine", (21, 32)),
    ("light worsted", (12, 17)),
    ("fingering", (21, 32)),
    ("sport", (16, 20)),
    ("worsted", (11, 14)),
    ("chunky", (8, 11)),
    ("bulky", (8, 11)),
    ("jumbo", (1, 6)),
    ("sock", (21, 32)),
    ("aran", (11, 14)),
    ("dk", (12, 17)),
)
_NO_BAND = ("lace", "thread", "cobweb")

_HEADER = re.compile(
    r"^(Row|Rnd|Round|R)s?\.?\s*(\d+)(?:\s*[-–—]\s*\d+)?\s*[:.]?\s*(.*)$",
    re.IGNORECASE,
)
_STATED = re.compile(r"\((\d+)\)\s*$")
_META = {
    "materials", "glossary", "gauge", "yarn", "hook", "assembly",
    "note", "notes", "terms", "difficulty", "category", "pattern",
    "edging", "seam", "finishing", "introduction", "instructions",
    "abbreviations", "stitch", "stitches", "title",
}
_NOT_A_PIECE = {
    "stitch", "stitches", "round", "row", "edge", "end", "side", "sides",
    "top", "bottom", "front", "back", "loop", "inch", "span", "same",
    "first", "next", "last", "other", "following", "remaining", "hook",
    "yarn",
}
_SEW_SKIP = _NOT_A_PIECE | {
    "the", "a", "an", "it", "its", "them", "this", "that", "flat", "shut",
    "closed", "open", "into", "onto", "and", "of", "with", "for", "from",
    "each", "both", "firmly", "lightly", "together", "through", "around",
    "across", "lower", "upper", "left", "right", "portion", "between",
    "using", "tail", "one", "two", "all", "not",
}
_US_ONLY = ("sc", "hdc")
_UK_ONLY = ("htr", "trtr")
_DEFAULT_SYMBOLS = {
    "X": "sc",
    "+": "sc",
    "V": "dc",
    "T": "hdc",
    "O": "chain",
    "•": "sl st",
}
_CHAIN = {"ch", "chain", "chains"}
_SKIPPED = (
    "chart image detector",
    "photo stitch classifier",
    "hosted language model",
    "vision training set",
    "process cluster",
)


@dataclass
class StageReport:
    errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    engines_ran: list[str] = field(default_factory=list)
    engines_skipped: list[str] = field(default_factory=list)

    @property
    def status(self) -> str:
        if self.errors:
            return "ERROR"
        if self.warnings:
            return "PASS_WITH_WARNINGS"
        return "PASS"


def stage_findings(text: str) -> tuple[list[str], list[str]]:
    """Return errors and warnings from the written-text stages."""
    report = run_stages(text)
    return report.errors, report.warnings


def run_stages(text: str) -> StageReport:
    """Run every written-text stage in order. External engines are not called."""
    errors: list[str] = []
    warnings: list[str] = []
    errors.extend(dialect_scope(text))
    errors.extend(termination(text))
    errors.extend(reachability(text))
    errors.extend(references(text))
    errors.extend(chart_text(text))
    errors.extend(short_row_gap(text))
    warnings.extend(ambiguity(text))
    warnings.extend(gauge_band(text))
    warnings.extend(unverified_claims(text))
    warnings.extend(prose_frill(text))
    errors.extend(eyes_on_frill(text))
    errors.extend(cinch_close(text))
    errors.extend(closed_join(text))
    errors.extend(domain_isolation(text))
    errors.extend(edge_lineage(text))
    errors.extend(open_boundary(text))
    errors.extend(two_sheet_seam(text))
    errors.extend(self_seam(text))
    errors.extend(ended_yarn(text))
    errors.extend(round_turn(text))
    errors.extend(closed_piece(text))
    errors.extend(second_start(text))
    errors.extend(count_role(text))
    errors.extend(fasten_contradiction(text))
    errors.extend(competing_counts(text))
    errors.extend(open_and_shut(text))
    errors.extend(two_endings(text))
    errors.extend(spiral_join(text))
    errors.extend(stuff_after_ban(text))
    errors.extend(make_disagree(text))
    errors.extend(written_pairs(text))
    errors.extend(chain_underside(text))
    errors.extend(dropped_body(text))
    errors.extend(front_back_post(text))
    errors.extend(eyes_before_stuff(text))
    warnings.extend(row_end_density(text))
    errors.extend(incoming_cover(text))
    errors.extend(missing_color(text))
    errors.extend(round_order(text))
    warnings.extend(every_base(text))
    errors.extend(chain_too_short(text))
    errors.extend(unclosed_repeat(text))
    errors.extend(missing_star(text))
    errors.extend(decrease_cover(text))
    warnings.extend(over_double(text))
    errors.extend(written_as_mismatch(text))
    errors.extend(eye_count(text))
    errors.extend(future_round(text))
    errors.extend(make_count(text))
    errors.extend(zero_hook(text))
    count_errors, count_warnings = spoken_counts(text)
    errors.extend(count_errors)
    warnings.extend(count_warnings)
    spoken_errors, spoken_warnings = spoken_forms(text)
    errors.extend(spoken_errors)
    warnings.extend(spoken_warnings)
    errors.extend(zero_words(text))
    errors.extend(zero_repeat(text))
    batch_errors, batch_warnings = batch_findings(text)
    errors.extend(batch_errors)
    warnings.extend(huge_hook(text))
    warnings.extend(batch_warnings)
    span_errors, span_warnings = span_findings(text)
    errors.extend(span_errors)
    warnings.extend(span_warnings)
    return StageReport(
        errors=_unique(errors),
        warnings=_unique(warnings),
        engines_ran=[
            "dialect scope",
            "termination",
            "stitch reachability",
            "references",
            "chart text",
            "short-row gap",
            "ambiguity",
            "gauge band",
            "unverified claims",
            "prose frill",
            "eyes on a frill",
            "cinch close",
            "closed join",
            "domain isolation",
            "edge lineage",
            "open boundary",
            "two-sheet seam",
            "self seam",
            "ended yarn",
            "round turn",
            "closed piece",
            "second start",
            "count role",
            "fasten contradiction",
            "competing counts",
            "open and shut",
            "two endings",
            "spiral join",
            "stuff after ban",
            "make count",
            "written pairs",
            "chain underside",
            "dropped body",
            "front and back post",
            "eyes before stuffing",
            "row-end density",
            "incoming cover",
            "missing color",
            "round order",
            "every base stitch",
            "chain length",
            "unclosed repeat",
            "missing star",
            "decrease cover",
            "over-double increase",
            "written-as count",
            "eye count",
            "future round",
            "make count",
            "zero repeat",
            *batch_names(),
            *span_names(),
        ],
        engines_skipped=list(_SKIPPED),
    )


def dialect_scope(text: str) -> list[str]:
    """Flag a US/UK mix inside one piece. Pieces may declare different dialects."""
    errors = []
    pieces = _pieces(text)
    preamble = next((body for name, body in pieces if not name), "")
    default = _declared_dialect(preamble)
    for name, body in pieces:
        declared = _declared_dialect(body) or default
        us = _terms(body, _US_ONLY)
        uk = _terms(body, _UK_ONLY)
        if not us and not uk:
            continue
        label = name or "This pattern"
        if declared == "US" and uk:
            errors.append(
                f"{label} is marked US, but it uses the UK term '{uk[0]}'."
            )
        elif declared == "UK" and us:
            errors.append(
                f"{label} is marked UK, but it uses the US term '{us[0]}'."
            )
        elif declared is None and us and uk:
            errors.append(
                f"{label} mixes the US term '{us[0]}' with the UK term '{uk[0]}'."
            )
    return _unique(errors)


def termination(text: str) -> list[str]:
    """Flag a repeat that has no stitch, round, or inch stop."""
    errors = []
    for line in text.splitlines():
        if line.lstrip().startswith(">") or line.lstrip().startswith("|"):
            continue
        if re.search(r"\bdo not\b|\bdon't\b", line, re.IGNORECASE):
            continue
        match = re.search(
            r"\b(?:repeat|continue|rep)\b(.{0,40}?)\buntil\b(.*)$",
            line,
            re.IGNORECASE,
        )
        forever = re.search(
            r"\b(?:repeat|continue|rep)\b.{0,20}\b(?:forever|indefinitely)\b",
            line,
            re.IGNORECASE,
        )
        if forever:
            errors.append("This repeat does not terminate. Give it a stitch, round, or inch stop.")
            continue
        if not match:
            if (
                not line.lstrip().startswith(">")
                and not line.lstrip().startswith("|")
                and re.search(r"\buntil\b.{0,48}\blong enough\b", line, re.IGNORECASE)
                and not re.search(r"\d", line)
            ):
                errors.append(
                    "This repeat does not terminate. "
                    "Say the stitch count, the round count, or the length."
                )
            continue
        clause = match.group(2)
        if re.search(
            r"\d|\b(?:one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve)\b",
            clause,
            re.IGNORECASE,
        ):
            continue
        errors.append(
            "This repeat does not terminate. "
            "Say the stitch count, the round count, or the length."
        )
    return _unique(errors)


def reachability(text: str) -> list[str]:
    """Flag a stitch index, skip, or leftover loop the previous round cannot reach."""
    errors = []
    previous = None
    loops: dict[int, set[str]] = {}
    for line in text.splitlines():
        stripped = line.strip()
        if _is_piece_line(stripped):
            previous = None
            loops = {}
            continue
        header = _HEADER.match(stripped)
        scope = header.group(3) if header else stripped
        number = int(header.group(2)) if header else None
        if previous is not None:
            ordinal = re.search(
                r"\b(\d+)(?:st|nd|rd|th)\s+st(?:itch)?\b",
                scope,
                re.IGNORECASE,
            )
            if ordinal and int(ordinal.group(1)) > previous:
                errors.append(
                    f"Stitch {ordinal.group(1)} is not reachable. "
                    f"The previous round has {previous} stitches."
                )
            skipped = re.search(r"\b(?:sk|skip)\s+(\d+)\b", scope, re.IGNORECASE)
            if skipped and int(skipped.group(1)) > previous:
                errors.append(
                    f"Skip of {skipped.group(1)} stitches goes past the "
                    f"{previous} stitches still live."
                )
        for match in re.finditer(
            r"\b(?:unused|free|remaining)\s+loops?\s+of\s+(?:round|rnd)\s+(\d+)\b",
            scope,
            re.IGNORECASE,
        ):
            target = int(match.group(1))
            left = loops.get(target)
            if left is not None and not left:
                errors.append(
                    f"The unused loop of Round {target} is not reachable. "
                    "That round already worked both loops."
                )
        if number is not None and previous is not None:
            loops[number - 1] = loops.get(number - 1, set())
        if header and _STATED.search(stripped):
            previous = int(_STATED.search(stripped).group(1))
            if re.search(r"\b(?:blo|flo|back loop|front loop)\b", scope, re.IGNORECASE):
                loops[number] = {"other"}
            else:
                loops[number] = set()
        elif header and previous is not None:
            loops[number] = set()
    return _unique(errors)


def references(text: str) -> list[str]:
    """Flag a named piece or round the pattern never starts."""
    errors = []
    known_rounds = {
        int(match.group(2))
        for line in text.splitlines()
        if (match := _HEADER.match(line.strip()))
    }
    known_pieces = {name.lower() for name in _piece_names(text)}
    for line in text.splitlines():
        if re.search(r"\bdo not\b|\bdon't\b", line, re.IGNORECASE):
            continue
        for match in re.finditer(
            r"\b(?:join|sew|attach|graft|see)\s+to\s+(?:round|rnd)\s+(\d+)\b",
            line,
            re.IGNORECASE,
        ):
            number = int(match.group(1))
            if number not in known_rounds:
                errors.append(f"Round {number} is named but this pattern never starts it.")
        for match in re.finditer(
            r"(?i:\b(?:sew|attach|graft)\b)[^.!\n]{0,80}?\bthe\s+([A-Z][a-z]+)\b",
            line,
        ):
            name = match.group(1)
            if name.lower() in _NOT_A_PIECE or name.lower() in known_pieces:
                continue
            errors.append(f"Piece '{name}' is named in assembly but never started.")
        if _quoted_or_explained(line):
            continue
        for match in re.finditer(
            r"(?i)(?<![A-Za-z])(?:sew|attach|graft)\s+([A-Za-z]+)\s+to\s+([A-Za-z]+)\b",
            line,
        ):
            for name in match.groups():
                if name.lower() in _SEW_SKIP or name.lower() in known_pieces:
                    continue
                errors.append(f"Piece '{name}' is named in assembly but never started.")
    return _unique(errors)


def short_row_gap(text: str) -> list[str]:
    """Flag a short-row span whose missing row-ends are not written."""
    if not re.search(r"\bshort rows?\b", text, re.IGNORECASE):
        return []
    match = re.search(
        r"\b(?:works?|worked)\s+(\d+)\s+of\s+(\d+)\b",
        text,
        re.IGNORECASE,
    )
    if not match:
        return []
    worked = int(match.group(1))
    perimeter = int(match.group(2))
    gap = perimeter - worked
    if gap <= 0:
        return []
    stated = []
    for left, right in re.findall(
        r"\b(\d+)\s+row-?ends?\b|\brow-?ends?\s*(?:\(|:)?\s*(\d+)",
        text,
        re.IGNORECASE,
    ):
        stated.append(int(left or right))
    if gap in stated or sum(stated) == gap:
        return []
    return [
        f"Short-row gap: {worked} of {perimeter} leaves {gap} row-ends unstated."
    ]


def chart_text(text: str) -> list[str]:

    """Count written chart symbols. This does not read a chart image."""
    legend = dict(_DEFAULT_SYMBOLS)
    errors = []
    for line in text.splitlines():
        if re.search(r"\blegend\b|\bsymbols\b", line, re.IGNORECASE):
            for symbol, meaning in re.findall(
                r"([A-Za-z+•])\s*=\s*([A-Za-z]+(?:\s+[A-Za-z]+)?)",
                line,
            ):
                legend[symbol] = meaning.strip().lower()
        if not re.match(r"^(?:#{1,6}\s+)?chart\b", line.strip(), re.IGNORECASE):
            continue
        if re.search(r"\blegend\b|\bsymbols\b", line, re.IGNORECASE):
            continue
        stated = _STATED.search(line.strip())
        body = re.sub(
            r"^(?:#{1,6}\s+)?chart\s+(?:row|round|rnd)?\s*\d*\s*[:.]?\s*",
            "",
            line.strip(),
            flags=re.IGNORECASE,
        )
        body = _STATED.sub("", body).strip()
        count = 0
        for token in body.split():
            meaning = legend.get(token)
            if meaning is None:
                errors.append(f"Chart symbol '{token}' is not in the legend.")
                continue
            if meaning not in _CHAIN:
                count += 1
        if stated and count != int(stated.group(1)):
            errors.append(
                f"Chart row states {stated.group(1)} stitches "
                f"but the symbols produce {count}."
            )
    return _unique(errors)


def ambiguity(text: str) -> list[str]:
    """Warn when a round names a stitch but not how many."""
    warnings = []
    for line in text.splitlines():
        header = _HEADER.match(line.strip())
        if not header:
            continue
        body = _STATED.sub("", header.group(3)).strip()
        if not body or re.search(r"\bdo not\b|\bdon't\b", body, re.IGNORECASE):
            continue
        if re.search(r"\d|\beach\b|\baround\b|\bacross\b|\bremaining\b|\bx\b|×|\btimes\b", body, re.IGNORECASE):
            continue
        if re.search(r"\b(?:sc|hdc|dc|tr|htr|inc|dec|sl\s*st)\b|\bwork even\b", body, re.IGNORECASE):
            kind = header.group(1).title()
            warnings.append(
                f"{kind} {header.group(2)} does not say how many stitches to work."
            )
    return _unique(warnings)


def eyes_on_frill(text: str) -> list[str]:
    """Flag safety eyes mounted on a frill. A prohibition does not fail."""
    errors = []
    for line in text.splitlines():
        if re.search(
            r"\bdo not\b|\bdon't\b|\bnot\s+on\s+the\s+frill\b|\bshould\s+not\b|\bnot\s+be\s+mounted\b",
            line,
            re.IGNORECASE,
        ):
            continue
        if not re.search(r"\b(?:safety\s+)?eyes?\b", line, re.IGNORECASE):
            continue
        if re.search(r"\bon\s+(?:the|a)\s+frill\b", line, re.IGNORECASE):
            errors.append(
                "Safety eyes are mounted on the frill. "
                "A frill has no fabric behind it for the washer. "
                "Mount them on a solid single-crochet round."
            )
    return _unique(errors)



def cinch_close(text: str) -> list[str]:
    """Read a cinch with no stitch count as closing the last stated round."""
    errors = []
    last = None
    count = re.compile(r"\((\d+)\s*(?:sts?|stitches)?\)", re.IGNORECASE)
    instruction = re.compile(
        r"(?i)(?:\bcinch\s+shut\b|\bcinch\s+the\s+last\b|\bfasten off\b.{0,40}\bcinch\b|^\s*cinch\b)"
    )
    for raw in text.splitlines():
        line = raw.strip()
        if not line or _quoted_or_explained(line):
            continue
        found = count.search(line)
        if found:
            last = int(found.group(1))
        if re.search(r"\d", line) or not re.search(r"\bcinch\b", line, re.IGNORECASE):
            continue
        if not instruction.search(line):
            continue
        if last is None:
            errors.append(
                "Cinch shut has no counted round to close. "
                "State the round count before the cinch."
            )
        elif last == 0:
            errors.append("Cinch shut cannot close a round of 0 stitches.")
    return _unique(errors)


def closed_join(text: str) -> list[str]:
    """Flag a join into a closed tentacle, or a cinched round sewn flat."""
    errors = []
    for line in text.splitlines():
        if _prohibition(line):
            continue
        if re.search(r"\bjoin\b.{0,50}\b(?:closed|sealed)\s+tentacle\b", line, re.IGNORECASE):
            errors.append(
                "A closed tentacle has no live stitches to join. "
                "Leave an open edge and state how many stitches it holds."
            )
        if re.search(r"\bcinch\b.{0,40}\bshut\b.{0,40}\bsew\b.{0,30}\bflat\b", line, re.IGNORECASE):
            errors.append(
                "A cinched round is a sealed cap. It cannot be sewn flat. Leave the last round open."
            )
    return _unique(errors)


def domain_isolation(text: str) -> list[str]:
    """Flag a counted round that pulls another piece into its local sum."""
    errors = []
    pieces = _piece_names(text)
    current = ""
    header = re.compile(r"^(?:round|row|rnd)\b", re.IGNORECASE)
    for raw in text.splitlines():
        line = raw.strip()
        name = _piece_name(line)
        if name:
            current = name
            continue
        plain = re.sub(r"^[*_>#\-\d.\s]+", "", line)
        if not header.match(plain) or _quoted_or_explained(line):
            continue
        for piece in pieces:
            if piece.lower() == current.lower():
                continue
            if re.search(rf"\b(?:of|from)\s+the\s+{re.escape(piece)}\b", line, re.IGNORECASE):
                errors.append(
                    f"Stitches of {piece} are outside this round. "
                    "They were not added to the local sum."
                )
    return _unique(errors)


def edge_lineage(text: str) -> list[str]:
    """Flag a seam count that no earlier counted round stated."""
    errors = []
    seen: set[int] = set()
    stated = re.compile(
        r"\((\d+)\s*(?:sts?|stitches)?\b|\b(\d+)\s+(?:sts?|stitches)\b",
        re.IGNORECASE,
    )
    seam_count = re.compile(r"\b(\d+)\s+(?:sts?|stitches)\b", re.IGNORECASE)
    verb = re.compile(r"\b(?:sew|sewn|sewing|attach|attached|graft)\b", re.IGNORECASE)
    for raw in text.splitlines():
        line = raw.strip()
        if not line:
            continue
        prior = set(seen)
        for match in stated.finditer(line):
            seen.add(int(match.group(1) or match.group(2)))
        if _quoted_or_explained(line) or re.search(r"\bdefect\b", line, re.IGNORECASE):
            continue
        if not verb.search(line) or re.search(r"\battach(?:ed)?\s+yarn\b", line, re.IGNORECASE):
            continue
        for match in seam_count.finditer(line):
            count = int(match.group(1))
            if count not in prior:
                errors.append(
                    f"The seam names {count} stitches, but no earlier round states that count. "
                    "The edge was not invented."
                )
    return _unique(errors)


def open_boundary(text: str) -> list[str]:
    """Flag a seam aimed at a closed magic ring or a cinched point."""
    errors = []
    verb = re.compile(
        r"\b(?:sew|sewn|seam|graft)\b|\battach(?:ed)?\b(?!\s+yarn)",
        re.IGNORECASE,
    )
    closed = re.compile(r"\bmagic\s+ring\b|\bcinch(?:ed)?(?:\s+shut)?\b", re.IGNORECASE)
    for raw in text.splitlines():
        line = raw.strip()
        if (
            _quoted_or_explained(line)
            or line.lstrip().startswith("|")
            or re.search(r"\bdefect\b", line, re.IGNORECASE)
        ):
            continue
        if verb.search(line) and closed.search(line):
            errors.append(
                "A seam cannot target a closed magic ring or a cinched point. "
                "Leave an open edge and state its stitch count. The join was not invented."
            )
    return _unique(errors)


def two_sheet_seam(text: str) -> list[str]:
    """Flag one seam line that names three written pieces."""
    names = _piece_names(text)
    if len({name.lower() for name in names}) < 3:
        return []
    errors = []
    verb = re.compile(r"\b(?:sew|sewn|attach|graft)\b", re.IGNORECASE)
    for raw in text.splitlines():
        line = raw.strip()
        if _quoted_or_explained(line) or re.search(r"\bdefect\b", line, re.IGNORECASE):
            continue
        if not verb.search(line) or re.search(r"\battach(?:ed)?\s+yarn\b", line, re.IGNORECASE):
            continue
        found = {
            name.lower()
            for name in names
            if re.search(rf"\b{re.escape(name)}\b", line, re.IGNORECASE)
        }
        if len(found) >= 3:
            errors.append(
                "This seam names more than two pieces. A Y-branch was not drawn, "
                "and the missing seams were not invented."
            )
    return _unique(errors)


def self_seam(text: str) -> list[str]:
    """Flag a seam that joins a written piece to itself."""
    errors = []
    pair = re.compile(
        r"\b(?:sew|sewn|graft)\s+(?:the\s+)?([A-Za-z][A-Za-z0-9]*)\s+to\s+(?:the\s+)?\1\b",
        re.IGNORECASE,
    )
    itself = re.compile(
        r"\b(?:sew|sewn|graft|attach)\b(?!\s+yarn).{0,80}\bto\s+itself\b",
        re.IGNORECASE,
    )
    for raw in text.splitlines():
        line = raw.strip()
        if (
            _quoted_or_explained(line)
            or line.startswith("|")
            or re.search(r"\bdefect\b", line, re.IGNORECASE)
        ):
            continue
        if pair.search(line) or itself.search(line):
            errors.append(
                "This seam joins a piece to itself. The other side was not invented."
            )
    return _unique(errors)


def ended_yarn(text: str) -> list[str]:
    """Flag a counted round that continues after fasten off in the same piece."""
    errors = []
    closed = False
    closed_label = ""
    for raw in text.splitlines():
        line = raw.strip()
        if not line:
            continue
        if _section_break(line):
            closed = False
            closed_label = ""
            continue
        if line.startswith("|") or line.startswith(">"):
            continue
        plain = re.sub(r"^[*_]+", "", line)
        is_round = bool(re.match(r"^(?:round|row|rnd)s?\b", plain, re.IGNORECASE))
        if (
            is_round
            and closed
            and not _quoted_or_explained(line)
            and not re.search(r"\bdefect\b", line, re.IGNORECASE)
        ):
            round_label = _numbered_part(line)
            if closed_label and round_label and closed_label != round_label:
                closed = False
                closed_label = ""
            else:
                errors.append(
                    "Fasten off ended this yarn. A later round in the same piece "
                    "was not continued."
                )
                closed = False
                closed_label = ""
        if (
            re.search(r"\bfasten\s+off\b", line, re.IGNORECASE)
            and not re.search(r"\b(?:do not|don't)\s+fasten\s+off\b", line, re.IGNORECASE)
            and not re.search(
                r"\bkeep\s+(?:the\s+)?(?:working\s+)?yarn\b|\bkeep yarn\b",
                line,
                re.IGNORECASE,
            )
            and not re.search(r"\bdefect\b", line, re.IGNORECASE)
        ):
            closed = True
            closed_label = _numbered_part(line)
    return _unique(errors)


def round_turn(text: str) -> list[str]:
    """Flag a round line that also turns. Turn belongs to a row."""
    errors = []
    for raw in text.splitlines():
        line = raw.strip()
        if _quoted_or_explained(line) or line.startswith("|"):
            continue
        plain = re.sub(r"^[*_]+", "", line)
        if re.match(r"^(?:round|rnd)s?\b", plain, re.IGNORECASE) and re.search(
            r"\bturn\b", line, re.IGNORECASE
        ):
            errors.append("A round says turn. A continuous round does not turn.")
    return _unique(errors)


def _section_break(line: str) -> bool:
    if re.match(r"^(?:#{1,6}\s+|\d+\.\s+|```)", line) or _piece_name(line):
        return True
    plain = re.sub(r"^[*_]+", "", line)
    if (
        plain.endswith(":")
        and len(plain) < 80
        and not re.match(r"^(?:round|row|rnd)s?\b", plain, re.IGNORECASE)
        and not re.search(r"\b(?:sc|hdc|dc|inc|dec|ch)\b", plain, re.IGNORECASE)
    ):
        return True
    return False


def _numbered_part(line: str) -> str:
    match = re.search(
        r"\b(leg|arm|ear|head|body|tentacle|wing|fin)\s*(\d+)\b",
        line,
        re.IGNORECASE,
    )
    if not match:
        return ""
    return f"{match.group(1).lower()} {match.group(2)}"


def closed_piece(text: str) -> list[str]:
    """Flag stuffing, eyes, or a later round after the piece is cinched shut."""
    errors = []
    closed = False
    for raw in text.splitlines():
        line = raw.strip()
        if not line:
            continue
        if _section_break(line):
            closed = False
            continue
        if line.startswith("|") or line.startswith(">"):
            continue
        if re.search(r"\bdefect\b", line, re.IGNORECASE):
            continue
        plain = re.sub(r"^[*_]+", "", line)
        is_round = bool(re.match(r"^(?:round|row|rnd)s?\b", plain, re.IGNORECASE))
        close_at = _close_at(line)
        if closed and not _quoted_or_explained(line):
            if is_round or re.search(r"\bstuff(?:ing|ed)?\b", line, re.IGNORECASE) or re.search(
                r"\bsafety\s+eyes\b", line, re.IGNORECASE
            ):
                errors.append(
                    "Cinch shut closed this piece. Stuffing, safety eyes, or a later "
                    "round were not added after it."
                )
                closed = False
        if close_at is not None and not _quoted_or_explained(line):
            rest = line[close_at:]
            if re.search(r"\bstuff(?:ing|ed)?\b", rest, re.IGNORECASE) or re.search(
                r"\bsafety\s+eyes\b", rest, re.IGNORECASE
            ):
                errors.append(
                    "Cinch shut closed this piece. Stuffing, safety eyes, or a later "
                    "round were not added after it."
                )
            closed = True
    return _unique(errors)


def _close_at(line: str) -> int | None:
    if re.search(
        r"\b(?:do not|don't|cannot|can't)\b[^.]{0,48}\bcinch\b|\bnot\s+cinch\b",
        line,
        re.IGNORECASE,
    ):
        return None
    match = re.search(
        r"\bcinch(?:ed)?\s+shut\b|\bcinch(?:ed)?\b[^.]{0,48}\bclosed\b",
        line,
        re.IGNORECASE,
    )
    if not match:
        return None
    return match.end()


def second_start(text: str) -> list[str]:
    """Flag a second magic ring within one piece, but allow a numbered restart.

    A new Round/Row 1 with a magic-ring foundation is an explicit signal that
    the writer has begun another piece even when a heading was omitted.
    """
    errors = []
    seen = False
    last_number = None
    for raw in text.splitlines():
        line = raw.strip()
        if not line:
            continue
        if _section_break(line):
            seen = False
            last_number = None
            continue
        if (
            line.startswith("|")
            or line.startswith(">")
            or _quoted_or_explained(line)
            or re.search(r"\bdefect\b", line, re.IGNORECASE)
        ):
            continue
        plain = re.sub(r"^[*_]+", "", line)
        header = _HEADER.match(plain)
        if not header:
            continue
        number = int(header.group(2))
        has_ring = bool(re.search(r"\bmagic\s+ring\b", line, re.IGNORECASE))
        if has_ring and last_number is not None and number <= last_number:
            seen = False
        if has_ring:
            if seen:
                errors.append(
                    "This piece already started. A second magic ring was not added."
                )
            seen = True
        last_number = number
    return _unique(errors)


def count_role(text: str) -> list[str]:
    """Flag a chain that counts as a stitch and does not count."""
    errors = []
    for raw in text.splitlines():
        line = raw.strip()
        if line.startswith("|") or line.startswith(">") or re.search(r"\bdefect\b", line, re.IGNORECASE):
            continue
        if re.search(r"\bcounts\s+as\b", line, re.IGNORECASE) and re.search(
            r"\bdoes\s+not\s+count\b", line, re.IGNORECASE
        ):
            errors.append(
                "The line says the chain counts as a stitch and does not count. "
                "The count was not invented."
            )
    return _unique(errors)


def fasten_contradiction(text: str) -> list[str]:
    """Flag a line that fastens off and does not fasten off."""
    errors = []
    ban = re.compile(r"\b(?:do not|don't)\s+fasten\s+off\b", re.IGNORECASE)
    for raw in text.splitlines():
        line = raw.strip()
        if line.startswith("|") or line.startswith(">") or re.search(r"\bdefect\b", line, re.IGNORECASE):
            continue
        if ban.search(line) and re.search(r"\bfasten\s+off\b", ban.sub("", line), re.IGNORECASE):
            errors.append(
                "The line fastens off and does not fasten off. The ending was not invented."
            )
    return _unique(errors)


def competing_counts(text: str) -> list[str]:
    """Flag one line that states two different stitch counts."""
    errors = []
    group = re.compile(r"\((\d+)\s*(?:sts?|stitches)\b", re.IGNORECASE)
    for raw in text.splitlines():
        line = raw.strip()
        if _skip_line(line):
            continue
        counts = {int(match.group(1)) for match in group.finditer(line)}
        if len(counts) >= 2:
            errors.append(
                "This line states more than one stitch count. The extra count was not chosen."
            )
    return _unique(errors)


def open_and_shut(text: str) -> list[str]:
    """Flag a line that closes the piece and leaves it open."""
    errors = []
    close = re.compile(
        r"\bcinch(?:ed)?\s+shut\b|\bcinch(?:ed)?\b[^.]{0,40}\bclosed\b",
        re.IGNORECASE,
    )
    leave = re.compile(
        r"\bleave\b[^.]{0,32}\bopen\b|\bopening\s+open\b|\bkeep\b[^.]{0,24}\bopen\b",
        re.IGNORECASE,
    )
    for raw in text.splitlines():
        line = raw.strip()
        if _skip_line(line) or _quoted_or_explained(line):
            continue
        if close.search(line) and leave.search(line):
            errors.append(
                "The line closes the piece and leaves it open. The opening was not invented."
            )
    return _unique(errors)


def two_endings(text: str) -> list[str]:
    """Flag an invisible join and a slip-stitch join on one line."""
    errors = []
    invisible = re.compile(r"\binvisible\s+join\b", re.IGNORECASE)
    slip = re.compile(
        r"\b(?:slip\s+stitch|sl\s*st)\b[^.]{0,24}\bjoin\b|\bjoin\s+with\s+(?:a\s+)?(?:slip\s+stitch|sl\s*st)\b",
        re.IGNORECASE,
    )
    for raw in text.splitlines():
        line = raw.strip()
        if _skip_line(line) or _quoted_or_explained(line):
            continue
        if invisible.search(line) and slip.search(line):
            errors.append(
                "An invisible join and a slip-stitch join are two endings. "
                "The extra join was not invented."
            )
    return _unique(errors)


def spiral_join(text: str) -> list[str]:
    """Flag a spiral that also joins the round."""
    errors = []
    spiral = re.compile(r"\bspiral\b", re.IGNORECASE)
    join = re.compile(
        r"\bjoin\s+with\s+(?:a\s+)?(?:slip\s+stitch|sl\s*st)\b"
        r"|\b(?:slip\s+stitch|sl\s*st)\b[^.]{0,24}\bjoin\b"
        r"|\bjoin\s+(?:each|every)\s+round\b",
        re.IGNORECASE,
    )
    waiting = False
    for raw in text.splitlines():
        line = raw.strip()
        if not line:
            continue
        if _section_break(line):
            waiting = False
            continue
        if _skip_line(line):
            continue
        if _quoted_or_explained(line):
            if spiral.search(line) and re.search(r"\b(?:do not|don't)\s+join\b", line, re.IGNORECASE):
                waiting = False
            continue
        if spiral.search(line) and join.search(line):
            errors.append(
                "A continuous spiral does not join every round. The join was not added."
            )
            waiting = False
            continue
        if waiting and join.search(line):
            errors.append(
                "A continuous spiral does not join every round. The join was not added."
            )
            waiting = False
            continue
        if spiral.search(line):
            waiting = True
    return _unique(errors)


def stuff_after_ban(text: str) -> list[str]:
    """Flag stuffing after the same piece says not to stuff."""
    errors = []
    banned = False
    for raw in text.splitlines():
        line = raw.strip()
        if not line:
            continue
        if _section_break(line):
            banned = False
            continue
        if _skip_line(line):
            continue
        if re.search(r"\b(?:do not|don't)\s+stuff\b", line, re.IGNORECASE):
            banned = True
            continue
        if banned and re.search(r"\bstuff(?:ing|ed)?\b", line, re.IGNORECASE) and not _quoted_or_explained(line):
            errors.append(
                "The piece says not to stuff, then stuffs. The stuffing was not added."
            )
            banned = False
    return _unique(errors)


def make_disagree(text: str) -> list[str]:
    """Flag one piece written with two different make counts."""
    errors = []
    seen: dict[str, tuple[str, int]] = {}
    pattern = re.compile(
        r"\b([A-Za-z][A-Za-z]+(?:\s+[A-Za-z][A-Za-z]+){0,2})\s*\(make\s+(\d+)\)",
        re.IGNORECASE,
    )
    for raw in text.splitlines():
        line = raw.strip()
        if _skip_line(line):
            continue
        for match in pattern.finditer(line):
            key = re.sub(r"\s+", " ", match.group(1)).strip().lower()
            if key in {"round", "row", "rnd", "hook", "yarn", "color"}:
                continue
            count = int(match.group(2))
            if key in seen and seen[key][1] != count:
                errors.append(
                    f"{seen[key][0]} is written as make {seen[key][1]} and make {count}. "
                    "The extra copies were not invented."
                )
            else:
                seen[key] = (match.group(1).strip(), count)
    return _unique(errors)


def _skip_line(line: str) -> bool:
    return (
        not line.strip()
        or line.lstrip().startswith("|")
        or line.lstrip().startswith(">")
        or bool(re.search(r"\bdefect\b", line, re.IGNORECASE))
    )


_COUNT_WORDS = {
    "one": 1,
    "two": 2,
    "three": 3,
    "four": 4,
    "five": 5,
    "six": 6,
    "seven": 7,
    "eight": 8,
    "nine": 9,
    "ten": 10,
    "eleven": 11,
    "twelve": 12,
    "thirteen": 13,
    "fourteen": 14,
    "fifteen": 15,
    "sixteen": 16,
    "seventeen": 17,
    "eighteen": 18,
    "nineteen": 19,
    "twenty": 20,
}
_WORD_LIST = "|".join(_COUNT_WORDS)
_WORD_DIGIT = re.compile(rf"\b({_WORD_LIST})\b\s*\(\s*(\d+)\s*\)", re.IGNORECASE)
_DIGIT_WORD = re.compile(rf"\b(\d+)\s*\(\s*({_WORD_LIST})\s*\)", re.IGNORECASE)
_NEGATIVE_MEASURE = re.compile(
    r"(?<![\d.])-\d+(?:\.\d+)?\s*(?:inches?|cm|mm|sts?|stitches|sc|hdc|dc)\b",
    re.IGNORECASE,
)


def written_pairs(text: str) -> list[str]:
    """Flag a contradiction in any sentence, not only one copied lesson line."""
    errors = []
    for raw in text.splitlines():
        line = raw.strip()
        if _skip_line(line):
            continue
        if _banned_and_done(line, r"\b(?:do not|don't)\s+stuff(?:ing)?\b", r"\bstuff(?:ing|ed)?\b"):
            errors.append("The line stuffs and does not stuff. The stuffing was not added.")
        if _banned_and_done(line, r"\b(?:do not|don't)\s+turn\b", r"\bturn\b"):
            errors.append("The line turns and does not turn. The turn was not added.")
        if _quoted_or_explained(line):
            continue
        errors.extend(_pair_messages(line))
        errors.extend(_word_digit(line))
        if _NEGATIVE_MEASURE.search(line):
            errors.append("A negative measure is not a size. No length was invented.")
        if _copied_unit(line):
            errors.append("The line copies the same number into both units. The length was not converted.")
    return _unique(errors)


def _choice(line: str) -> bool:
    return bool(re.search(r"\bor\b|\bcannot\b", line, re.IGNORECASE))


def _has(line: str, pattern: str) -> bool:
    return bool(re.search(pattern, line, re.IGNORECASE))


def _pair_messages(line: str) -> list[str]:
    if _choice(line):
        return []
    found = []
    both_ways = _has(line, r"left to right") and _has(line, r"right to left")
    if both_ways or _has(line, r"\bboth directions\b"):
        found.append("The line gives both directions and does not say or.")
    if _has(line, r"right side") and _has(line, r"wrong side"):
        found.append("The right side and the wrong side cannot both face the worker.")
    if _has(line, r"yarn over") and _has(line, r"yarn under"):
        found.append("Yarn over and yarn under cannot be the same stitch.")
    if _has(line, r"reverse (?:sc|single crochet)") and _has(line, r"\bforwards?\b") and not _has(line, r"\bbackward\b"):
        found.append("Reverse single crochet is worked backward, not forward.")
    if _has(line, r"right-handed") and _has(line, r"left-handed") and not _has(line, r"\bseparate\b"):
        found.append("Right-handed and left-handed work need separate instructions.")
    if _has(line, r"whip\s*stitch") and _has(line, r"mattress stitch"):
        found.append("Whipstitch and mattress stitch are two seams. The extra seam was not invented.")
    if _has(line, r"magic ring") and _has(line, r"chain ring|form(?:ed|ing)? (?:a |an )?(?:open )?ring"):
        found.append("A piece cannot start with both a magic ring and a chain ring.")
    if _has(line, r"\bFLO\s+and\s+BLO\b|\bBLO\s+and\s+FLO\b|\bBLO only and both loops\b"):
        found.append("FLO and BLO cannot be the same stitch.")
    if _has(line, r"in the round") and _has(line, r"back and forth"):
        found.append("In the round and back and forth are two fabrics. The extra fabric was not invented.")
    if _has(line, r"\binc(?:rease)?\b") and _has(line, r"\bdec(?:rease)?\b") and _has(line, r"\b(?:same|every|each) stitch\b"):
        found.append("Increase and decrease cannot be the same stitch.")
    plain = re.sub(r"^[*_]+", "", line)
    if re.match(r"^rows?\b", plain, re.IGNORECASE) and _has(line, r"\baround\b"):
        found.append("A row says around. Rows are worked across.")
    return found


def _word_digit(line: str) -> list[str]:
    errors = []
    for pattern, word_group, digit_group in (
        (_WORD_DIGIT, 1, 2),
        (_DIGIT_WORD, 2, 1),
    ):
        for match in pattern.finditer(line):
            before = line[max(0, match.start() - 12):match.start()]
            if re.search(r"\b(?:round|row|rnd)s?\s*$", before, re.IGNORECASE):
                continue
            word = match.group(word_group).lower()
            digit = int(match.group(digit_group))
            if _COUNT_WORDS[word] != digit:
                errors.append(
                    "The word and the digit are different counts. The extra count was not chosen."
                )
    return errors


def _copied_unit(line: str) -> bool:
    patterns = (
        r"\b(\d+(?:\.\d+)?)\s*inches\b[^.]{0,40}\b(\d+(?:\.\d+)?)\s*cm\b",
        r"\b(\d+(?:\.\d+)?)\s*cm\b[^.]{0,40}\b(\d+(?:\.\d+)?)\s*inches\b",
    )
    for pattern in patterns:
        match = re.search(pattern, line, re.IGNORECASE)
        if match and match.group(1) == match.group(2):
            return True
    return False


def _banned_and_done(line: str, ban: str, verb: str) -> bool:
    pattern = re.compile(ban, re.IGNORECASE)
    if not pattern.search(line):
        return False
    return bool(re.search(verb, pattern.sub("", line), re.IGNORECASE))


def chain_underside(text: str) -> list[str]:
    """Flag a stated count that needs both sides of a chain when only one is written."""
    errors = []
    for line in text.splitlines():
        if re.search(r"\bunderside\b|\bboth sides\b", line, re.IGNORECASE):
            continue
        stated = _STATED.search(line.strip())
        chains = [int(item) for item in re.findall(r"\bch\s+(\d+)\b", line, re.IGNORECASE)]
        if not stated or len(chains) != 1:
            continue
        chain = chains[0]
        across = [int(item) for item in re.findall(r"\bsc\s+(\d+)\s+across\b", line, re.IGNORECASE)]
        if sum(1 for item in across if item == chain) != 1:
            continue
        singles = [int(item) for item in re.findall(r"\bsc\s+(\d+)\b", line, re.IGNORECASE)]
        if chain not in singles:
            continue
        singles.remove(chain)
        both = sum(singles) + (2 * chain)
        if int(stated.group(1)) == both:
            errors.append(
                f"Chain underside missing: ch {chain} is crossed once, "
                f"but {both} counts both sides."
            )
    return _unique(errors)


def dropped_body(text: str) -> list[str]:
    """Flag body stitches taken from a larger count with no skip written."""
    errors = []
    for line in text.splitlines():
        match = re.search(
            r"\bwork(?:ed)?\s+(\d+)\b.{0,40}?\bfrom\s+(?:an?\s+)?(\d+)-stitch\b",
            line,
            re.IGNORECASE,
        )
        if not match:
            continue
        worked = int(match.group(1))
        source = int(match.group(2))
        gap = source - worked
        if gap <= 0:
            continue
        if re.search(rf"\bskip(?:ped)?\s+{gap}\b", line, re.IGNORECASE):
            continue
        errors.append(
            f"Dropped body stitches: {worked} worked from {source} leaves {gap} unwritten. "
            "Write the skip, or work the full count."
        )
    return _unique(errors)


def front_back_post(text: str) -> list[str]:
    """Flag a back post worked in the front loop. A quoted line is not an instruction."""
    errors = []
    for line in text.splitlines():
        if line.lstrip().startswith(">") or _prohibition(line):
            continue
        front = re.search(r"\b(?:flo|front loop)\b", line, re.IGNORECASE)
        back = re.search(r"\bbp(?:sc|hdc|dc|tr)\b", line, re.IGNORECASE)
        if front and back:
            errors.append(
                "A back post in the front loop turns the ridge inward. "
                "Use a front post if the ridge should show."
            )
    return _unique(errors)


def eyes_before_stuff(text: str) -> list[str]:
    """Flag safety eyes placed after the piece has been stuffed."""
    errors = []
    for name, body in _pieces(text):
        stuff_at = None
        eyes_at = None
        for index, line in enumerate(body.splitlines()):
            if stuff_at is None and re.search(r"\bstuff(?:ed)?\b", line, re.IGNORECASE):
                stuff_at = index
            if eyes_at is None and re.search(
                r"\b(?:insert|mount|place|attach)\b.{0,30}\beyes?\b",
                line,
                re.IGNORECASE,
            ):
                eyes_at = index
        if stuff_at is not None and eyes_at is not None and stuff_at < eyes_at:
            label = name or "This piece"
            errors.append(
                f"{label}: safety eyes are placed after stuffing. "
                "Insert them before the piece is stuffed."
            )
    return _unique(errors)


def row_end_density(text: str) -> list[str]:
    """Warn when more than 3 stitches are worked in each row end."""
    warnings = []
    for line in text.splitlines():
        if _quoted_or_explained(line):
            continue
        match = re.search(
            r"\b(\d+)\s+stitches\s+in\s+each\s+row[-\s]?ends?\b",
            line,
            re.IGNORECASE,
        )
        if not match:
            continue
        count = int(match.group(1))
        if count > 3:
            warnings.append(
                f"Row-end density: {count} stitches in each row end is above 3. "
                "The edge will bunch."
            )
    return _unique(warnings)


def incoming_cover(text: str) -> list[str]:
    """Flag a written repeat that does not consume the incoming count on the same line."""
    errors = []
    for line in text.splitlines():
        incoming = re.search(r"\bon\s+(\d+)\s+stitches\b", line, re.IGNORECASE)
        repeat = re.search(r"\(([^)]+)\)\s*[x×]\s*(\d+)", line, re.IGNORECASE)
        if not incoming or not repeat:
            continue
        available = int(incoming.group(1))
        used = _repeat_use(repeat.group(1), int(repeat.group(2)))
        if used is None or used == available:
            continue
        if re.search(rf"\bskip(?:ped)?\s+{abs(available - used)}\b", line, re.IGNORECASE):
            continue
        errors.append(
            f"Incoming cover: the repeat uses {used} of {available} stitches. "
            f"{abs(available - used)} are unaccounted for."
        )
    return _unique(errors)


def missing_color(text: str) -> list[str]:
    """Flag a Color letter used when a yarn list names other colors but not this one."""
    listed = set()
    used = []
    for line in text.splitlines():
        if line.lstrip().startswith(">"):
            continue
        defined = set(re.findall(r"\bColor\s+([A-Z])\s*:", line))
        if re.match(r"^\s*(?:[-*]\s*)?(?:yarn|materials)\b", line, re.IGNORECASE):
            defined.update(re.findall(r"\bColor\s+([A-Z])\b", line))
        if defined:
            listed.update(defined)
            continue
        used.extend(re.findall(r"\bColor\s+([A-Z])\b", line))
    if not listed:
        return []
    return _unique(
        [
            f"Color {color} is used but the yarn line never lists it."
            for color in used
            if color not in listed
        ]
    )


def round_order(text: str) -> list[str]:
    """Flag a round number that repeats or goes backwards inside one piece."""
    errors = []
    seen: set[int] = set()
    last = None
    for line in text.splitlines():
        if _is_piece_line(line):
            seen = set()
            last = None
            continue
        header = _HEADER.match(line.strip())
        if not header:
            continue
        start = int(header.group(2))
        end_match = re.search(r"\d+\s*[-–—]\s*(\d+)", line)
        end = int(end_match.group(1)) if end_match else start
        # A numbered round restart at a magic ring begins a new piece; do not
        # treat the reset as a duplicate round in the prior piece.
        if last is not None and start <= last and re.search(
            r"\bmagic\s+ring\b", line, re.IGNORECASE
        ):
            seen = set()
            last = None
        numbers = range(start, end + 1)
        if any(number in seen or (last is not None and number < last) for number in numbers):
            errors.append(
                f"Round {start} repeats or goes backwards. Number the rounds in order."
            )
        seen.update(numbers)
        last = end
    return _unique(errors)


def every_base(text: str) -> list[str]:
    """Warn when more than 2.5 stitches are worked into every base stitch."""
    warnings = []
    for line in text.splitlines():
        if _quoted_or_explained(line):
            continue
        match = re.search(
            r"\b(\d+(?:\.\d+)?)\s+stitches\s+worked\s+into\s+every\s+base\b",
            line,
            re.IGNORECASE,
        )
        if not match:
            continue
        count = float(match.group(1))
        if count > 2.5:
            warnings.append(
                f"Every base stitch is worked {count:g} times. Above 2.5x the fabric bunches."
            )
    return _unique(warnings)


def _prohibition(line: str) -> bool:
    return bool(re.search(r"\bdo not\b|\bdon't\b|\bshould\s+not\b", line, re.IGNORECASE))


def _quoted_or_explained(line: str) -> bool:
    if line.lstrip().startswith(">") or _prohibition(line):
        return True
    return bool(re.search(r"\binstead of\b|\bcreates\b|\bexcessive\b|\bstated\b", line, re.IGNORECASE))


def _repeat_use(unit: str, times: int) -> int | None:
    used = 0
    found = False
    for part in unit.split(","):
        part = part.strip()
        counted = re.search(
            r"(\d+)\s+(sc|hdc|dc|tr|inc|dec|sc2tog)\b",
            part,
            re.IGNORECASE,
        )
        bare = re.search(r"\b(sc|hdc|dc|tr|inc|dec|sc2tog)\b", part, re.IGNORECASE)
        if counted:
            count = int(counted.group(1))
            name = counted.group(2).lower()
        elif bare:
            count = 1
            name = bare.group(1).lower()
        else:
            continue
        found = True
        used += count * (2 if name in {"dec", "sc2tog"} else 1)
    if not found:
        return None
    return used * times



def chain_too_short(text: str) -> list[str]:
    """Flag a foundation chain that is shorter than the stitches worked into it."""
    errors = []
    for line in text.splitlines():
        if not re.search(r"\b2nd\s+ch\b|\beach\s+ch\b", line, re.IGNORECASE):
            continue
        chain = re.search(r"\bch\s+(\d+)\b", line, re.IGNORECASE)
        stated = _STATED.search(line.strip())
        if not chain or not stated:
            continue
        length = int(chain.group(1))
        count = int(stated.group(1))
        limit = length - 1 if re.search(r"\b2nd\s+ch\b", line, re.IGNORECASE) else length
        if count > limit:
            errors.append(
                f"Chain of {length} cannot hold {count} stitches. "
                f"The most this line can hold is {limit}."
            )
    return _unique(errors)


def unclosed_repeat(text: str) -> list[str]:
    """Flag a round whose parentheses do not balance."""
    errors = []
    for line in text.splitlines():
        header = _HEADER.match(line.strip())
        if not header:
            continue
        body = header.group(3)
        if body.count("(") != body.count(")"):
            kind = header.group(1).title()
            errors.append(
                f"{kind} {header.group(2)} has an unclosed parenthesis. Close the repeat."
            )
    return _unique(errors)


def missing_star(text: str) -> list[str]:
    """Flag rep from * when the line never opens the star."""
    errors = []
    for line in text.splitlines():
        if line.lstrip().startswith(">") or _prohibition(line):
            continue
        if not re.search(r"\brep(?:eat)?\s+from\s+\*", line, re.IGNORECASE):
            continue
        if line.count("*") < 2:
            errors.append("Rep from * has no opening star. Mark the start of the repeat with *.")
    return _unique(errors)


def decrease_cover(text: str) -> list[str]:
    """Flag a decrease repeat that does not consume the count written on the same line."""
    errors = []
    for line in text.splitlines():
        match = re.search(
            r"\bdec(?:rease)?\s*[x×]\s*(\d+)\s+on\s+(\d+)\s+stitches\b",
            line,
            re.IGNORECASE,
        )
        if not match:
            continue
        times = int(match.group(1))
        incoming = int(match.group(2))
        used = times * 2
        if used == incoming:
            continue
        errors.append(
            f"Decrease cover: dec x {times} uses {used} stitches, not {incoming}."
        )
    return _unique(errors)


def over_double(text: str) -> list[str]:
    """Warn when a stated increase exceeds 2x; a ratio alone is not proof of error."""
    warnings: list[str] = []
    previous = None
    for line_number, line in enumerate(text.splitlines(), 1):
        if _is_piece_line(line) or line.startswith("## "):
            previous = None
            continue
        header = _HEADER.match(line.strip())
        stated = _STATED.search(line.strip()) if header else None
        if not header or not stated:
            continue
        produced = int(stated.group(1))
        if previous is not None and produced > previous * 2:
            label = header.group(1).title()
            warnings.append(
                f"Line {line_number}: {label} {header.group(2)} jumps from "
                f"{previous} to {produced}. More than doubling is a large increase; "
                "verify the shaping and count."
            )
        previous = produced
    return _unique(warnings)


def written_as_mismatch(text: str) -> list[str]:
    """Flag an N-stitch edge that the same line writes as a different count."""
    errors = []
    for line in text.splitlines():
        if line.lstrip().startswith(">"):
            continue
        match = re.search(
            r"\b(\d+)-stitch\b.{0,80}?\bwritten\s+as\s+(\d+)\b",
            line,
            re.IGNORECASE,
        )
        if not match:
            continue
        left = int(match.group(1))
        right = int(match.group(2))
        if left != right:
            errors.append(
                f"Written count {right} does not match the {left}-stitch edge."
            )
    return _unique(errors)


def eye_count(text: str) -> list[str]:
    """Flag a mount count that disagrees with the materials count in the same section."""
    errors = []
    for section in _sections(text):
        listed = re.findall(r"safety\s+eyes?\s*\(x\s*(\d+)\)", section, re.IGNORECASE)
        mounted = re.findall(
            r"\b(?:mount|insert|place)\s+(\d+)\s+safety\s+eyes?\b",
            section,
            re.IGNORECASE,
        )
        if not listed or not mounted:
            continue
        if int(listed[0]) != int(mounted[0]):
            errors.append(
                f"Eye count: materials list {listed[0]} safety eyes, "
                f"but the instructions place {mounted[0]}."
            )
    return _unique(errors)


def future_round(text: str) -> list[str]:
    """Flag a round that works into a later round number."""
    errors = []
    for line in text.splitlines():
        header = _HEADER.match(line.strip())
        if not header:
            continue
        current = int(header.group(2))
        for match in re.finditer(r"\b(?:round|rnd)\s+(\d+)\b", header.group(3), re.IGNORECASE):
            target = int(match.group(1))
            if target > current:
                errors.append(
                    f"Round {current} works into Round {target}, which has not been made yet."
                )
    return _unique(errors)


def make_count(text: str) -> list[str]:
    """Flag sewing a different number of a piece than its make count."""
    errors = []
    for section in _sections(text):
        made = {}
        for line in section.splitlines():
            match = re.search(
                r"\b([A-Za-z][A-Za-z]+)\s*\(make\s+(\d+)\)",
                line,
                re.IGNORECASE,
            )
            if match:
                made[match.group(1).lower()] = int(match.group(2))
        for line in section.splitlines():
            if line.lstrip().startswith(">"):
                continue
            for name, count in made.items():
                found = re.search(rf"\b(\d+)\s+{name}s?\b", line, re.IGNORECASE)
                if found and int(found.group(1)) != count:
                    errors.append(
                        f"Make count: {name} is made {count} times, "
                        f"but the line uses {found.group(1)}."
                    )
    return _unique(errors)


def zero_hook(text: str) -> list[str]:
    """Flag a hook size of 0 mm in any sentence, not only "Hook: 0 mm"."""
    zero = re.compile(
        r"\bhook\b[^.\n]{0,48}?(?<![\d.])0(?:\.0+)?\s*mm\b"
        r"|(?<![\d.])0(?:\.0+)?\s*mm\b[^.\n]{0,48}?\bhook\b",
        re.IGNORECASE,
    )
    errors = []
    for line in text.splitlines():
        if line.lstrip().startswith(">") or _prohibition(line):
            continue
        if zero.search(line):
            errors.append("A hook of 0 mm cannot make a stitch.")
    return _unique(errors)




def huge_hook(text: str) -> list[str]:
    """Warn when a hook of 30 mm or more is named in any sentence."""
    huge = re.compile(
        r"\bhook\b[^.\n]{0,32}?(?<![\d.])(?:[3-9]\d|\d{3,})(?:\.0+)?\s*mm\b"
        r"|(?<![\d.])(?:[3-9]\d|\d{3,})(?:\.0+)?\s*mm\b[^.\n]{0,16}?\bhook\b",
        re.IGNORECASE,
    )
    warnings = []
    for line in text.splitlines():
        if line.lstrip().startswith(">") or _prohibition(line):
            continue
        if huge.search(line):
            warnings.append(
                "A hook of 40 mm or more is past normal crochet. This is a warning."
            )
    return _unique(warnings)




def spoken_counts(text: str) -> tuple[list[str], list[str]]:
    """Accept word counts, and the same arithmetic defects, in any sentence."""
    errors: list[str] = []
    warnings: list[str] = []
    words = {
        "zero": 0, "one": 1, "two": 2, "three": 3, "four": 4, "five": 5,
        "six": 6, "seven": 7, "eight": 8, "nine": 9, "ten": 10, "eleven": 11,
        "twelve": 12, "thirteen": 13, "fourteen": 14, "fifteen": 15,
        "sixteen": 16, "seventeen": 17, "eighteen": 18, "nineteen": 19,
        "twenty": 20, "thirty": 30, "forty": 40,
    }
    number = "|".join(sorted(words, key=len, reverse=True))
    token = rf"(?<![\d.])(\d+|{number})(?!\d|\.\d|[A-Za-z])"

    def as_int(raw: str) -> int:
        raw = raw.lower()
        return words[raw] if raw in words else int(raw)

    increase = re.compile(
        rf"\b(increase|decrease)\s+from\s+{token}\s+to\s+{token}\b",
        re.IGNORECASE,
    )
    multiple = re.compile(
        rf"\bmultiple\s+of\s+{token}\s*,\s*{token}\s+stitches\b",
        re.IGNORECASE,
    )
    plus = re.compile(
        rf"\bmultiple\s+of\s+{token}\s+plus\s+{token}\s*,\s*{token}\s+stitches\b",
        re.IGNORECASE,
    )
    parity = re.compile(
        rf"\bcount\s+must\s+be\s+(even|odd)\s*\(\s*{token}\s+stitches\s*\)",
        re.IGNORECASE,
    )
    apart = re.compile(
        rf"\beyes\s+{token}\s+stitches\s+apart\s+on\s+a\s+{token}-stitch\s+round\b",
        re.IGNORECASE,
    )
    marker = re.compile(
        rf"\bmarker\s+in\s+stitch\s+{token}\s+on\s+a\s+{token}-stitch\s+round\b",
        re.IGNORECASE,
    )
    skip = re.compile(
        rf"\bskip\s+{token}\s+on\s+a\s+{token}-stitch\s+row\b",
        re.IGNORECASE,
    )
    rounds = re.compile(
        rf"\b(rounds|rows)\s+{token}\s*[{chr(45)}{chr(8211)}{chr(8212)}]\s*{token}\b",
        re.IGNORECASE,
    )
    inches = re.compile(
        rf"\b{token}\s+inches\s*=\s*{token}\s+cm\b",
        re.IGNORECASE,
    )
    centimeters = re.compile(
        rf"\b{token}\s+cm\s*=\s*{token}\s+inches\b",
        re.IGNORECASE,
    )
    hook_letter = re.compile(
        r"\bhook:?\s*([A-Z](?:/[A-Z0-9]+)?(?:-\d+(?:\.\d+)?)?)\s*\((\d+(?:\.\d+)?)\s*mm\)",
        re.IGNORECASE,
    )
    turn = re.compile(
        rf"\bch\s+{token}\s*,\s*turn\s*,\s*(tr|dtr)\b",
        re.IGNORECASE,
    )
    counts_as = re.compile(
        rf"\bch\s+{token}\s+counts\s+as\s+an?\s+(sc|hdc|dc|tr|dtr)\b",
        re.IGNORECASE,
    )
    zero_mm = re.compile(
        r"\bhook\b[^.\n]{0,48}?(?<![\d.])(?:0|zero)(?:\.0+)?\s*(?:mm|millimeters?)\b"
        r"|(?<![\d.])(?:0|zero)(?:\.0+)?\s*(?:mm|millimeters?)\b[^.\n]{0,48}?\bhook\b",
        re.IGNORECASE,
    )
    huge_mm = re.compile(
        r"\bhook\b[^.\n]{0,32}?(?<![\d.])(?:(?:[3-9]\d|\d{3,})(?:\.0+)?|thirty|forty)\s*(?:mm|millimeters?)\b"
        r"|(?<![\d.])(?:(?:[3-9]\d|\d{3,})(?:\.0+)?|thirty|forty)\s*(?:mm|millimeters?)\b[^.\n]{0,16}?\bhook\b",
        re.IGNORECASE,
    )
    written = re.compile(
        rf"\b{token}-stitch\b.{0,80}?\bwritten\s+as\s+{token}\b",
        re.IGNORECASE,
    )
    steel = re.compile(
        rf"\bsteel\s+hook\s+{token}\b[^.\n]{0,40}?\blarger\s+than\s+(?:a\s+)?steel\s+hook\s+{token}\b",
        re.IGNORECASE,
    )
    reverse = re.compile(r"\breverse\s+sc\s+worked\s+forward\b", re.IGNORECASE)
    spiral = re.compile(
        r"\bcontinuous\s+spiral\b[^.\n]{0,40}?\bturn\s+every\s+round\b",
        re.IGNORECASE,
    )
    fasten = re.compile(
        r"\bfasten\s+off\b[^.\n]{0,24}?\bcontinue\s+in\s+the\s+same\s+yarn\b",
        re.IGNORECASE,
    )
    listed_eyes = re.compile(rf"safety\s+eyes?\s*\(x\s*{token}\)", re.IGNORECASE)
    mounted_eyes = re.compile(
        rf"\b(?:mount|insert|place)\s+{token}\s+safety\s+eyes?\b",
        re.IGNORECASE,
    )
    made = re.compile(rf"\b([A-Za-z][A-Za-z]+)\s*\(make\s+{token}\)", re.IGNORECASE)
    chain_line = re.compile(r"\b(?:2nd|second)\s+ch\b|\beach\s+ch\b", re.IGNORECASE)
    chain_count = re.compile(rf"\bch\s+{token}\b", re.IGNORECASE)

    for raw in text.splitlines():
        if raw.lstrip().startswith(">") or _prohibition(raw):
            continue
        found = increase.search(raw)
        if found:
            left, right = as_int(found.group(2)), as_int(found.group(3))
            if found.group(1).lower() == "increase" and right <= left:
                errors.append(
                    f"Increase from {found.group(2)} to {found.group(3)} does not rise."
                )
            if found.group(1).lower() == "decrease" and right >= left:
                errors.append(
                    f"Decrease from {found.group(2)} to {found.group(3)} does not fall."
                )
        found = plus.search(raw)
        if found:
            base, remainder, count = (as_int(found.group(i)) for i in (1, 2, 3))
            if base > 0 and remainder < base and count % base != remainder:
                errors.append(
                    f"{found.group(3)} is not a multiple of {found.group(1)} plus {found.group(2)}."
                )
        elif (found := multiple.search(raw)):
            base, count = as_int(found.group(1)), as_int(found.group(2))
            if base > 0 and count % base:
                errors.append(f"{found.group(2)} is not divisible by {found.group(1)}.")
        found = parity.search(raw)
        if found:
            count = as_int(found.group(2))
            if found.group(1).lower() == "even" and count % 2:
                errors.append(
                    f"{found.group(2)} is odd, but the line says the count must be even."
                )
            if found.group(1).lower() == "odd" and count % 2 == 0:
                errors.append(
                    f"{found.group(2)} is even, but the line says the count must be odd."
                )
        found = apart.search(raw)
        if found and as_int(found.group(1)) >= as_int(found.group(2)):
            errors.append(
                f"Eyes {found.group(1)} stitches apart do not fit on a "
                f"{found.group(2)}-stitch round."
            )
        found = marker.search(raw)
        if found and as_int(found.group(1)) > as_int(found.group(2)):
            errors.append(
                f"Stitch {found.group(1)} is past a {found.group(2)}-stitch round."
            )
        found = skip.search(raw)
        if found and as_int(found.group(1)) >= as_int(found.group(2)):
            errors.append(
                f"Skip {found.group(1)} does not fit on a {found.group(2)}-stitch row."
            )
        for found in rounds.finditer(raw):
            if as_int(found.group(2)) > as_int(found.group(3)):
                label = "Rounds" if found.group(1).lower().startswith("round") else "Rows"
                errors.append(
                    f"{label} {found.group(2)}-{found.group(3)} run backwards."
                )
        found = inches.search(raw)
        if found and found.group(1).lower() == found.group(2).lower():
            errors.append(
                f"{found.group(1)} inches is not {found.group(2)} cm. "
                "The line copies the same number."
            )
        found = centimeters.search(raw)
        if found and found.group(1).lower() == found.group(2).lower():
            errors.append(
                f"{found.group(1)} cm is not {found.group(2)} inches. "
                "The line copies the same number."
            )
        found = hook_letter.search(raw)
        if found:
            label = found.group(1).upper().replace("/", "-")
            if label not in HOOKS:
                label = found.group(1).upper()
            nominal = HOOKS.get(label)
            if nominal is not None and abs(float(found.group(2)) - nominal) > HOOK_GAP:
                errors.append(
                    f"Hook {found.group(1)} is written as {found.group(2)} mm, "
                    f"but the Craft Yarn Council nominal size is {nominal:g} mm. "
                    "The gap is more than 1.5 mm."
                )
        found = turn.search(raw)
        if found:
            chains = as_int(found.group(1))
            stitch = found.group(2).lower()
            needed = TURN_MIN[stitch]
            if chains <= needed - 2:
                errors.append(
                    f"ch {chains} is too short to turn for a {stitch}. Use ch {needed}."
                )
        found = counts_as.search(raw)
        if found:
            shown = str(as_int(found.group(1)))
            pair = (shown, found.group(2).lower())
            if pair in COUNTS_AS:
                errors.append(f"ch {shown} cannot count as a {pair[1]}.")
        if zero_mm.search(raw):
            errors.append("A hook of 0 mm cannot make a stitch.")
        if huge_mm.search(raw):
            warnings.append(
                "A hook of 40 mm or more is past normal crochet. This is a warning."
            )
        found = written.search(raw)
        if found and as_int(found.group(1)) != as_int(found.group(2)):
            errors.append(
                f"Written count {found.group(2)} does not match the {found.group(1)}-stitch edge."
            )
        found = steel.search(raw)
        if found and as_int(found.group(1)) > as_int(found.group(2)):
            errors.append("A higher steel-hook number is smaller, not larger.")
        if reverse.search(raw):
            errors.append("Reverse single crochet is worked backward, not forward.")
        if spiral.search(raw):
            errors.append("A continuous spiral does not turn every round.")
        if fasten.search(raw):
            errors.append("Fasten off ends the yarn.")
        if chain_line.search(raw):
            chain = chain_count.search(raw)
            stated = _STATED.search(raw.strip())
            if chain and stated:
                length = as_int(chain.group(1))
                count = int(stated.group(1))
                second = re.search(r"\b(?:2nd|second)\s+ch\b", raw, re.IGNORECASE)
                limit = length - 1 if second else length
                if count > limit:
                    errors.append(
                        f"Chain of {length} cannot hold {count} stitches. "
                        f"The most this line can hold is {limit}."
                    )
    for section in _sections(text):
        listed = listed_eyes.findall(section)
        mounted = mounted_eyes.findall(section)
        if listed and mounted and as_int(listed[0]) != as_int(mounted[0]):
            errors.append(
                f"Eye count: materials list {as_int(listed[0])} safety eyes, "
                f"but the instructions place {as_int(mounted[0])}."
            )
        made_counts = {}
        for line in section.splitlines():
            match = made.search(line)
            if match:
                made_counts[match.group(1).lower()] = as_int(match.group(2))
        for line in section.splitlines():
            if line.lstrip().startswith(">") or _prohibition(line):
                continue
            for name, count in made_counts.items():
                found = re.search(rf"\b{token}\s+{name}s?\b", line, re.IGNORECASE)
                if found and as_int(found.group(1)) != count:
                    errors.append(
                        f"Make count: {name} is made {count} times, "
                        f"but the line uses {as_int(found.group(1))}."
                    )
    return _unique(errors), _unique(warnings)


def spoken_forms(text: str) -> tuple[list[str], list[str]]:
    """Accept the words zero and one, and a large hook, in any sentence."""
    errors: list[str] = []
    warnings: list[str] = []
    pairs = (
        (r"\bch(?:ains?)?\s+(?:of\s+)?(?:0|zero)\b", "ch 0 makes no chain."),
        (r"\bwork\s+(?:0|zero)\b", "Work 0 stitches does no work."),
        (r"\bskip\s+(?:0|zero)\b", "Skip 0 does not move the hook."),
        (r"\bdecrease\s+to\s+(?:0|zero)\s+stitches\b", "Decrease to 0 stitches leaves nothing to fasten."),
        (r"\buntil\s+(?:0|zero)\s+stitches\b", "Repeat until 0 stitches is not a workable stop."),
        (r"\bround\s+(?:0|zero)\b", "Round 0 is not a round. Start at Round 1."),
        (r"\brow\s+(?:0|zero)\b", "Row 0 is not a row. Start at Row 1."),
        (r"\bmarker in stitch\s+(?:0|zero)\b", "Stitch 0 does not exist. Place the marker in stitch 1 or later."),
        (r"\bgauge:\s*(?:0|zero)\s+sc\b", "A gauge of 0 sc is not a fabric."),
        (r"\b(?:0|zero)\s+inches\s+wide\b", "A finished width of 0 inches is not a piece."),
        (r"\bpicot of\s+(?:0|zero)\b", "A picot of 0 is not a picot."),
        (r"\bch-(?:0|zero)\s+sp\b", "A ch-0 space has no chains to work into."),
        (r"\bshell of\s+(?:1|one)\b", "A shell of 1 is not a shell. Use at least 3 stitches."),
        (r"\b(?:1|one)-dc cluster\b", "A 1-dc cluster is one stitch, not a cluster."),
        (r"\bbobble of\s+(?:1|one)\b", "A bobble of 1 has nothing to gather."),
        (r"\bpuff of\s+(?:1|one)\b", "A puff of 1 is not a puff."),
        (r"\bpopcorn of\s+(?:1|one)\b", "A popcorn of 1 cannot be closed."),
        (r"\byo\s+(?:0|zero)\b", "yo 0 does not put yarn on the hook."),
        (r"\bpull through\s+(?:0|zero)\s+loops\b", "Pull through 0 loops leaves the loops on the hook."),
        (r"\b(?:0|zero)\s+rows tall\b", "A piece that is 0 rows tall was not made."),
        (r"\b(?:0|zero)\s+rounds tall\b", "A piece that is 0 rounds tall was not made."),
        (r"\bmake\s+(?:0|zero)\b", "Make 0 asks for none of that piece."),
        (r"\bwork even for\s+(?:0|zero)\s+rows\b", "Work even for 0 rows does no work."),
        (r"\bplace\s+(?:0|zero)\s+safety eyes\b", "Place 0 safety eyes mounts nothing."),
        (r"\b(?:0|zero)\s+yards\b", "0 yards cannot make the piece."),
        (r"\bstuff with\s+(?:0|zero)\s+g\b", "Stuff with 0 g leaves the piece empty."),
        (r"\bevery\s+(?:0|zero)\s+(?:rows|rounds)\b", "Every 0 rows or rounds never happens."),
        (r"\bbullion of\s+(?:0|zero)\b", "A bullion of 0 wraps has no wraps."),
        (r"\bcable over\s+(?:0|zero)\s+stitches\b", "A cable over 0 stitches does not cross."),
        (r"\bfringe of\s+(?:0|zero)\b", "A fringe of 0 strands is not a fringe."),
        (r"\bbuttonhole of\s+(?:0|zero)\b", "A buttonhole of 0 chains has no opening."),
        (r"\bi-cord of\s+(?:0|zero)\b", "An i-cord of 0 stitches has no cord."),
        (r"\b(?:oval start with|square of|rectangle of|tube of|corner of)\s+(?:0|zero)\b", "A count of 0 does not make that shape."),
        (r"\bsolomon knot of\s+(?:0|zero)\b", "A Solomon knot of 0 is not a knot."),
        (r"\bsurface crochet of\s+(?:0|zero)\b", "Surface crochet of 0 chains draws no line."),
        (r"\bbead every\s+(?:0|zero)\b", "A bead every 0 stitches is never placed."),
        (r"\bstripe every\s+(?:0|zero)\b", "A stripe every 0 rounds never stripes."),
        (r"\b(?:pom-pom|tassel) of\s+(?:0|zero)\b", "A wrap count of 0 has nothing to tie."),
        (r"\bpineapple of\s+(?:0|zero)\b", "A pineapple of 0 is not a pineapple motif."),
        (r"\bspike stitch down\s+(?:0|zero)\b", "A spike stitch down 0 rows does not leave the row."),
        (r"\bloop stitch of\s+(?:0|zero)\b", "A loop stitch of 0 has no loop."),
        (
            r"\bhook\b[^.\n]{0,32}?(?<![\d.])\d+(?:\.\d+)?\s*centimeters?\b"
            r"|(?<![\d.])\d+(?:\.\d+)?\s*centimeters?\s+hook\b",
            "The hook is written in centimeters. Crochet hooks are written in millimeters.",
        ),
    )
    huge = re.compile(
        r"\bhook\b[^.\n]{0,32}?(?<![\d.])(?:[3-9]\d|\d{3,})(?:\.0+)?\s*mm\b"
        r"|(?<![\d.])(?:[3-9]\d|\d{3,})(?:\.0+)?\s*mm\b[^.\n]{0,16}?\bhook\b",
        re.IGNORECASE,
    )
    words = {
        "zero": 0, "one": 1, "two": 2, "three": 3, "four": 4, "five": 5,
        "six": 6, "seven": 7, "eight": 8, "nine": 9, "ten": 10, "eleven": 11,
        "twelve": 12, "thirteen": 13, "fourteen": 14, "fifteen": 15,
        "sixteen": 16, "eighteen": 18, "twenty": 20,
    }
    number = r"(?:\d+|" + "|".join(words) + r")"
    decrease = re.compile(
        rf"\b(?:decrease|dec)\s+({number})\s+times\s+(?:across|on)\s+({number})\s+stitches\b",
        re.IGNORECASE,
    )

    def as_int(token: str) -> int:
        token = token.lower()
        return words[token] if token in words else int(token)

    for raw in text.splitlines():
        if raw.lstrip().startswith(">") or _prohibition(raw):
            continue
        for pattern, message in pairs:
            if re.search(pattern, raw, re.IGNORECASE):
                errors.append(message)
        if huge.search(raw):
            warnings.append("A hook of 40 mm or more is past normal crochet. This is a warning.")
        found = decrease.search(raw)
        if found:
            times = as_int(found.group(1))
            incoming = as_int(found.group(2))
            used = times * 2
            if used != incoming:
                errors.append(
                    f"Decrease cover: dec x {times} uses {used} stitches, not {incoming}."
                )
    return _unique(errors), _unique(warnings)


def zero_words(text: str) -> list[str]:
    """Flag zero-work and centimeter-hook lines that are not the lesson sentence."""
    chain = re.compile(r"\bch(?:ains?)?\s+(?:of\s+)?(?:0|zero)\b", re.IGNORECASE)
    work = re.compile(r"\bwork\s+(?:0|zero)\b", re.IGNORECASE)
    skip = re.compile(r"\bskip\s+(?:0|zero)\b", re.IGNORECASE)
    hook_cm = re.compile(
        r"\bhook\b[^.\n]{0,32}?(?<![\d.])\d+(?:\.\d+)?\s*(?:cm|centimeters?)\b"
        r"|(?<![\d.])\d+(?:\.\d+)?\s*(?:cm|centimeters?)\s+hook\b",
        re.IGNORECASE,
    )
    errors = []
    for line in text.splitlines():
        if line.lstrip().startswith(">") or _prohibition(line):
            continue
        if chain.search(line):
            errors.append("ch 0 makes no chain.")
        if work.search(line):
            errors.append("Work 0 stitches does no work.")
        if skip.search(line):
            errors.append("Skip 0 does not move the hook.")
        if hook_cm.search(line):
            errors.append(
                "The hook is written in centimeters. "
                "Crochet hooks are written in millimeters."
            )
    return _unique(errors)


def zero_repeat(text: str) -> list[str]:
    """Flag a repeat of zero. It does no work."""
    errors = []
    for line in text.splitlines():
        if line.lstrip().startswith(">") or _prohibition(line):
            continue
        if re.search(r"\b(?:repeat|rep)\b[^.\n]{0,20}?[x×]\s*0\b|\b0\s+times\b|\bzero\s+times\b", line, re.IGNORECASE):
            errors.append("A repeat of zero does no work. Give the repeat a count above zero.")
    return _unique(errors)


def _sections(text: str) -> list[str]:
    parts = re.split(r"(?=^## )", text, flags=re.MULTILINE)
    return [part for part in parts if part.strip()]


def prose_frill(text: str) -> list[str]:

    """Warn when prose says one edge is worked more than 2.5 times full."""
    warnings = []
    for line in text.splitlines():
        if re.search(r"\bdo not\b|\bdon't\b", line, re.IGNORECASE):
            continue
        worked = re.search(
            r"\b(\d+)\s+stitches\s+worked\s+into\s+(\d+)\s+base\b",
            line,
            re.IGNORECASE,
        )
        if worked:
            made = int(worked.group(1))
            base = int(worked.group(2))
            if base > 0 and made / base > 2.5:
                warnings.append(
                    f"Prose frill: {made} stitches worked into {base} base stitches "
                    f"is {made / base:.1f}x full. Above 2.5x the edge bunches."
                )
        times = re.search(
            r"\b(\d+(?:\.\d+)?)\s+times\s+full\b",
            line,
            re.IGNORECASE,
        )
        if times and float(times.group(1)) > 2.5 and re.search(r"\bfrill\b", line, re.IGNORECASE):
            warnings.append(
                f"Prose frill: {float(times.group(1)):g} times full is above 2.5x. "
                "The edge will bunch."
            )
    return _unique(warnings)



def unverified_claims(text: str) -> list[str]:
    """Name written size, gauge, yarn, and fit claims that were not measured.

    These are warnings. No finished measurement is invented.
    """
    warnings = []
    size_label = re.compile(
        r"\b(?:finished\s+(?:size|diameter|width|length|height|dimensions)"
        r"|target\s+size|size\s+range)\b",
        re.IGNORECASE,
    )
    number_range = re.compile(
        r"\d+(?:\.\d+)?\s*(?:[–—-]|to)\s*\d{1,3}(?:,\d{3})?(?:\.\d+)?"
    )
    measured_sample = re.compile(
        r"completed sample|finished sample|measured from|measured on the finished"
        r"|blocked sample measured|tested sample",
        re.IGNORECASE,
    )
    if not measured_sample.search(text):
        for line in text.splitlines():
            if line.lstrip().startswith(">"):
                continue
            if size_label.search(line) and number_range.search(line):
                warnings.append(
                    "Finished size is a target range, not a measurement from a completed sample."
                )
                break
    if re.search(
        r"\bmatch\b.{0,48}\bgauge\b|\bgauge\b.{0,48}\bmatch\b"
        r"|\bcheck your gauge\b|\bstitch and round gauge\b",
        text,
        re.IGNORECASE,
    ) and not re.search(
        r"tested sample|swatch measured|measured swatch|sample result",
        text,
        re.IGNORECASE,
    ):
        warnings.append(
            "Gauge asks the maker to match stitch and round gauge, "
            "but no tested sample result is written."
        )
    yarn_range = re.compile(
        r"\d+(?:\.\d+)?\s*(?:[–—-]|to)\s*\d{1,3}(?:,\d{3})?(?:\.\d+)?\s*(?:g|grams|yards|yd)\b",
        re.IGNORECASE,
    )
    for line in text.splitlines():
        if line.lstrip().startswith(">") or not yarn_range.search(line):
            continue
        if re.search(r"\bweighed\b|\bmeasured\b", line, re.IGNORECASE):
            continue
        extra = ""
        if re.search(r"standard\s*/\s*large|standard or large", text, re.IGNORECASE) and not re.search(
            r"\bmini\b.{0,40}\d", text, re.IGNORECASE
        ):
            extra = " No measured mini-size quantity or colour split is written."
        warnings.append("Yarn quantity is a range, not a weighed amount." + extra)
        break
    for line in text.splitlines():
        if line.lstrip().startswith(">"):
            continue
        opening = re.search(r"\b(?:centre|center)?\s*opening\b|\btree stand\b", line, re.IGNORECASE)
        approx = re.search(r"\bapprox(?:imate(?:ly)?)?\b|\btarget\b", line, re.IGNORECASE)
        ranged = number_range.search(line) and re.search(r"\b(?:in|inch|inches|cm)\b", line, re.IGNORECASE)
        if (opening and (approx or ranged)) or re.search(r"\btree stand\b", line, re.IGNORECASE):
            warnings.append(
                "The opening is an approximate target. It was not checked against a finished stand."
            )
            break
    return _unique(warnings)


def gauge_band(text: str) -> list[str]:

    """Warn when a stated gauge is far outside the published crochet band."""
    weight = _weight(text)
    if weight is None:
        return []
    name, low, high = weight
    warnings = []
    for line in text.splitlines():
        match = re.search(
            r"\bgauge\b\s*:?\s*(\d+(?:\.\d+)?)\s*(?:sc|hdc|dc|tr|sts?|stitches)\b"
            r"[^.\n]{0,48}?(?:=|per)\s*4\s*(?:inches|in)\b",
            line,
            re.IGNORECASE,
        )
        if not match:
            continue
        stitches = float(match.group(1))
        if low * 0.5 <= stitches <= high * 2:
            continue
        warnings.append(
            f"Gauge {stitches:g} stitches per 4 inches is outside the "
            f"Craft Yarn Council crochet band for {name} ({low}-{high}). "
            "This is a published-range check, not a trained model."
        )
    return _unique(warnings)


def inspect_photo(
    path: str | None = None,
    confirmed_stitches: int | None = None,
    confirmed_rows: int | None = None,
) -> dict:
    """Record confirmed counts. The path is not opened and no count is invented."""
    del path
    if confirmed_stitches is None or confirmed_rows is None:
        return {
            "automatic_detection": False,
            "counts": None,
            "message": "A photo is not classified. A person must confirm the stitch and row counts.",
        }
    return {
        "automatic_detection": False,
        "counts": {"stitches": confirmed_stitches, "rows": confirmed_rows},
        "message": "Confirmed counts were recorded. The photo was not read for stitch type.",
    }


def read_chart_image() -> dict:
    """A chart picture is not detected. Written symbols are the chart stage."""
    return {
        "read": False,
        "message": "A chart image is not detected. Write the row, such as Chart row 1: X V X V (4).",
    }


def _pieces(text: str) -> list[tuple[str, str]]:
    pieces: list[tuple[str, list[str]]] = [("", [])]
    for line in text.splitlines():
        name = _piece_name(line)
        if name:
            pieces.append((name, []))
            continue
        pieces[-1][1].append(line)
    return [(name, "\n".join(lines)) for name, lines in pieces if name or any(line.strip() for line in lines)]


def _piece_names(text: str) -> list[str]:
    return [name for name in (_piece_name(line) for line in text.splitlines()) if name]


def _piece_name(line: str) -> str | None:
    stripped = re.sub(r"^#{1,6}\s+", "", line.strip())
    match = re.match(
        r"^([A-Za-z][A-Za-z0-9]*(?:\s+[A-Za-z][A-Za-z0-9]*){0,3})"
        r"(?:\s*\(make\s+\d+\))?\s*:?\s*$",
        stripped,
    )
    if not match:
        return None
    name = match.group(1).strip()
    if name.lower() in _META or name.lower() in {"round", "row", "rnd"}:
        return None
    return name


def _is_piece_line(line: str) -> bool:
    return _piece_name(line) is not None


def _declared_dialect(body: str) -> str | None:
    if re.search(r"\b(?:terms?\s*:\s*UK|UK\s+terms?|UK\s+terminology)\b", body, re.IGNORECASE):
        return "UK"
    if re.search(r"\b(?:terms?\s*:\s*US|US\s+terms?|US\s+terminology)\b", body, re.IGNORECASE):
        return "US"
    return None


def _terms(body: str, words: tuple[str, ...]) -> list[str]:
    found = []
    for line in body.splitlines():
        if re.search(r"\bdo not\b|\bdon't\b", line, re.IGNORECASE):
            continue
        if re.match(r"^[A-Za-z0-9-]+:\s+\S", line.strip()) and not _HEADER.match(line.strip()):
            continue
        for word in words:
            if re.search(rf"\b{word}\b", line, re.IGNORECASE) and word not in found:
                found.append(word)
    return found


def _weight(text: str):
    low = text.lower()
    if any(re.search(rf"\b{name}\b", low) for name in _NO_BAND) and not any(
        name in low for name, _band in _WEIGHTS
    ):
        return None
    found = []
    for name, band in _WEIGHTS:
        start = 0
        while True:
            at = low.find(name, start)
            if at < 0:
                break
            found.append((at, len(name), name, band))
            start = at + 1
    if not found:
        return None
    found.sort(key=lambda item: (-item[1], item[0]))
    chosen = []
    for at, length, name, band in found:
        if any(pos <= at and at + length <= pos + span for pos, span, _name, _band in chosen):
            continue
        chosen.append((at, length, name, band))
    chosen.sort()
    name, band = chosen[0][2], chosen[0][3]
    return name, band[0], band[1]


def _unique(items: list[str]) -> list[str]:
    found = []
    for item in items:
        if item not in found:
            found.append(item)
    return found
