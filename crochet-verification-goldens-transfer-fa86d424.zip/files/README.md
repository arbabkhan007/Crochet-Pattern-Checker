<div align="center">

# ðŸ§¶ Crochet Pattern Checker

**Deterministic crochet pattern verification, visualization & PDF publishing â€” no AI guesswork.**

Parse US rounds/rows, count every stitch, and catch contradictions before you hook a single loop.
Gauge, yarn, hooks, USâ†”UK conversion, diagrams, 3D simulation, and printable sheets included.

[![CI](https://github.com/arbabkhan007/Crochet-Pattern-Checker/actions/workflows/tests.yml/badge.svg)](https://github.com/arbabkhan007/Crochet-Pattern-Checker/actions/workflows/tests.yml)
[![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)](./LICENSE)
[![Python 3.10+](https://img.shields.io/badge/Python-3.10%2B-blue.svg)](./pyproject.toml)
[![Version](https://img.shields.io/badge/version-1.0.0-orange.svg)](./pyproject.toml)

**[Try the web app](#web-app)** Â· **[Quick start](#quick-start)** Â· **[API](#api)** Â· **[Commands](#commands)**

</div>

## âœ¨ Features

- âœ… **Stitch-count validation** â€” repeats, increases/decreases math, round order, chain length, seams, eye counts
- ðŸ“Š **Visualize** â€” 2D diagrams, stitch maps, assembly & geometry maps, 3D simulation (OBJ/glTF/SVG export)
- ðŸ“ **Gauge calculator** â€” swatch â†’ finished size (in/cm), stitches-for-size
- ðŸ§µ **Yarn & hooks** â€” yardage estimates, hook recommendations from Craft Yarn Council standards, WPI â†’ weight
- ðŸ”€ **US â†” UK converter** â€” word-boundary-safe terminology translation
- ðŸ“„ **Shareable HTML reports** â€” verdict, stitch-count ladder, findings; printable pattern sheets (WeasyPrint PDF)
- ðŸŒ **Web app + REST API** â€” FastAPI with CORS, OpenAPI docs at `/docs`, Docker one-command deploy
- ðŸ”’ **Deterministic & honest** â€” written counts only; estimates always name their assumptions. No photo counting, no invented sizes.

## ðŸš€ Quick start

```bash
git clone https://github.com/arbabkhan007/Crochet-Pattern-Checker.git
cd Crochet-Pattern-Checker
python -m pip install -e ".[dev]"

# Check a pattern (exit 1 on errors)
crochet-check check examples/amigurumi.txt

# Web app (UI + API)
crochet-check serve --port 8000
# â†’ http://localhost:8000  Â·  API docs at /docs

# Or with Docker
docker compose up --build
```

## ðŸŒ Web app

Tabs: **Check** Â· **Visualize** Â· **Gauge & Yarn** Â· **US â†” UK** Â· **Report** â€” dark-mode aware, responsive, no external assets.

## ðŸ”Œ API

| Endpoint | What it does |
|---|---|
| `POST /api/check` | Validate a pattern â†’ verdict, score, errors, warnings |
| `POST /api/render` Â· `/api/simulate` | Diagrams, stitch maps, 3D simulation |
| `POST /api/gauge` | Gauge swatch â†’ finished size (estimate) |
| `POST /api/chart` | Stitch-count ladder and silhouette from written counts |
| `POST /api/yarn` Â· `GET /api/hooks` | Yardage estimate Â· hook recommendation |
| `POST /api/convert` | US â†” UK terminology conversion |
| `POST /api/report` Â· `/api/pdf` | Shareable HTML report Â· printable sheet |
| `GET /api/health` Â· `/api/version` | Liveness & version |

## âŒ¨ï¸ Commands

| Command | What it does |
|---|---|
| `crochet-check check <file>` | Validate stitch counts (exit 1 on errors) |
| `crochet-check gauge -s 40 -r 40 --sts-per-4in 20 --rows-per-4in 20` | Finished size from a swatch |
| `crochet-check convert <file> --to us-to-uk` | Convert terminology |
| `crochet-check report <file> -o report.html` | Shareable HTML report |
| `crochet-check render` / `simulate` / `render-3d` | Diagrams, stitch maps, 3D meshes |
| `crochet-check measure` / `yarn-calc` / `progress` | Estimates & round checklist |
| `crochet-check pdf` / `diff` / `export` / `explain` / `standards` | Printable sheets, diffs, exports, reference |
| `crochet-check serve` | Web app + API |

---


Version 1.0.0. Repository: [arbabkhan007/Crochet-Pattern-Checker](https://github.com/arbabkhan007/Crochet-Pattern-Checker).

## What a result means

`CPC-RULESET-1` identifies the current deterministic rule set. JSON reports include structured findings with stable rule IDs, severities, locations, and source lines where available; legacy prose errors and warnings remain available. `NEEDS_REVIEW` means an explicit Row/Round body was not fully parsed. It is not a stitch-count error.

A large shaping step is a review warning, not a requirement to add a particular round or proof of fit. The small golden fixture set is provisional; independent craft review and broader real-pattern review remain pending.

`PASS` means the written checks that ran found no error and no warning. It does not mean a photo was counted, a chart image was read, or every English sentence was understood.

These engines are not run:

- a chart image detector
- a photo stitch classifier
- a hosted language model
- a support chat
- a cover image generator
- a vision training set
- a process cluster

Two assembly lines are read. They are still not a made piece and not a photo:

- `Cinch shut`, with no stitch count, closes the last stated round. It is an error when no counted round comes before it.
- `sew head to body` is a piece reference. It is an error when head or body never starts.

An instruction line the parser did not count is named under Not checked. It is not treated as a passed round.

A sew line that names a made piece but gives no number is named. The count is not guessed. A flatten line with fewer than two stitch counts is named. The seam is not compared.

A check is not a purchase. A photo was not opened, the piece was not made, and a gauge swatch was not measured.

A finished-size range, a request to match stitch and round gauge with no tested sample, a yarn range that was not weighed, and an approximate opening are warnings. The missing measurements are not invented.

A hook size of 0 mm is an error in any sentence. The line does not have to say `Hook: 0 mm`. A size such as 3.0 mm or 10 mm is not that error.

A chain of 0, work of zero stitches, a skip of zero, and a repeat of zero times are errors in any sentence. A hook size written in centimeters is an error in any sentence. These do not have to match one lesson line.

A hook of 40 mm or more is a warning in any sentence, not only after `Hook:`. Chain zero and work 0 are the same errors as `ch 0` and `work 0 stitches`. A hook size written as centimeters is the same error as cm.

The words zero and one are the same defects as 0 and 1 in those written checks. Decrease five times across eleven stitches is the same error as dec x 5 on 11 stitches.

Those arithmetic checks also accept the words twelve, six, and the other number words, and they do not have to be the first words of the line. A hook letter such as H/8 can be named in any sentence. A hook written as millimeters is the same size check as mm.

A line that starts with `>` is a quote. A line that says `do not` is a prohibition. Neither is treated as an instruction.

`Inc from 12 to 6`, `rnd 8 to rnd 5`, `colour A to colour A`, and `ch-1 counts as dc` are the same errors as the longer sentences. A line that says `or` is still a choice. No length is invented. This is not a physical proof, and it is not a reason to pay for a pattern.

`ch1, turn for dc`, `8in = 8cm`, and `H/8 = 2.25mm` are the same errors without the space. A real conversion such as `4 inches = 10.16 cm` is not that error. No length is invented.

`I-cord uses no stitch`, `cable crosses no stitch`, and `make none` are the same empty counts. `No stitches are left unworked` is not that error. No length is invented.

`Puff is one stitch`, `picot = 0`, and `round goes side to side` are the same written errors. `sc (UK double)` stays correct. No length is invented.

`Righties and lefties`, `Fsc and ch 12 to start`, and `increase shrinks, 12 to 6` are the same written rules. A line that says `or` stays a choice. No length is invented.

`I-cord of no stitches`, `round number 0`, and `repeat x zero` are the same empty counts. `No stitches are left unworked` is not that error. No length is invented.

`Cable that crosses nothing`, `yardage listed as nothing`, and `round numbered nothing` are the same empty counts. `Leave nothing unworked` is not that error. No length is invented.


`Inc that shrinks from 12 to 6`, `gauge of minus 1 sc`, and `colour B back to colour B` are the same written rules. A line that says `or` stays a choice. The kept scripts do not set a price, a score, or a gauge. No length is invented.

## Web companion (optional)

`web/studio/` is a browser companion for this checker: pattern library, row counter, PDF and web
import, a pattern canvas, courses, and a photo texture aid. It is built with React and TypeScript and
is separate from the Python package.

It does not change what this checker does. The studio calls `POST /api/check` and shows that verdict;
the Python engine still owns parsing, validation and measurement. The studio's own score is labelled
in its interface as a browser-side pre-check.

```bash
cd web/studio
npm install
npm run build
cd ../..
uvicorn crochet_checker.web.app:app --port 8000
```

Open `http://localhost:8000/studio/`. The root UI at `/` also includes the checker, visualization,
gauge/yarn, conversion, and report tools. Without a built `web/studio/dist`, only the `/studio` mount
is skipped; the root UI and API remain available.

The photo aid measures image texture and ranks stitches by fit. It is not a chart image detector and
it does not count a photo, so it does not change the non-goals listed above.

## Install

```bash
git clone https://github.com/arbabkhan007/Crochet-Pattern-Checker.git
cd Crochet-Pattern-Checker
python -m pip install -e ".[dev]"
```

PDF generation also needs WeasyPrint and its system libraries. The other checks do not.

## Check a pattern

```bash
crochet-check check examples/amigurumi.txt
```

A correct start for a 6-stitch sphere is:

```text
Round 1: 6 sc into magic ring (6)
Round 2: inc x 6 (12)
Round 3: (sc, inc) x 6 (18)
Round 4: (2 sc, inc) x 6 (24)
```

`Round 2: (sc, inc) x 6 (18)` after a 6-stitch round is an error. That round uses 12 stitches and more than doubles the count. It is not a valid example.

Exit status is 1 when the report has an error. Warnings do not change the exit status. `PASS_WITH_WARNINGS` is still a completed check.

## What the checker catches

On written US instructions it checks stitch counts, repeats, increases that more than double, decreases that miss their count, round order, dialect scope, a chain that is too short for the stated count, a missing repeat star, an eye count that disagrees with its materials line, a seam whose two stitch counts disagree, and an inch edge sewn to a much shorter edge. The lesson files under `consensus_lessons/` are the proofs: each wrong file is not clean, and each corrected file passes.

`docs/spec_gap.md` is the inventory. If this README and that file disagree, the file is the detailed list and this page is the contract.

## Commands that also exist

| Command | What it does | What it does not do |
|---|---|---|
| `crochet-check check` | Runs the written checker | Does not invent counts from a photo |
| `crochet-check render` | Writes 2D diagrams, a stitch map, a 3D stitch file, a stitch table, an assembly map, a geometry map, and a shape mesh | Does not read a chart image. Geometry is a stitch count, not a millimetre. The shape mesh does not track each loop |
| `crochet-check render-3d` | Writes the shape mesh, one point per written stitch, the 2D stitch map, the stitch table, the assembly map, and the geometry map | The shape mesh does not track each loop. Geometry is not a millimetre. A color comment is a written label, and an assembly line is not a stitch map |
| `crochet-check simulate` | Places one point per written stitch and writes the 2D map, 3D points, stitch table, assembly map, geometry map, and shape mesh. A color is shown only when the round names one color letter | Not a photo, not a measured size, not a guessed stitch join, and not an invented dye. Geometry is not a millimetre |
| `crochet-check measure` | Estimates measurements from the parsed piece and names the untested gauge | Does not replace a gauge swatch and does not invent a finished size |
| `crochet-check pdf` | Writes a printable sheet with template, page size, landscape, duplex facing pages, crop marks, PDF bookmarks, a count ladder, a text fingerprint, large print, ink saver, a binding margin, parsed-round charts, a written-stitch map, a written color key, count changes, round marks, and empty worked boxes. A .pdf path uses WeasyPrint when installed | Does not certify the pattern, read a chart image, invent a gauge, or change the check. The stitch map is not a measured size |
| `crochet-check explain` | Names the written result in words | Does not call a chat model, invent a finished size, or override the stitch count |
| `crochet-check yarn-calc` | Rough yardage estimate | Not weighed, not a finished size, and not a substitute for a measured swatch |
| `crochet-check progress` | Local round checklist | Not a validator |
| `crochet-check diff` | Compares the written stitch counts of two files | Does not call a count change a cone or a disk, and does not measure a shape |
| `crochet-check export` | Writes the existing stitch points as obj or gltf, the stitch map as svg, or the sheet as html | Does not write InDesign, does not use millimetres, and does not certify a print file |

## Examples

| File | Result |
|---|---|
| `examples/amigurumi.txt` | PASS |
| `examples/simple_hat.txt` | PASS |
| `examples/scarf.txt` | PASS |
| `examples/baby_booties.txt` | ERROR, 4 |
| `examples/intentionally_broken_pattern.txt` | ERROR, 3 |
| `examples/mini_sphere.txt` | ERROR, 4, plus 1 warning |

## Benchmarks that still report a finding

The three viewpoint files are kept as pasted. The checker is not edited to hide their findings.

- `docs/gemini_corrected.md`, whole file: `PASS_WITH_WARNINGS`. A short-row turn does not state the row-end stitches.
- `docs/chatgpt_corrected.md`, whole file: `ERROR`. A seam of 3 stitches cannot close 4 stitches.

Those are findings in the source text, not a failed install.

## Tests

```bash
python -m pytest tests/test_contract.py tests/test_stages.py tests/test_verdict.py tests/test_span.py tests/validation -q
python scripts/check_consensus.py
```

`tests/test_span.py` proves 5,000 impossible sentences. Those sentences are cases of the general checks. They are not 5,000 named engines.

## Published standards

Yarn weights 0-7, hooks, needles, steel pairs, and terms are in `docs/standards.md`.
Source: Craft Yarn Council's www.YarnStandards.com. Size 8 is announced and not numbered.
These tables do not change a check result.

## Not in this package

`experimental/` is not imported and is not part of this contract. A module that is not named on this page is not a feature of the checker.
