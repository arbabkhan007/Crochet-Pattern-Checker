# Codespaces transfer bundle — target-specific

Target branch: `crochet-verification-goldens`
Target base commit: `fa86d424a21e25232509234f50a0449e6fe204c0`.

This bundle is a selective port onto that exact branch. It preserves the branch's existing files and tests; do not use the older `crochet-verification-goldens-transfer.zip` patch or copy its files over this checkout. The patch excludes generated `docs/consensus.md`, the nested `Crochet-Pattern-Checker/` directory, cache/media assets, and unrelated files.

## Safe application

1. In Codespaces, run `git rev-parse HEAD` and `git status --short --branch`. Keep the nested directory and any other unrelated local changes unstaged.
2. Extract `changes.patch` outside the repository and run `git apply --check /tmp/changes.patch`. If it fails, stop; do not force it.
3. If the check succeeds, run `git apply /tmp/changes.patch`, inspect `git diff --stat` and `git diff`, then run:

   `python3 tools/run_tests_with_release_inputs.py tests/ -q --tb=short`

   `PYTHONPATH=src python3 scripts/check_consensus.py`

4. Review the regenerated `docs/consensus.md`; stage it only if its diff is expected. Stage only the selected intended paths, inspect the staged diff, and commit/push only after checks.

The golden manifest is provisional; independent craft review and broader real-pattern review remain pending. Fit, gauge, fullness, and safety are not certified. The two learning-pair cases previously noted still need review.

## Validation performed while preparing this bundle

- Focused branch-target tests: 44 passed.
- `scripts/check_consensus.py`: `CONSENSUS_OK` on a clean checkout of the target base after applying this port.
- The full release-input test suite was not rerun in this isolated sandbox because its Python environment lacks the Codespaces FastAPI dependency; rerun it in Codespaces after applying.
