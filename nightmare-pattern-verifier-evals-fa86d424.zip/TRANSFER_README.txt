Nightmare Pattern Verifier eval kit transfer
Base commit: fa86d424a21e25232509234f50a0449e6fe204c0
Patch SHA-256: 5f11b1598df513842fb4480e2f0da6165538f09ed1c24a9fa4dc0e1d04766c02

This addition-only patch adds the public eval kit under evals/. It contains no real fixtures, hidden answer rubric, raw responses, API keys, network client, or live-run results. It is not committed or pushed.

From the Codespaces repository root, after downloading this bundle:
  unzip -p nightmare-pattern-verifier-evals-fa86d424.zip changes.patch > /tmp/nightmare-evals.patch
  sha256sum /tmp/nightmare-evals.patch
  git apply --check /tmp/nightmare-evals.patch
  git apply /tmp/nightmare-evals.patch

The expected base is fa86d424a21e25232509234f50a0449e6fe204c0. The patch adds only new evals/ paths, so it can be applied after the reliability patch if evals/ is still absent. Stop if any check fails; do not force-apply. Review and test before staging. Do not add private fixtures or rubric files to the public repository.
