#!/usr/bin/env python3
"""Safely apply the reviewed media cleanup to the matching worktree.

This script only deletes exact paths whose size and SHA-256 match the bundled
manifest, then copies the reviewed README/updater/support files. It never stages,
commits, pushes, or touches the two protected untracked filenames.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import os
from pathlib import Path
import subprocess
import sys

EXPECTED_HEAD = "49d69daeb8d7a2462d5e5bef5394a4ff5d170a3b"
EXPECTED_BRANCH = "multi-ai-consensus"
PROTECTED = {"SHA256SUMS.txt", "multi-ai-consensus-upgrade.zip"}
TRACKED_PAYLOAD = {
    "novality_kits/README.md",
    "novality_kits/engine/update_readme.py",
}
NEW_PAYLOAD = {
    "novality_kits/external-media-manifest.json",
    "deliverables/README.txt",
    "final_patterns/christmas/etsy_listing_kit_from_collection.md",
}


def git(repo: Path, *args: str) -> bytes:
    cp = subprocess.run(
        ["git", *args], cwd=repo, stdout=subprocess.PIPE, stderr=subprocess.PIPE
    )
    if cp.returncode:
        raise RuntimeError(cp.stderr.decode("utf-8", "replace").strip() or "git command failed")
    return cp.stdout


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def safe_path(repo: Path, rel: str) -> Path:
    rel_path = Path(rel)
    if rel_path.is_absolute() or ".." in rel_path.parts or ".git" in rel_path.parts:
        raise ValueError(f"unsafe relative path: {rel}")
    target = repo / rel_path
    resolved = target.resolve(strict=False)
    if not resolved.is_relative_to(repo):
        raise ValueError(f"path escapes repository: {rel}")
    return target


def git_status(repo: Path) -> tuple[dict[str, str], set[str]]:
    raw = git(repo, "status", "--porcelain=v1", "-z", "--untracked-files=all")
    statuses: dict[str, str] = {}
    for rec in raw.split(b"\0"):
        if not rec:
            continue
        code = rec[:2].decode("ascii", "replace")
        path = rec[3:].decode("utf-8", "surrogateescape")
        statuses[path] = code
    tracked = {
        x.decode("utf-8", "surrogateescape")
        for x in git(repo, "ls-files", "-z").split(b"\0")
        if x
    }
    return statuses, tracked


def load_deletions(bundle: Path) -> list[dict[str, str]]:
    manifest = bundle / "approved-deletions.csv"
    with manifest.open(newline="", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))
    seen: set[str] = set()
    for row in rows:
        rel = row["path"]
        if rel in seen:
            raise RuntimeError(f"duplicate path in manifest: {rel}")
        seen.add(rel)
        if len(row["sha256"]) != 64:
            raise RuntimeError(f"missing SHA-256 in manifest for {rel}")
    if len(rows) != 648:
        raise RuntimeError(f"unexpected manifest row count: {len(rows)} (expected 648)")
    return rows


def load_payload(bundle: Path) -> dict[str, bytes]:
    payload_root = bundle / "payload"
    rels = TRACKED_PAYLOAD | NEW_PAYLOAD
    payload: dict[str, bytes] = {}
    for rel in sorted(rels):
        path = safe_path(payload_root, rel)
        if not path.is_file() or path.is_symlink():
            raise RuntimeError(f"bundle payload missing or unsafe: {rel}")
        payload[rel] = path.read_bytes()
    return payload


def preflight(repo: Path, bundle: Path, deletions: list[dict[str, str]], payload: dict[str, bytes]):
    head = git(repo, "rev-parse", "HEAD").decode().strip()
    branch = git(repo, "branch", "--show-current").decode().strip()
    if head != EXPECTED_HEAD:
        raise RuntimeError(f"HEAD mismatch: found {head}; expected {EXPECTED_HEAD}")
    if branch != EXPECTED_BRANCH:
        raise RuntimeError(f"branch mismatch: found {branch}; expected {EXPECTED_BRANCH}")

    statuses, tracked = git_status(repo)
    delete_by_path = {r["path"]: r for r in deletions}
    payload_hashes = {rel: sha256_bytes(data) for rel, data in payload.items()}
    plans: dict[str, str] = {}
    present_count = 0
    absent_count = 0

    # Validate every deletion candidate before making any changes.
    for row in deletions:
        rel = row["path"]
        path = safe_path(repo, rel)
        if Path(rel).name in PROTECTED:
            raise RuntimeError(f"protected file unexpectedly appears in deletion manifest: {rel}")
        expected_tracked = row["source_tracked"].lower() == "true"
        actual_tracked = rel in tracked
        if actual_tracked != expected_tracked:
            raise RuntimeError(f"tracked/index mismatch for {rel}: expected {expected_tracked}, found {actual_tracked}")
        code = statuses.get(rel, "")
        if path.exists():
            if path.is_symlink() or not path.is_file():
                raise RuntimeError(f"not a regular file: {rel}")
            if path.stat().st_size != int(row["size_bytes"]):
                raise RuntimeError(f"size mismatch for {rel}; refusing to delete")
            if sha256_file(path) != row["sha256"]:
                raise RuntimeError(f"SHA-256 mismatch for {rel}; refusing to delete")
            if code and code not in ("??",):
                raise RuntimeError(f"working-tree/index state is not clean for {rel}: {code!r}")
            if code == "??" and expected_tracked:
                raise RuntimeError(f"tracked candidate unexpectedly appears untracked: {rel}")
            if code == "??" and expected_tracked is False:
                pass
            plans[rel] = "delete"
            present_count += 1
        else:
            # Missing tracked files are allowed only as an already-applied, unstaged deletion.
            if expected_tracked and code not in (" D",):
                raise RuntimeError(f"tracked candidate is missing without an unstaged delete status: {rel} ({code!r})")
            if code == "??":
                raise RuntimeError(f"status says untracked but path is missing: {rel}")
            plans[rel] = "already absent"
            absent_count += 1

    # Allow only the two explicitly protected untracked files, candidate deletions,
    # and the exact reviewed payload files. Any other dirty state aborts the apply.
    allowed = set(delete_by_path) | set(payload)
    for rel, code in statuses.items():
        if rel in PROTECTED and code == "??":
            continue
        if rel in delete_by_path:
            row = delete_by_path[rel]
            path = safe_path(repo, rel)
            if code == " D" and not path.exists():
                continue
            if code == "??" and row["source_tracked"].lower() == "false" and path.is_file():
                continue
            if not code:
                continue
            raise RuntimeError(f"unexpected staged/dirty state for deletion candidate {rel}: {code!r}")
        if rel in TRACKED_PAYLOAD:
            if code not in ("", " M"):
                raise RuntimeError(f"unexpected staged state for reviewed file {rel}: {code!r}")
            target = safe_path(repo, rel)
            if not target.is_file() or target.is_symlink():
                raise RuntimeError(f"reviewed tracked file missing or unsafe: {rel}")
            current = target.read_bytes()
            if code == " M" and sha256_bytes(current) != payload_hashes[rel]:
                raise RuntimeError(f"modified tracked file has unexpected contents: {rel}")
            if code == "" and current != git(repo, "show", f"HEAD:{rel}") and current != payload[rel]:
                raise RuntimeError(f"tracked file differs from both base and reviewed payload: {rel}")
            continue
        if rel in NEW_PAYLOAD:
            if code not in ("", "??"):
                raise RuntimeError(f"unexpected staged state for new support file {rel}: {code!r}")
            target = safe_path(repo, rel)
            if target.exists():
                if target.is_symlink() or not target.is_file() or target.read_bytes() != payload[rel]:
                    raise RuntimeError(f"destination already exists with different contents: {rel}")
            continue
        raise RuntimeError(f"unrelated working-tree change found: {rel} ({code!r})")

    # Validate destinations which currently have no status entry too.
    for rel in TRACKED_PAYLOAD:
        target = safe_path(repo, rel)
        if not target.is_file() or target.is_symlink():
            raise RuntimeError(f"reviewed tracked file missing or unsafe: {rel}")
        current = target.read_bytes()
        base = git(repo, "show", f"HEAD:{rel}")
        if current not in (base, payload[rel]):
            raise RuntimeError(f"tracked file differs from both base and reviewed payload: {rel}")
    for rel in NEW_PAYLOAD:
        target = safe_path(repo, rel)
        if target.exists() and (target.is_symlink() or not target.is_file() or target.read_bytes() != payload[rel]):
            raise RuntimeError(f"destination already exists with different contents: {rel}")

    return plans, payload_hashes, present_count, absent_count


def main() -> int:
    parser = argparse.ArgumentParser(description="Apply the reviewed cleanup to the matching Git worktree.")
    parser.add_argument("--repo", required=True, help="path to the Codespaces repository")
    parser.add_argument("--apply", action="store_true", help="apply after full preflight; default is a dry run")
    args = parser.parse_args()
    repo = Path(args.repo).resolve(strict=True)
    if not (repo / ".git").exists():
        raise SystemExit("The --repo path is not a Git worktree root.")
    bundle = Path(__file__).resolve().parent
    deletions = load_deletions(bundle)
    payload = load_payload(bundle)
    plans, payload_hashes, present_count, absent_count = preflight(repo, bundle, deletions, payload)

    print(f"Preflight OK: {repo}")
    print(f"Base: {EXPECTED_BRANCH} at {EXPECTED_HEAD}")
    print(f"Deletion manifest: {len(deletions)} paths ({present_count} present, {absent_count} already absent)")
    print("Reviewed files to update: 2; support files to add: 3")
    print("Protected untracked files will be left alone: " + ", ".join(sorted(PROTECTED)))
    if not args.apply:
        print("DRY RUN ONLY. No files changed. Re-run with --apply to apply the reviewed transfer.")
        return 0

    # Write the reviewed text payload first; destinations were preflighted and will not be overwritten.
    for rel, data in payload.items():
        target = safe_path(repo, rel)
        if target.exists() and target.read_bytes() == data:
            continue
        target.parent.mkdir(parents=True, exist_ok=True)
        tmp = target.with_name(target.name + ".cleanup-transfer.tmp")
        if tmp.exists():
            raise RuntimeError(f"temporary destination already exists: {tmp}")
        tmp.write_bytes(data)
        os.replace(tmp, target)
        if target.read_bytes() != data:
            raise RuntimeError(f"payload verification failed after write: {rel}")

    deleted = 0
    already_absent = 0
    for row in deletions:
        rel = row["path"]
        target = safe_path(repo, rel)
        if not target.exists():
            already_absent += 1
            continue
        if target.is_symlink() or not target.is_file():
            raise RuntimeError(f"path changed during apply: {rel}")
        if target.stat().st_size != int(row["size_bytes"]) or sha256_file(target) != row["sha256"]:
            raise RuntimeError(f"content changed during apply; refusing to unlink: {rel}")
        target.unlink()
        deleted += 1

    # The protected filenames are never included in the deletion manifest or payload.
    report = bundle / "apply-result.txt"
    protected_state = {name: (repo / name).exists() for name in sorted(PROTECTED)}
    report.write_text(
        f"Applied {EXPECTED_BRANCH} cleanup to {repo}\n"
        f"Deleted {deleted} files; already absent {already_absent}; total manifest {len(deletions)}.\n"
        f"Protected files still present: {protected_state}\n"
        "No staging, commit, or push was performed.\n",
        encoding="utf-8",
    )
    print(f"Applied: deleted {deleted}; already absent {already_absent}. No stage/commit/push performed.")
    print(f"Protected files remain: {protected_state}")
    print(f"Apply record: {report}")
    print("Next, inspect git status and the staged diff before committing or pushing.")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(f"ABORTED: {exc}", file=sys.stderr)
        raise SystemExit(2)
