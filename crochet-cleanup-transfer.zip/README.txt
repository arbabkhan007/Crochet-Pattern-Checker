CROCHET CLEANUP TRANSFER — FOR CODESPACES

This package transfers the reviewed cleanup from the Arena-side worktree into a matching Codespaces checkout. It is gated to commit 49d69daeb8d7a2462d5e5bef5394a4ff5d170a3b on branch multi-ai-consensus.

The package does NOT stage, commit, or push. It removes only paths listed in approved-deletions.csv whose size and SHA-256 match, then copies two reviewed tracked text files and adds three support files. It never touches SHA256SUMS.txt or multi-ai-consensus-upgrade.zip.

1. Download this ZIP from the Arena file viewer and place it in Codespaces outside the repository, for example /tmp.
2. Extract it outside the repository, e.g.:

   mkdir -p /tmp/crochet-cleanup-transfer
   unzip /tmp/crochet-cleanup-transfer.zip -d /tmp/crochet-cleanup-transfer

3. From the Codespaces terminal, run a dry run (enter only the command, not the shell prompt):

   python3 /tmp/crochet-cleanup-transfer/apply_cleanup.py --repo /workspaces/Crochet-Pattern-Checker

   It must report that the base is 49d69daeb8d7a2462d5e5bef5394a4ff5d170a3b and that preflight is OK. If it aborts, do not force it; send the error output for review.

4. If the dry run matches the reviewed plan, apply it:

   python3 /tmp/crochet-cleanup-transfer/apply_cleanup.py --repo /workspaces/Crochet-Pattern-Checker --apply

   The script leaves the two protected untracked files untouched and performs no Git staging/commit/push.

5. Review the working tree, then stage only the intended changes:

   cd /workspaces/Crochet-Pattern-Checker
   git status --short
   git add -u
   git add novality_kits/external-media-manifest.json deliverables/README.txt final_patterns/christmas/etsy_listing_kit_from_collection.md
   git diff --cached --check
   git diff --cached --stat
   git diff --cached --name-status

   Confirm the protected files are still untracked and absent from the staged diff. Do NOT use git add -A.

6. Only after reviewing the staged diff, commit and push:

   git commit -m "Remove media and artifact files"
   git push origin multi-ai-consensus

The transfer has 648 deletion paths: the 124 previously approved M-001–M-124 paths plus 524 approved-clone artifact paths from the later broad cleanup. It also copies the reviewed README/updater and adds the manifest plus two preserved text files. The alternate local checkout is not included. No rebuild/test validation was passed after the source media/fonts/audio removals; media-dependent builds may fail.
