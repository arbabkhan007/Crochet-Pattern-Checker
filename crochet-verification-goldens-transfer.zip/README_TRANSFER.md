# Codespaces transfer bundle (review before applying)

Source checkout base: `1aa750b45d7fbe0c0b7e662d602e97da3315d0b2`. This bundle contains a curated set of files for the conservative repeat checks, structured findings, and provisional golden fixtures. It excludes the rest of the dirty workspace, including unrelated deletions and media/font cleanup.

## Safe use

1. In Codespaces, inspect `git rev-parse HEAD` and `git status --short`.
2. Copy `changes.patch` into the repository and run `git apply --check changes.patch`. This is a dry check. If it fails, do not force it; the two checkouts differ.
3. Only if the check succeeds, run `git apply changes.patch`, inspect `git diff`, and rerun tests. The patch intentionally omits generated `docs/consensus.md`; regenerate it with `PYTHONPATH=src python3 scripts/check_consensus.py`.
4. If the patch does not apply, use `files/` as a comparison source and merge file-by-file. Do not extract over the checkout blindly.

The Codespaces test run must use the external-input runner for NS01/release assets: `python3 tools/run_tests_with_release_inputs.py tests/ -q --tb=short`. Do not restore removed media or skip the QA/archive checks. The learning-pair gate still has two fixtures awaiting review.
