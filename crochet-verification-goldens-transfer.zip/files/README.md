# Crochet Pattern Checker

A deterministic checker for written crochet patterns. It parses US rounds and rows, counts the stitches, and reports contradictions. It does not decide those counts with a language model.

Version 1.0.0. Repository: [arbabkhan007/Crochet-Pattern-Checker](https://github.com/arbabkhan007/Crochet-Pattern-Checker).

## What a result means

`PASS` means the written checks that ran found no error and no warning. It does not mean a photo was counted, a chart image was read, or every English sentence was understood.

These engines are not run:

- a chart image detector
- a photo stitch classifier
- a hosted language model
- a vision training set
- a process cluster

Two assembly lines are read. They are still not a made piece and not a photo:

- `Cinch shut`, with no stitch count, closes the last stated round. It is an error when no counted round comes before it.
- `sew head to body` is a piece reference. It is an error when head or body never starts.

A line that starts with `>` is a quote. A line that says `do not` is a prohibition. Neither is treated as an instruction.

## Install

```bash
git clone https://github.com/arbabkhan007/Crochet-Pattern-Checker.git
cd Crochet-Pattern-Checker
python -m pip install -e ".[dev]"
```

PDF generation also needs WeasyPrint and its system libraries. The other checks do not.

## Check a pattern

```bash
crochet-check check examples/amigurumi.txt
```

A correct start for a 6-stitch sphere is:

```text
Round 1: 6 sc into magic ring (6)
Round 2: inc x 6 (12)
Round 3: (sc, inc) x 6 (18)
Round 4: (2 sc, inc) x 6 (24)
```

`Round 2: (sc, inc) x 6 (18)` after a 6-stitch round is an error because the repeat consumes 12 input stitches when only 6 were produced. The separate greater-than-2x count heuristic is a warning for review, not proof of an error.

Exit status is 1 when the report has an error. Warnings do not change the exit status. `PASS_WITH_WARNINGS` is still a completed check.

## What the checker catches

On written US instructions it checks stitch counts, repeats, decreases that miss their count, round order, dialect scope, a chain that is too short for the stated count, a missing repeat star, an eye count that disagrees with its materials line, and a seam whose two stitch counts disagree. Large count changes generate review warnings; a ratio alone does not prove an error. The synthetic lesson files under `consensus_lessons/` are regression probes, not independent craft review or proof of general coverage. A 12-to-24 shaping step is a warning, not a required correction.

`docs/spec_gap.md` is the inventory. If this README and that file disagree, the file is the detailed list and this page is the contract.

## Commands that also exist

| Command | What it does | What it does not do |
|---|---|---|
| `crochet-check check` | Runs the written checker | Does not invent counts from a photo |
| `crochet-check render` | Writes 2D SVG diagrams from parsed rounds | Does not read a chart image |
| `crochet-check render-3d` | Writes an OBJ mesh for a detected sphere, hat, tube, cone, or bowl | Does not track each loop |
| `crochet-check measure` | Estimates measurements from the parsed piece | Does not replace a gauge swatch |
| `crochet-check pdf` | Writes an HTML pattern sheet, and a PDF when WeasyPrint is installed | Does not certify the pattern |
| `crochet-check explain` | Rule-based explanation. `--ai` can call a configured provider | AI output cannot override the stitch count |
| `crochet-check image` | Writes a placeholder cover unless a provider is configured | Does not count stitches in the image |
| `crochet-check yarn-calc` | Rough yardage estimate | Not a substitute for a measured swatch |
| `crochet-check progress` | Local round checklist | Not a validator |

## Examples

| File | Result |
|---|---|
| `examples/amigurumi.txt` | PASS |
| `examples/simple_hat.txt` | PASS |
| `examples/scarf.txt` | PASS |
| `examples/baby_booties.txt` | ERROR, 4 |
| `examples/intentionally_broken_pattern.txt` | ERROR, 3 |
| `examples/mini_sphere.txt` | ERROR, 4, plus 1 warning |

## Benchmarks that still report a finding

The three viewpoint files are kept as pasted. The checker is not edited to hide their findings.

- `docs/gemini_corrected.md`, whole file: `NEEDS_REVIEW`. The parser does not fully analyze many row lines; a short-row warning also asks for the row-end count.
- `docs/chatgpt_corrected.md`, whole file: `ERROR`. A seam of 3 stitches cannot close 4 stitches.

Those are findings in the source text, not a failed install.

## Tests

```bash
python -m pytest tests/test_golden_fixtures.py tests/test_contract.py tests/test_stages.py tests/test_verdict.py tests/test_span.py tests/validation -q
python scripts/check_consensus.py
```

`tests/test_span.py` exercises 5,000 generated sentences. That is synthetic test coverage, not evidence of broad real-pattern performance or 5,000 separate rules. The provisional golden manifest is under `tests/golden_fixtures/`; its review status is documented there.

## Not in this package

`experimental/` is not imported and is not part of this contract. A module that is not named on this page is not a feature of the checker.
