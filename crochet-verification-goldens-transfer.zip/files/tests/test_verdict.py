from crochet_checker.verification import verify_pattern


def test_verdict_uses_the_real_checker_and_names_the_gaps():
    bad = "Round 1: (sc, dec) x 6 (12)\nRound 2: inc x 12 (24)\n"
    verdict = verify_pattern(bad)
    assert verdict.status == "PASS_WITH_WARNINGS"
    assert verdict.errors == []
    assert any("12 to 24 stitches doubles" in item for item in verdict.warnings)
    shape_finding = next(
        finding for finding in verdict.findings
        if finding["rule_id"] == "CPC.SHAPE.LARGE_STEP_REVIEW"
    )
    assert shape_finding["severity"] == "warning"
    assert shape_finding["location"] == "Round 2"
    assert shape_finding["source_line"] == "Round 2: inc x 12 (24)"
    assert (shape_finding["expected"], shape_finding["actual"]) == (12, 24)
    assert "text checker" in verdict.engines_ran
    assert "chart text" in verdict.engines_ran
    assert "chart image detector" in verdict.engines_skipped
    assert "photo stitch classifier" in verdict.engines_skipped
    assert "hosted language model" in verdict.engines_skipped

    good = (
        "Round 1: 6 sc into magic ring (6)\n"
        "Round 2: inc x 6 (12)\n"
        "Round 3: (sc, inc) x 6 (18)\n"
    )
    passed = verify_pattern(good)
    assert passed.status == "PASS"
    assert passed.engines_skipped == verdict.engines_skipped


def test_unparsed_round_is_review_needed_not_a_clean_pass():
    text = (
        "Round 1: 6 sc into magic ring (6)\n"
        "Round 2: puff stitch in each st around\n"
    )
    verdict = verify_pattern(text)

    assert verdict.status == "NEEDS_REVIEW"
    assert verdict.errors == []
    assert len(verdict.not_checked) == 1
    assert verdict.not_checked[0].startswith("Line 2:")
    assert "puff stitch" in verdict.not_checked[0]
    assert "row/round parser coverage" in verdict.engines_ran
    assert verdict.to_dict()["not_checked"] == verdict.not_checked
    assert verdict.to_dict()["ruleset_id"] == "CPC-RULESET-1"
    parser_finding = verdict.findings[0]
    assert parser_finding["rule_id"] == "CPC.PARSER.ROW_UNPARSED"
    assert parser_finding["severity"] == "review"
    assert parser_finding["location"] == "Line 2"
    assert parser_finding["source_line"] == text.splitlines()[1]

    from crochet_checker.validation.validator import validate_pattern

    report = validate_pattern(text)
    assert report.overall_status == "NEEDS_REVIEW"
    assert report.valid is False
    assert report.not_checked == verdict.not_checked
    assert report.to_dict()["not_checked"] == verdict.not_checked


def test_trailing_repeat_alternative_fails_closed_as_review():
    from crochet_checker.validation.validator import validate_pattern

    text = (
        "Round 1: 6 sc into magic ring (6)\n"
        "Round 2: (sc, inc) x 6 (18) or (sc, inc) x 3 (9)\n"
    )
    report = validate_pattern(text)
    assert report.overall_status == "NEEDS_REVIEW"
    assert not report.valid
    assert report.errors == []
    assert len(report.not_checked) == 1
    assert report.not_checked[0].startswith("Line 2:")
    assert "text after the repeat may be unparsed" in report.not_checked[0]
    finding = report.findings[0].to_dict()
    assert finding["rule_id"] == "CPC.PARSER.REPEAT_SUFFIX_UNPARSED"
    assert finding["severity"] == "review"
    assert finding["location"] == "Line 2"
    assert finding["source_line"] == text.splitlines()[1]

    verdict = verify_pattern(text)
    assert verdict.status == "NEEDS_REVIEW"
    assert verdict.errors == []
    assert verdict.findings[0]["rule_id"] == "CPC.PARSER.REPEAT_SUFFIX_UNPARSED"


def test_machine_findings_have_stable_ids_severity_and_source():
    import json

    from crochet_checker.validation.validator import validate_pattern

    text = (
        "Round 1: 6 sc into magic ring (6)\n"
        "Round 2: (sc, inc) x 6 (18)\n"
    )
    report = validate_pattern(text)
    findings = report.to_dict()["findings"]
    by_id = {finding["rule_id"]: finding for finding in findings}

    overconsume = by_id["CPC.STITCH.REPEAT_OVERCONSUMPTION"]
    assert overconsume["severity"] == "error"
    assert overconsume["location"] == "Line 2"
    assert overconsume["source_line"] == text.splitlines()[1]
    assert (overconsume["expected"], overconsume["actual"]) == (6, 12)

    increase = by_id["CPC.STITCH.LARGE_INCREASE_REVIEW"]
    assert increase["severity"] == "warning"
    assert increase["location"] == "Line 2"
    assert (increase["expected"], increase["actual"]) == (6, 18)
    json.dumps(report.to_dict())


def test_check_cli_json_fails_closed_for_unparsed_round(tmp_path):
    import json

    from click.testing import CliRunner

    from crochet_checker.cli import cli

    pattern_file = tmp_path / "unparsed-pattern.txt"
    pattern_file.write_text(
        "Round 1: 6 sc into magic ring (6)\n"
        "Round 2: puff stitch in each st around\n",
        encoding="utf-8",
    )
    result = CliRunner().invoke(cli, ["check", str(pattern_file), "--json"])

    assert result.exit_code == 1
    payload = json.loads(result.output)
    assert payload["overall_status"] == "NEEDS_REVIEW"
    assert payload["valid"] is False
    assert payload["not_checked"][0].startswith("Line 2:")
    assert payload["stitch_counts"]["Main"]["1"] == 6
    assert payload["findings"][0]["rule_id"] == "CPC.PARSER.ROW_UNPARSED"
    assert payload["findings"][0]["severity"] == "review"
