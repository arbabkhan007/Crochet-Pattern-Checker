"""Conservative parser-coverage notes for explicit row and round instructions.

This audit identifies row/round bodies the parser marks ambiguous or parses
with its generic fallback. It is not a claim that free-form prose, charts, or
photos have been fully analyzed.
"""

from __future__ import annotations

import re

from ..parser.grammar import is_row_header
from ..parser.normalizer import sanitize_pattern_text
from ..parser.parser import CrochetParser


SKIPPED = (
    "chart image detector",
    "photo stitch classifier",
    "hosted language model",
    "vision training set",
    "process cluster",
)


def skipped_line() -> str:
    return (
        "Not run: a chart image, a photo stitch count, a hosted model, "
        "a vision training set, and a process cluster."
    )


def has_unparsed_repeat_suffix(body: str) -> bool:
    """Detect a parsed-looking flat repeat followed by ignored text."""
    candidate = body.strip().rstrip(".").strip()
    stated = re.search(r"\s*\(\d+\)\s*$", candidate)
    if stated:
        candidate = candidate[: stated.start()].rstrip()

    flat = re.match(
        r"[\(\[][^()\[\]]+[\)\]]\s*[x×]\s*\d+",
        candidate,
        flags=re.IGNORECASE,
    )
    if flat and candidate[flat.end() :].strip():
        return True

    star = re.match(
        r"\*[^*]+\*\s*(?:rep(?:eat)?\s+)?"
        r"(?:\d+\s+times|[x×]\s*\d+)",
        candidate,
        flags=re.IGNORECASE,
    )
    return bool(star and candidate[star.end() :].strip())


def unread_notes(text: str) -> list[str]:
    """List explicit row/round lines that the stitch parser did not fully parse."""
    parser = CrochetParser()
    notes: list[str] = []

    for line_number, raw in enumerate(sanitize_pattern_text(text).splitlines(), 1):
        line = raw.strip()
        if not line or line.startswith(">") or line.startswith("```"):
            continue

        # Numbered instructions are sometimes formatted as Markdown bullets.
        candidate = line
        for marker in ("- ", "* ", "+ "):
            if candidate.startswith(marker):
                candidate = candidate[len(marker) :].strip()
                break

        is_header, _, _, body, _ = is_row_header(candidate)
        if not is_header:
            continue
        if not body.strip():
            notes.append(
                f"Line {line_number}: row/round header has no instruction body to verify."
            )
            continue

        try:
            instructions = parser._parse_instruction_text(body.strip(), line)
        except Exception:
            instructions = []

        not_fully_parsed = not instructions or any(
            instruction.is_ambiguous
            or bool(instruction.parse_warnings)
            for instruction in instructions
        )
        if not_fully_parsed:
            notes.append(
                f"Line {line_number}: parser could not fully interpret this "
                f"instruction; review manually: {line}"
            )
        elif (
            len(instructions) == 1
            and instructions[0].is_repeat_block
            and has_unparsed_repeat_suffix(body)
        ):
            notes.append(
                f"Line {line_number}: text after the repeat may be unparsed; "
                f"review manually: {line}"
            )

    return notes
