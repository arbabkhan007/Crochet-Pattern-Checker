NS01 and release-archive input support transfer

Purpose
Keep the approved media/font removals while making the four remaining full-suite failures reproducible on demand. This adds a SHA-256/size-pinned fetcher for two NS01 concept illustrations and 34 published release PDFs; it generates the two collection ZIPs in an external cache using the current Markdown masters. It changes the NS01 model and the archive tests to read from that cache, and changes the full-test GitHub Actions step to use the explicit runner.

No source images, release PDFs, ZIPs, generated media, or fonts are copied into the Git checkout. The NS01 resolution checks, concept-art identification, human-review HOLD, archive CRC checks, exact-member lists, and member byte-identity assertions remain intact. SHA256SUMS.txt is untouched. The installer does not stage, commit, push, or rewrite history.

Target checkout
/workspaces/Crochet-Pattern-Checker

Installation in Codespaces
1. Extract this ZIP to a temporary path, for example /tmp/crochet-ns01-release-input-support.
2. Run:
   python3 /tmp/crochet-ns01-release-input-support/apply_release_input_support.py --repo /workspaces/Crochet-Pattern-Checker
3. Review git status and the diff. The installer prints the actual branch and HEAD; it does not assume the unknown post-merge SHA.
4. Run the full suite with the explicit input flow:
   python3 tools/run_tests_with_release_inputs.py tests/ -q --tb=short

The first run fetches 36 files (19,074,465 bytes) from immutable commit 9dbdfab5cf05e68a2136897f9739a0d81cc54114 and verifies each file's SHA-256 and exact byte size. Collection ZIPs are generated under the external cache from the pinned PDFs and the checkout's current Markdown masters, then CRC- and byte-identity-checked. The full test runner passes CROCHET_RELEASE_INPUT_CACHE to pytest. The default cache is ~/.cache/crochet-pattern-checker/release-test-inputs/9dbdfab5cf05e68a2136897f9739a0d81cc54114; set CROCHET_RELEASE_INPUT_CACHE to override it.

To check without downloading:
   python3 tools/fetch_release_test_inputs.py --group all --dry-run

To prepare only (fetch inputs and build the archives without pytest):
   python3 tools/run_tests_with_release_inputs.py --prepare-only

The original input files were verified against GitHub's tree and raw contents at the pinned commit. The two NS01 concept images and all 34 release PDFs are unchanged in the public main snapshot 98b55efc6d98dffce3d43207616e7ec0a38e6bc3. The archives themselves are generated from current Markdown rather than fetched, so branch-specific Markdown changes remain byte-identical to the sources tested in that checkout.

The installer refuses staged changes in files it will patch and refuses conflicting existing support files. It adds four support files under tools/ and docs/, patches the NS01 asset root, the two archive test roots, and .github/workflows/tests.yml. It changes no media paths in the checkout.