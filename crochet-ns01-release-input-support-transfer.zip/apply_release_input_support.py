#!/usr/bin/env python3
"""Install the on-demand release-input test flow into an existing checkout.

The installer only writes the listed working-tree files. It never stages,
commits, pushes, restores media into the checkout, or changes SHA256SUMS.txt.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import subprocess
import tempfile
from pathlib import Path

PATCH_TARGETS = [
    ".github/workflows/tests.yml",
    "tools/ns01_pdf_model.py",
    "tests/validation/test_complete_collection_archive.py",
    "tests/validation/test_ns16_ns17_archive.py",
]

MODEL_ASSETS_OLD = '''HERO_ASSET = ROOT / "assets/patterns/ns01/hamish_cover_concept.png"
MATERIALS_ASSET = ROOT / "assets/patterns/ns01/hamish_materials_concept.png"'''
MODEL_ASSETS_NEW = '''# Optional external cache keeps reviewed image inputs out of the checkout.
RELEASE_INPUT_CACHE = os.environ.get("CROCHET_RELEASE_INPUT_CACHE")
ASSET_ROOT = (
    Path(RELEASE_INPUT_CACHE).expanduser().resolve()
    if RELEASE_INPUT_CACHE
    else ROOT
)
HERO_ASSET = ASSET_ROOT / "assets/patterns/ns01/hamish_cover_concept.png"
MATERIALS_ASSET = ASSET_ROOT / "assets/patterns/ns01/hamish_materials_concept.png"'''

ARCHIVE_ROOT_OLD = 'RELEASE = ROOT / "release"'
ARCHIVE_ROOT_NEW = '''RELEASE_INPUT_CACHE = Path(
    os.environ.get("CROCHET_RELEASE_INPUT_CACHE", ROOT)
).expanduser().resolve()
RELEASE = RELEASE_INPUT_CACHE / "release"'''

WORKFLOW_OLD = "      - run: python -m pytest tests/ -q --tb=short"
WORKFLOW_NEW = (
    "      - name: Run tests with checksum-pinned external release inputs\n"
    "        run: python tools/run_tests_with_release_inputs.py tests/ -q --tb=short"
)


def git(repo: Path, *args: str) -> str:
    result = subprocess.run(["git", *args], cwd=repo, text=True, capture_output=True)
    if result.returncode:
        raise RuntimeError(result.stderr.strip() or f"git {' '.join(args)} failed")
    return result.stdout.strip()


def replace_once(text: str, old: str, new: str, label: str, already: str) -> str:
    if already in text:
        return text
    count = text.count(old)
    if count != 1:
        raise RuntimeError(
            f"expected exactly one {label} anchor, found {count}; no files changed"
        )
    return text.replace(old, new, 1)


def patch_archive_test(path: Path) -> bytes:
    text = path.read_text(encoding="utf-8")
    marker = 'RELEASE_INPUT_CACHE = Path(\n    os.environ.get("CROCHET_RELEASE_INPUT_CACHE", ROOT)\n).expanduser().resolve()'
    if marker not in text:
        text = replace_once(
            text,
            "import zipfile\n",
            "import os\nimport zipfile\n",
            f"{path.name} os import",
            "import os\nimport zipfile\n",
        )
        text = replace_once(
            text,
            ARCHIVE_ROOT_OLD,
            ARCHIVE_ROOT_NEW,
            f"{path.name} external release root",
            marker,
        )
    return text.encode("utf-8")


def build_transforms(repo: Path) -> dict[Path, bytes]:
    results: dict[Path, bytes] = {}

    model_path = repo / "tools" / "ns01_pdf_model.py"
    text = model_path.read_text(encoding="utf-8")
    if "import os\n" not in text:
        text = replace_once(
            text,
            "import math\nimport re\n",
            "import math\nimport os\nimport re\n",
            "ns01_pdf_model.py os import",
            "import os\n",
        )
    text = replace_once(
        text,
        MODEL_ASSETS_OLD,
        MODEL_ASSETS_NEW,
        "ns01_pdf_model.py image-root block",
        "RELEASE_INPUT_CACHE = os.environ.get(\"CROCHET_RELEASE_INPUT_CACHE\")",
    )
    results[model_path] = text.encode("utf-8")

    for relative in (
        "tests/validation/test_complete_collection_archive.py",
        "tests/validation/test_ns16_ns17_archive.py",
    ):
        path = repo / relative
        results[path] = patch_archive_test(path)

    workflow = repo / ".github" / "workflows" / "tests.yml"
    text = workflow.read_text(encoding="utf-8")
    if "tools/run_tests_with_release_inputs.py" not in text:
        if not text.startswith("name: Tests"):
            raise RuntimeError("unexpected .github/workflows/tests.yml header; no files changed")
        text = replace_once(
            text,
            WORKFLOW_OLD,
            WORKFLOW_NEW,
            "tests workflow pytest command",
            "tools/run_tests_with_release_inputs.py",
        )
    results[workflow] = text.encode("utf-8")
    return results


def build_payload(payload_root: Path, repo: Path) -> dict[Path, bytes]:
    relative_paths = (
        Path("tools/fetch_release_test_inputs.py"),
        Path("tools/run_tests_with_release_inputs.py"),
        Path("tools/release-test-inputs-manifest.json"),
        Path("docs/RELEASE_TEST_INPUTS.md"),
    )
    payload: dict[Path, bytes] = {}
    for relative in relative_paths:
        source = payload_root / relative
        if not source.is_file():
            raise RuntimeError(f"transfer payload is incomplete: {source}")
        target = repo / relative
        data = source.read_bytes()
        if target.is_symlink():
            raise RuntimeError(f"refusing to write through an existing symlink: {target}")
        if target.exists() and hashlib.sha256(target.read_bytes()).digest() != hashlib.sha256(data).digest():
            raise RuntimeError(f"refusing to overwrite a different existing file: {target}")
        payload[target] = data

    try:
        manifest = json.loads(
            payload[repo / "tools" / "release-test-inputs-manifest.json"].decode("utf-8")
        )
        if (
            manifest.get("source", {}).get("commit")
            != "9dbdfab5cf05e68a2136897f9739a0d81cc54114"
            or len(manifest.get("files", [])) != 36
            or manifest.get("groups", {}).get("ns01-images", {}).get("count") != 2
            or manifest.get("groups", {}).get("release-pdfs", {}).get("count") != 34
        ):
            raise ValueError("unexpected pin or group counts")
    except Exception as exc:
        raise RuntimeError(f"invalid release-input manifest: {exc}") from exc
    return payload


def atomic_write_all(updates: dict[Path, bytes]) -> int:
    changed = {
        path: data
        for path, data in updates.items()
        if not path.is_file() or path.read_bytes() != data
    }
    originals: dict[Path, bytes | None] = {
        path: path.read_bytes() if path.is_file() else None for path in changed
    }
    try:
        for path, data in changed.items():
            path.parent.mkdir(parents=True, exist_ok=True)
            fd, temporary_name = tempfile.mkstemp(
                prefix=f".{path.name}.", suffix=".tmp", dir=path.parent
            )
            try:
                with os.fdopen(fd, "wb") as stream:
                    stream.write(data)
                os.replace(temporary_name, path)
            except Exception:
                try:
                    os.unlink(temporary_name)
                except FileNotFoundError:
                    pass
                raise
    except Exception:
        for path, original in originals.items():
            if original is None:
                try:
                    path.unlink()
                except FileNotFoundError:
                    pass
            else:
                path.write_bytes(original)
        raise
    return len(changed)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", required=True, type=Path, help="Codespaces checkout path")
    args = parser.parse_args()
    repo = args.repo.expanduser().resolve()
    if not repo.is_dir():
        raise SystemExit(f"repository directory not found: {repo}")
    if not (repo / "pyproject.toml").is_file() or not (repo / ".git").exists():
        raise SystemExit(f"not a Git repository checkout: {repo}")

    try:
        git_root = Path(git(repo, "rev-parse", "--show-toplevel")).resolve()
        if git_root != repo:
            raise RuntimeError(f"--repo must be the checkout root; Git root is {git_root}")
        branch = git(repo, "rev-parse", "--abbrev-ref", "HEAD")
        head = git(repo, "rev-parse", "HEAD")
        staged = subprocess.run(
            ["git", "diff", "--cached", "--quiet", "--", *PATCH_TARGETS],
            cwd=repo,
        ).returncode
        if staged == 1:
            raise RuntimeError(
                "one or more patch target files have staged changes; review/unstage those "
                "paths before installing"
            )
        if staged not in (0, 1):
            raise RuntimeError("could not inspect staged changes")

        payload_root = Path(__file__).resolve().parent / "payload"
        payload = build_payload(payload_root, repo)
        changes = build_transforms(repo)
        all_updates = {**changes, **payload}
        for path, data in all_updates.items():
            if path.suffix == ".py":
                compile(data.decode("utf-8"), str(path), "exec")
        json.loads(payload[repo / "tools" / "release-test-inputs-manifest.json"])

        updated = atomic_write_all(all_updates)
        print(f"Preflight OK: {repo}")
        print(f"Checkout: {branch} at {head}")
        print(f"Working-tree files written or updated: {updated}")
        print(
            "Added checksum-pinned external inputs and archive generation; patched the NS01 "
            "asset path, archive test roots, and Tests CI step."
        )
        print(
            "No media copied into the checkout; SHA256SUMS.txt untouched; no files staged, "
            "committed, or pushed."
        )
        return 0
    except Exception as exc:
        raise SystemExit(f"Preflight failed; no files changed: {exc}") from exc


if __name__ == "__main__":
    raise SystemExit(main())
