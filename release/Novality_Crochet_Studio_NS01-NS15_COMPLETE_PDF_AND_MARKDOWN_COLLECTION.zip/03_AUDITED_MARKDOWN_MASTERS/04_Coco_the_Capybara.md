# Coco the Capybara

> **No plastic eyes  ·  Intermediate  ·  2.5 - 3 hours**  —  Design Code NS 04

A low, round, bottom-heavy capybara with a blunt sewn-on muzzle, plump stuffed legs and a calm embroidered sleeping face. No safety eyes and no small plastic parts.

**FINISHED SIZE**  About 10.3 cm (4 in) tall standing on all four legs.  About 5 cm (2 in) wide at the widest part of the body.  Squat and bottom-heavy, standing on her feet rather than her belly.

---

## Safety — read this first

Coco has an embroidered face and no plastic eye components, removing that particular detachment hazard. The stuffed item still has a sewn-on muzzle and ears; check every seam and surrounding stitch by hand, especially after cleaning.

No finished Coco has been shown by Novality Store to comply with ASTM F963, EN 71 or another toy-safety regime. Do not infer age suitability from the embroidered face or describe a finished item as “baby-safe” or compliant. Calling it “decorative” does not replace classification based on intended and reasonably foreseeable use. Before supply, the finished-item maker or seller must determine all applicable assessment, testing, documentation, labelling and traceability duties in every destination market.

## Materials

- Main yarn: worsted weight (#4), warm brown, about 30 g. A smooth matte yarn shows the stitch texture best.
- Face yarn: worsted weight (#4), dark brown, about 5 g, for the closed eyes, nose and mouth. Use the same weight as the main yarn.
- Hook: 3.0 mm. The gauge is written for this hook.
- Eyes: none. The sleeping face is embroidered - no safety eyes.
- Also needed: polyester fiber filling about 5-8 g; yarn needle; stitch marker; pins. Pins matter: the muzzle and ears are pinned before sewing.

## Gauge & size

Gauge: 36 sc around measures about 52 mm in diameter when stuffed (4.5 mm per stitch, 4.3 mm per round). Check it on the body after Rnd 6 - a stuffed tube, not a flat swatch. If your 36 sts measure wider than 52 mm, crochet more tightly or go down a hook size; a loose gauge will show stuffing.

Finished size: about 10.3 cm (4 in) tall, 5 cm (2 in) wide.

## Abbreviations (US terms)

MR - magic ring  ·  ch - chain
sc - single crochet  ·  inc - increase (2 sc in one st)
invdec - invisible decrease  ·  sl st - slip stitch
st(s) - stitch(es)  ·  Rnd(s) - round(s)
FO - fasten off  ·  (n) - stitch count at round end

Work in a continuous spiral - do not join and do not chain 1 between rounds. Keep a marker in the first stitch of every round. Work every stitch through both loops unless a note says otherwise.

## Techniques used, in the order you will meet them

1. **The magic ring** - Every piece begins with a magic ring. Pull the tail tight once the first round is complete.

2. **Working in a spiral** - Keep a stitch marker in the first stitch of every round and move it up. There is no seam and no join to count from.

3. **The two-layer leg join** - This is the only fiddly step - worth practising once on a scrap magic ring. Hold a finished leg against the body with the pinched-flat top of the leg lying against the outside of the body. For each joining sc, insert the hook through one stitch on the front edge of the flattened leg top, the matching stitch on its back edge, AND the next body stitch, then complete one sc through all three layers. That paired leg edge and body anchor produce one body-round stitch, so every count in the body table stays correct. Pinch the leg top flat first - a round, un-pinched top will not lie against the curved body and the join will pucker. A 9-stitch leg top flattens to about 5 stitches across - pinch it down to a strip about 3 stitches wide and hold it while you join. The stitches you don't join bunch up inside, and that bunch makes the leg look plump rather than tubular.

## Notes

How the height adds up: the body (Rnd 1-20) is 20 rounds x 4.3 mm = 86 mm; the short 8/9-round legs lift the body about 17 mm off the table, for a total standing height of about 103 mm = 10.3 cm.

## Instructions

### 1. Legs - make 4

Stuff the lower half of each leg lightly, leaving the top loose. Back legs stop after Rnd 8; front legs work Rnd 9 too - they join one round higher and need to be one round longer so all four feet reach the table level.

| Rnd | Instruction | Sts | Note |
|---|---|---|---|
| R1 | 6 sc in MR | (6) | all four |
| R2 | [sc, inc] x 3 | (9) | all four |
| R3 | sc in each st around | (9) | all four |
| R4 | sc in each st around | (9) | all four |
| R5 | sc in each st around | (9) | all four |
| R6 | sc in each st around | (9) | all four |
| R7 | sc in each st around | (9) | all four |
| R8 | sc in each st around | (9) | BACK legs finish here |
| R9 | sc in each st around | (9) | FRONT legs only |

Finish: FO with a long tail; use it later to tack any tiny side gap left after the crocheted join. Before joining, pinch the whole 9-stitch top flat into a narrow strip about 3 stitches wide (see technique 3).

### 2. Ears (make 2) & muzzle (make 1)

#### Ears - make 2 (do not stuff)

| Rnd | Instruction | Sts | Note |
|---|---|---|---|
| R1 | 6 sc in MR | (6) | - |
| R2 | [sc, inc] x 3 | (9) | - |
| R3 | sc in each st around | (9) | - |
| R4 | sc in each st around | (9) | - |
| R5 | sc in each st around, then FO | (9) | - |

#### Muzzle - make 1 (stuff lightly)

| Rnd | Instruction | Sts | Note |
|---|---|---|---|
| R1 | 6 sc in MR | (6) | - |
| R2 | [sc, inc] x 3 | (9) | - |
| R3 | [2 sc, inc] x 3 | (12) | - |
| R4 | sc in each st around | (12) | - |
| R5 | sc in each st around, then FO | (12) | - |

Ears: FO with a long tail, do not stuff - a shallow cup. Muzzle: FO with a long tail and stuff lightly, just enough to hold a dome; it should sit proud of the head when sewn on.

### 3. Body & head - one piece

Both are 36 stitches around with only a shallow waist between them - that is what makes Coco read as one round blob rather than a snowman. The legs are joined low at Rnd 4-5 (see below).

| Rnd | Instruction | Sts | Note |
|---|---|---|---|
| R1 | 6 sc in MR | (6) | - |
| R2 | inc in each st around | (12) | - |
| R3 | [sc, inc] x 6 | (18) | - |
| R4 | join BL1: 3 sc, [sc, inc] x 3, join BL2: 3 sc, [sc, inc] x 3 | (24) | join the BACK legs |
| R5 | 1 sc, inc, 1 sc, inc, 1 sc, join FL1: 3 sc, [sc, inc] x 3, 1 sc, join FL2: 3 sc, 3 sc, inc, 2 sc | (30) | join the FRONT legs |
| R6 | [4 sc, inc] x 6 | (36) | full width - check gauge |
| R7 | sc in each st around | (36) | - |
| R8 | sc in each st around | (36) | - |
| R9 | sc in each st around | (36) | stuff the body FIRMLY |
| R10 | [7 sc, invdec] x 4 | (32) | shallow waist |
| R11 | [7 sc, inc] x 4 | (36) | head begins |
| R12 | sc in each st around | (36) | muzzle over R12 - R14 |
| R13 | sc in each st around | (36) | - |
| R14 | sc in each st around | (36) | eyes at R14 - R15 |
| R15 | sc in each st around | (36) | embroider eyes now; ears attach here later |
| R16 | [4 sc, invdec] x 6 | (30) | - |
| R17 | [3 sc, invdec] x 6 | (24) | stuff the head firmly |
| R18 | [2 sc, invdec] x 6 | (18) | - |
| R19 | [sc, invdec] x 6 | (12) | top up stuffing |
| R20 | invdec x 6 | (6) | - |

Immediately after Rnd 15, embroider both closed eyes as described under Finishing, knotting and burying the floss ends inside while the 36-stitch opening is clear. Then work Rnds 16-20, stuffing the head as directed. Cinch the remaining 6 stitches closed and weave the tail inside the body. Do not decrease the Rnd 10 waist further - a narrow neck cannot hold the head upright on this shape.

How the leg joins work: work Rnd 4 and Rnd 5 following the full written rounds below. Wherever a round says “join”, hold a pinched-flat leg against the body and work the next 3 sc through both flattened leg-edge layers AND the body together (technique 3). Those 3 sc still count as 3 stitches of the round, so the stitch totals do not change - Rnd 4 ends at 24, Rnd 5 at 30. The joined stitches are always plain single crochet - never work an increase through a leg.

Rnd 4 - the BACK legs (24 stitches): work the first 3 sc through a leg and the body together, then [sc, inc] x 3; work the next 3 sc through the second leg and the body together, then [sc, inc] x 3 to the end of the round.

Rnd 5 - the FRONT legs (30 stitches): work 1 sc, inc, 1 sc, inc, 1 sc (7 stitches made); join a leg over the next 3 sc; work [sc, inc] x 3 and 1 sc (10 stitches made); join the second leg over the next 3 sc; work 3 sc, inc, 2 sc to the end (7 stitches made). In the finished round that is 7 - 3 - 10 - 3 - 7 = 30, all six increases falling inside the plain runs. The 7-10-7 spacing centres each front leg between the two back legs.

Stitch arithmetic for both join rounds: each [sc, inc] x 3 block works into 6 stitches and makes 9 (sc in one stitch, then 2 sc - the increase - in the next, three times over). Rnd 4: worked = 3 + 6 + 3 + 6 = 18, using EVERY stitch of Rnd 3; made = 3 + 9 + 3 + 9 = 24. Rnd 5: worked = 5 + 3 + 7 + 3 + 6 = 24, using every stitch of Rnd 4; made = 7 + 3 + 10 + 3 + 7 = 30. The 3-sc join runs count once - each goes through the leg and the body in the same stitch.

Work the numbers exactly. If the front legs line up directly behind the back legs instead of between them, the footprint narrows and Coco tips. The correct spacing covers the deepest footprint this shape allows - about 65 mm across and 29 mm front to back. Hold the piece upside down and check all four legs sit square before you stuff the body.

The legs join low (Rnd 4-5) so every foot hangs about 17 mm below the body and Coco stands on her feet.

## Finishing & assembly

Muzzle: stuff lightly and pin it to the front of the head over Rnds 12-14. Sew about three quarters of the perimeter with matching brown, pause to adjust the stuffing, then embroider the nose and mouth on the established curve. Knot those embroidery ends inside the muzzle through the remaining opening, finish the seam, and bury the sewing tail in the body. It should sit proud of the head, not flush. Centring matters - the eyes are 6 stitches apart and a muzzle pinned even slightly off-centre crowds one eye.

Eyes: embroider - do not use safety eyes. Complete them immediately after Body Rnd 15, before the decreases and head stuffing. With dark brown, work a shallow downward arc about 3 stitches wide on each side across Rnds 14-15, 6 stitches apart, with a tiny tick angled down at each outer end. Knot and bury every floss end inside.

Nose & mouth: after three quarters of the stuffed muzzle is sewn on, work a small dark triangle at top centre, a short vertical line down from it, and a soft curved mouth to one side. Knot the ends inside through the open part of the seam, then finish sewing the muzzle.

Ears: pinch the base of each ear so it cups forward, then sew at Rnd 15, about 5 stitches apart, angled slightly outward. Rnd 15 is a full 36-st round, so this puts the ears on top of the head where a capybara's belong.

Legs: the 3-sc joins locked each leg's pinched top into the body round. Check that every pinched 3-stitch strip is caught fully in the round; if a sliver stays open at the side of a leg top, tack it shut with 2-3 whip stitches through all layers - it sits on the underbody and stays invisible.

Final shaping: roll the finished piece gently between your palms to settle the stuffing into a round, bottom-heavy shape.

Before you sew - lay every component out and check: 4 legs (2 back of 8 rounds, 2 front of 9), 2 ears, 1 muzzle, 1 body & head, closed at the crown. The sleeping face is all embroidery - closed-eye arcs, a small triangle nose and a soft curved mouth.

## Troubleshooting

- **Coco looks too tall.** Almost always too many plain rounds. Rnd 12-15 is the straight head section the face is positioned on; adding 'just one more' round turns the shape into a tower and moves the face.
- **Coco will not stand.** Check the join height, not the leg spacing. The legs belong on Rnd 4 and Rnd 5; joined any higher, they cannot clear the underside of the body and the belly rests on the table.
- **Coco tips forward or backward.** Most often the front legs are lined up behind the back legs instead of between them - the Rnd 5 spacing must be 7 sc, 10 sc, 7 sc. If still tipping, stuff the lower body more firmly and settle weight back over all four feet.
- **Rocks back, front feet in the air.** All four legs are the same length and they cannot be. Front legs join at Rnd 5 (21 mm up), back at Rnd 4 (17 mm up); work the front legs 9 rounds and the back legs 8.
- **The head flops back.** The Rnd 10 waist is deliberately shallow at 32 stitches - do not decrease it further. A narrow neck cannot hold the head upright.
- **Small hole where a leg meets the body.** You joined a flat, wide leg top instead of a pinched one. Flatten the whole 9-stitch top into a strip about 3 stitches wide before joining, so the un-joined stitches bunch up inside.
- **Muzzle looks flat / stuffing shows.** Stuff the muzzle just enough to hold a dome. If stuffing shows through the body, your gauge is too loose - 36 sts should measure 52 mm; crochet tighter or go down a hook size.

## Colorways

Classic warm brown  ·  Soft grey  ·  Sandy beige  ·  Cocoa

## Designer notes

- Why the legs join so low: back legs (8 rnd, ~34 mm) join at Rnd 4, only 17 mm above the base; front legs (9 rnd, ~39 mm) join at Rnd 5, 21 mm up. Different lengths, same result: every foot hangs about 17 mm below the body so all four land level. This is the most common failure on round-bodied animals.
- Bottom-heavy by design: stuff the lower body firmly and keep the shape squat. Coco is meant to be one continuous curve from base to crown - she stands on her feet, not her belly.

## Care

Follow the labels for every yarn and component used. Before publishing a care claim or supplying finished Cocos, clean and dry a complete sample by the proposed method, then remeasure it and inspect for dye transfer, fibre change, stuffing migration, distorted embroidery and opened seams. Until that sample test passes, recommend gentle surface cleaning with a damp cloth and drying flat away from heat. Check the muzzle, ears and leg joins again after cleaning.

## Terms of Use

### Copyright & ownership

This crochet pattern - including all instructions, stitch counts, photography and design elements - is the original work and intellectual property of Novality Store, designed by Novality Crochet Studio. Design Code NS 04.

© 2026 Novality Store. All rights reserved.

This pattern is licensed to the purchaser for personal use and for the small-batch sale of finished physical items under the terms below. You may not copy, redistribute, resell, share, translate, reproduce, or claim the pattern itself as your own. The pattern itself may not be uploaded, reproduced, or distributed in digital or printed form without permission from Novality Store.

### You may

Make as many finished Coco plushies as you like for yourself, gifts, or charity. Sell physical finished items made from this pattern in small batches, in shops, markets and online, provided credit is given to “Novality Store” (a link or tag is always appreciated).

### You may not

Do not resell, share, redistribute, translate, rewrite, publish or upload this digital PDF or its contents in any form. Do not alter, copy or recolor the pattern and claim it as your own. Do not use the Novality Store name, logo or photos in your own listings beyond crediting the pattern. Do not mass-produce finished items commercially without written permission.

### Safety reminder

No finished Coco has been shown by Novality Store to comply with ASTM F963, EN 71 or another toy-safety regime. An embroidered face removes plastic-eye components but is not proof of overall compliance. The finished-item maker or seller is responsible for applicable assessment, evidence, labelling and traceability before supply.

## Happy crocheting!

Tag your makes with **#NovalityStore** and **#CocoTheCapybara** - We love seeing your Cocos. Thank you for supporting an independent pattern designer.
