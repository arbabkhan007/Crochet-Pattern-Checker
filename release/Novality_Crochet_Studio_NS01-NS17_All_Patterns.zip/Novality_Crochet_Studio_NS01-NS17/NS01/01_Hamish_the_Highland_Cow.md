# Hamish the Highland Cow

> **US terms  ·  Intermediate  ·  6 - 8 hours**  —  Design Code NS 01

A shaggy, sturdy Highland cow with a flattened brow, a wide cream muzzle and a weather-beaten fringe. Worked in pieces so every proportion can be pinned and checked before sewing.

**FINISHED SIZE**  About 15 cm (6 in) sitting in worsted weight.  A 70 mm wide body and a 70 x 67 mm head.  A low, sprawling Highland sit.

---

## Safety — read this first

Hamish has two 12 mm safety eyes - small parts. Reach through the open head and lock the washers firmly from the inside BEFORE you stuff and close the head (Rnd 16) - once closed you cannot get back inside. Pull-test each eye. The horns, ears, muzzle, legs and tail are sewn on, and the fringe and tail are knotted yarn: sew every seam twice, weave ends in at least 5 cm, and knot the fringe and tail securely.

Not tested to ASTM F963 or EN 71 - do not describe finished Hamishes as “baby-safe”. For children under three, embroider the eyes with black floss instead of safety eyes.

## Materials

- Yarn A - Ginger: worsted / aran (#4), about 25 g used. Caramel, toffee or ginger gold. One 80 g / 150 m ball covers several cows and re-dos.
- Yarn B - Oat cream: worsted / aran (#4), about 12 g. Muzzle, horns, inner ears, optional belly patch.
- Yarn C - Dark chocolate: worsted / aran (#4), about 5 g. Hooves and nostrils.
- Yarn D - Rust (optional): about 6 g for the scarf, or 28 cm of 12 mm tartan ribbon.
- Hook: 3.5 mm (US E-4) - smaller than the ball band so stuffing cannot show.
- Eyes: 2 x 12 mm black safety eyes, or embroider for under-threes.
- Stuffing & notions: polyester fibre fill about 30 g (buy 50 g to over-stuff the base); stitch marker, tapestry needle, pins, scissors.

## Gauge & size

Gauge: 11 sc x 12 rounds = 5 cm / 2 in in Yarn A. Not critical, but loose tension lets stuffing show - drop half a millimetre if your fabric is gappy.

Finished size: about 15 cm / 6 in sitting.

## Abbreviations (US terms)

MR - magic ring  ·  ch - chain
sl st - slip stitch  ·  sc - single crochet
hdc - half double crochet  ·  inc - increase (2 sc in one st)
dec - invisible decrease  ·  BLO - back loop only
FO - fasten off  ·  (n) - stitch count at round end

Work in a continuous spiral unless a round says join. Mark the first stitch of every round. Leave 30-40 cm tails on every piece you will sew.

## Techniques used, in the order you will meet them

1. **The magic ring** - Wrap yarn around two fingers, insert the hook, pull up a loop and work the first round into the ring; pull the tail tight once the round is complete.

2. **Working in a spiral** - Do not join and do not chain 1 between rounds. Move the marker up each time - there is no join to count from.

3. **The invisible decrease** - Insert the hook through the FRONT loops only of the next two stitches, yarn over and pull through both, then yarn over and pull through the remaining two. Every dec is worked this way - no ridge on visible rounds.

4. **Back loop only (BLO)** - Work into the far loop only, leaving the near loop unused; the unused loops form a raised ridge. Hamish's hoof line is one BLO round.

5. **Working around a chain** - For the belly patch, crochet into both sides of a starting chain: across the front, corner increases into the last chain, then back along the opposite side - turning a chain into a flat oval.

6. **The lark's head knot** - Fold a strand in half, push the folded loop under a stitch with the hook, pull the two loose ends through the loop and cinch. Used for every fringe strand and the tail.

7. **Ladder stitch** - The invisible seam: out on one side, pick up one bar on the opposite side, then one bar back, alternating, pulling snug every few stitches. The head-to-body join needs two full passes.

## Instructions

### 1. Head - Yarn A

Worked from the crown down toward the neck. One straight round only - that is what keeps the brow flat and wide instead of egg-shaped. Close to 6 stitches at the end.

| Rnd | Instruction | Sts | Note |
|---|---|---|---|
| R1 | 6 sc in MR | (6) | - |
| R2 | inc in each st around | (12) | - |
| R3 | [sc, inc] x 6 | (18) | - |
| R4 | [2 sc, inc] x 6 | (24) | - |
| R5 | [3 sc, inc] x 6 | (30) | - |
| R6 | [4 sc, inc] x 6 | (36) | fringe row 3 |
| R7 | [5 sc, inc] x 6 | (42) | fringe row 2 / horns |
| R8 | [6 sc, inc] x 6 | (48) | fringe row 1 / ears |
| R9 | sc in each st around | (48) | eyes at R9 - R10 |
| R10 | [6 sc, dec] x 6 | (42) | - |
| R11 | [5 sc, dec] x 6 | (36) | - |
| R12 | [4 sc, dec] x 6 | (30) | lock eye washers, then stuff firmly |
| R13 | [3 sc, dec] x 6 | (24) | - |
| R14 | [2 sc, dec] x 6 | (18) | - |
| R15 | [sc, dec] x 6 | (12) | last pinch of stuffing |
| R16 | dec x 6 | (6) | close the hole |

Head finishing: after completing R16, fasten off and leave a sufficient yarn tail. Thread the tail through the front loops only of the remaining 6 stitches, pull tightly to close the opening, then secure the yarn with a small knot and weave the end inside the head.

Eyes & head size: the 12 mm eyes go in between Rnds 9 and 10, 7 stitches apart and a touch low on the face (7 sts is about 32 mm, just under half the head width). LOCK THE WASHERS at about Rnd 12, while you can still reach the inside: press each washer on until it clicks. The head stays open until Rnd 16 closes it - after that the washers are unreachable. Finished head about 70 mm wide x 67 mm tall.

### 2. Muzzle & nostrils - Yarn B

| Rnd | Instruction | Sts | Note |
|---|---|---|---|
| R1 | 6 sc in MR | (6) | - |
| R2 | inc in each st around | (12) | - |
| R3 | [sc, inc] x 6 | (18) | - |
| R4 | [2 sc, inc] x 6 | (24) | - |
| R5 | sc in each st around | (24) | face at full width, 35 mm |
| R6 | sc in each st around | (24) | - |
| R7 | sc in each st around | (24) | - |
| R8 | [2 sc, dec] x 6 | (18) | rim = 26 mm across |

Finish: FO with a 40 cm tail and stuff lightly. The muzzle FACE is about 35 mm across (the wide cream patch you see); the RIM it sews by is about 26 mm, spanning roughly six rounds of head. Pin the top edge just under the eyes at Rnd 10 and let the lower edge fall at Rnd 15-16 near the chin. Centre it, let the face sit a little wider than the eye spacing, and sew with small whip stitches, adding a whisper more stuffing before you close.

Nostrils (Yarn C): two short vertical satin stitches, 3 stitches apart, on the lower third. Mouth: one tiny horizontal stitch or a shallow V below them. (The eye washers were already locked before the head was closed at Rnd 16.)

The wide cream muzzle, low-set eyes and shaggy fringe give the Highland stare.

### 3. Body - Yarn A

Worked bottom up. The neck is left open at 18 stitches for the head join.

| Rnd | Instruction | Sts | Note |
|---|---|---|---|
| R1 | 6 sc in MR | (6) | - |
| R2 | inc in each st around | (12) | - |
| R3 | [sc, inc] x 6 | (18) | - |
| R4 | [2 sc, inc] x 6 | (24) | - |
| R5 | [3 sc, inc] x 6 | (30) | - |
| R6 | [4 sc, inc] x 6 | (36) | - |
| R7 | [5 sc, inc] x 6 | (42) | - |
| R8 | [6 sc, inc] x 6 | (48) | front legs join R8 - R9 |
| R9 | sc in each st around | (48) | - |
| R10 | sc in each st around | (48) | body at full width, 70 mm |
| R11 | sc in each st around | (48) | - |
| R12 | sc in each st around | (48) | - |
| R13 | sc in each st around | (48) | - |
| R14 | [6 sc, dec] x 6 | (42) | - |
| R15 | sc in each st around | (42) | - |
| R16 | [5 sc, dec] x 6 | (36) | - |
| R17 | [4 sc, dec] x 6 | (30) | stuff firmly, pack the base |
| R18 | [3 sc, dec] x 6 | (24) | - |
| R19 | [2 sc, dec] x 6 | (18) | leave neck OPEN |

Finish: FO with a 40 cm tail; do not close. Body is about 19 rounds (79 mm); with the head seated on the neck ring the finished sitting height is about 15 cm / 6 in.

### 4. Belly patch - Yarn B (optional)

A flat oval worked around a chain, sewn on last.

| Rnd | Instruction | Sts | Note |
|---|---|---|---|
| Foundation: | ch 9 | - | - |
| R1 | sc in 2nd ch, sc in next 6, 3 sc in last ch, sc in next 6, 2 sc in last loop | (18) | - |
| R2 | inc, 6 sc, inc x 3, 6 sc, inc x 2 | (24) | - |
| R3 | sc, inc, 6 sc, [sc, inc] x 3, 6 sc, [sc, inc] x 2 | (30) | - |
| R4 | 2 sc, inc, 6 sc, [2 sc, inc] x 3, 6 sc, [2 sc, inc] x 2 | (36) | - |

Sl st, FO with a long tail; sew centred on the front with the lower edge about 3 rounds up from the base. Skip it for a plain ginger front - both are correct.

### 5. Legs - start with Yarn C, change to Yarn A (make 4)

All four identical; the sitting pose comes from where and at what angle you sew them. Sixteen rounds = a 67 mm leg.

| Rnd | Instruction | Sts | Note |
|---|---|---|---|
| R1 | 6 sc in MR (Yarn C) | (6) | hoof |
| R2 | inc in each st around | (12) | - |
| R3 | [sc, inc] x 6 | (18) | - |
| R4 | sc in each st around | (18) | - |
| R5 | sc in each st around | (18) | - |
| R6 | BLO sc around | (18) | change to Yarn A - ridge |
| R7 | sc in each st around | (18) | - |
| R8 | [sc, dec] x 6 | (12) | stuff hoof firmly |
| R9 | sc in each st around | (12) | - |
| R10 | sc in each st around | (12) | - |
| R11 | sc in each st around | (12) | - |
| R12 | sc in each st around | (12) | - |
| R13 | sc in each st around | (12) | upper leg light |
| R14 | [2 sc, dec] x 3 | (9) | - |
| R15 | sc in each st around | (9) | - |
| R16 | sc in each st around | (9) | leave top open |

Standard leg finishing: after R16, fasten off and leave a 30-40 cm sewing tail. 
Do not close or flatten the opening - the 9-stitch top edge stays open so it can be sewn to the body. Stuff the hoof firmly, keep the upper leg lightly filled, and add only a small pinch near the top if needed so the opening remains easy to shape and attach.

Leg length - read before you sew. A 67 mm leg joins much lower than it is long, so it splays: front about 55 degrees from vertical, back about 68-70 degrees (near horizontal) - that is the low Highland sit. For a tidier upright sit, work the FRONT pair only to Rnd 10 (42 mm); leave the back pair at 16 rounds as haunches.

#### Shortened front legs - upright option only (make 2)

Short-front finish and placement: each leg measures 42 mm with a 12-stitch top opening. Stuff the hoof firmly, keep the final two rounds lightly filled, and FO after Rnd 10 with a 40 cm sewing tail; do not close or flatten the opening. 
Pin both front legs before sewing, centred across Body Rnds 8-9 and about 8 body stitches apart. Start each leg 25 degrees forward from vertical; mirror the pair and adjust only within 20-30 degrees until both hooves rest level. Sew all 12 opening stitches to the body, then make a second complete seam pass. Keep the standard 16-round back legs at 68-70 degrees from vertical.

### 6. Ears - make 2 of each layer

#### INNER ear - Yarn B (make 2) & OUTER ear - Yarn A (make 2)

| Rnd | Instruction | Sts | Note |
|---|---|---|---|
| R1 | 6 sc in MR | (6) | - |
| R2 | [sc, inc] x 3 | (9) | - |
| R3 | [2 sc, inc] x 3 | (12) | - |
| R4 | sc in each st around | (12) | - |
| R5 | sc in each st around | (12) | - |
| R6 | [2 sc, dec] x 3 | (9) | - |
| R7 | sc in each st around | (9) | - |

Work BOTH layers through all 7 rounds. FO the inner ear with a short tail; FO the outer with a long tail. Lay the inner on the outer, cream side facing you, and join them around the edge: either single crochet around the edge through both layers in Yarn A (about 1 sc per stitch, plus extras at the corners), or whip-stitch around with the outer's tail. Flatten and pinch the base with 2-3 stitches so the ear cups forward.

### 7. Horns - Yarn B (make 2)

| Rnd | Instruction | Sts | Note |
|---|---|---|---|
| R1 | 4 sc in MR | (4) | - |
| R2 | [sc, inc] x 2 | (6) | - |
| R3 | sc in each st around | (6) | - |
| R4 | sc in each st around | (6) | - |
| R5 | [2 sc, inc] x 2 | (8) | - |
| R6 | sc in each st around | (8) | - |
| R7 | sc in each st around | (8) | stuff tip only |

FO with a tail; stuff the tip only. Short and slightly curved - tilt each horn out and a little back when you sew.

### 8. Tail - Yarn A

Cut 6 strands of Yarn A, each 22 cm / 8.5 in. Fold the bundle in half and attach with a lark's head at the centre-back just above the last increase round: pull the folded loop through a stitch, then the tails through the loop. Folding gives 12 hanging ends; divide into 3 groups of 4, braid 4 cm, knot firmly and trim into a small tassel.

### 9. Fringe - Yarn A

Attach AFTER the horns and ears so you can part the hair around them. Cut 44 strands (includes 1 spare), each 14 cm / 5.5 in (swap 6 for Yarn C for depth). Attach with lark's head knots in a horseshoe from one ear, across the brow, to the other, filling three rows across the front of the head: every stitch along the front of Rnd 8 (24 knots), then every other stitch along the front of Rnd 7 (about 10 knots) and Rnd 6 (about 9 knots) - about 24 + 10 + 9 = 43 knots.

Tousle, then trim so the fringe grazes the eyes and breaks into uneven points. Highland hair is weather-beaten, not a salon fringe.

### 10. Tartan scarf - Yarn D (optional)

| Rnd | Instruction | Sts | Note |
|---|---|---|---|
| Foundation: | ch 61 | - | - |
| Row 1 | hdc in 2nd ch from hook and in each ch across | (60) | - |
| Row 2 | ch 2, turn, hdc across | (60) | turning ch does not count |

FO; add a 3-strand tassel at each end or weave a second colour as a slip-stitch stripe to hint at tartan, then tie loosely under the muzzle. Ribbon shortcut: 28 cm of 12 mm rust tartan ribbon, knotted once.

## Finishing & assembly

Assembly - work in this order:

1. Muzzle & face sewn (section 2) - the eye washers were locked before the head was closed at Rnd 16.

2. Horns between Rnds 5 and 7, 6 stitches apart, angled out and slightly back.

3. Ears just outside and below each horn, centred on Rnds 8-9, cupped forward.

4. Fringe attached and trimmed (section 9), parting around horns and ears.

5. Head to body: position the closed head over the open 18-st neck ring (Body Rnd 19). The head is closed at Rnd 16 (6 sts), but the attachment ring is the full 18-stitch round at Head Rnd 14. Match the 18 body Rnd-19 stitches one-for-one to the 18 head stitches of Rnd 14, forming a full circular seam around the nub; do not bunch all 18 neck stitches into the 6-stitch closure. Pin at four quarter points first (front, back, left, right), then fill in the remaining stitches so the head sits level. Pack the neck firmly. Using the body tail and ladder stitch, pass the needle under a stitch on the body opening, then under the corresponding stitch on Head Rnd 14, alternating around the full circle. Pull the seam snug every few stitches, check the head position, then ladder-stitch around TWICE for a reinforcing second pass. Weave the tail inside the body. Tilt the muzzle slightly down.

6. Back legs: lower sides across Rnds 3-6, almost on the base, splayed near horizontal.

7. Front legs: FRONT across Rnds 8-9, about 8 sts apart, angled forward about 55 degrees.

8. Belly patch - only if you made it.

9. Tail & scarf: attach the tassel tail, tie the scarf, weave in every end and fluff the fringe.

## Troubleshooting

- **He will not sit.** Restuff the body base firmly and sew the back legs lower and wider - closer to horizontal than you think.
- **Front hooves float.** Sewn too high - they belong on Rnds 8-9, not under the neck. If they still float, the legs are too long: work the front pair to Rnd 10.
- **Stuffing shows.** Drop half a hook size, or hold a matching thread with the yarn on visible rounds.
- **Face looks blank.** The eyes are too high. Low eyes plus a wide muzzle is the Highland stare.
- **Fringe is sparse.** Add a fourth row behind the horns and mix in one darker shade.
- **Horns flop.** Under-stuffed at the tip, or sewn only at the edge - stitch a full round into the head fabric.
- **Head tips forward.** The neck ring grips the head only about 8 mm up. Pack the neck before closing and make the second ladder-stitch pass tight.

## Colourways

Ginger  ·  Caramel  ·  Highland black  ·  Cream  ·  Roan red

## Three sizes, one pattern

The stitch counts are unchanged across all three versions; yarn weight, hook size, eye size and stuffing quantity change. The heights below are **estimated targets - not physically tested**. No physical sample was made for the Wee or Cuddle version in this pass; actual finished size depends on yarn thickness, hook, individual tension and stuffing density.

| Version | Yarn / hook | Eyes | Estimated height* |
|---|---|---|---|
| Wee Hamish | DK / #3 - 2.75 mm | 8-9 mm | ~12 cm |
| Classic Hamish | Worsted / #4 - 3.5 mm | 12 mm | ~15 cm |
| Cuddle Hamish | Bulky chenille / #5 - 5.0 mm | 16-18 mm | ~21 cm |

\*Estimated from yarn/hook scaling of the Classic pattern. No physical sample has been made and measured for Wee Hamish or Cuddle Hamish as part of this pattern release. Work a gauge swatch, measure your own tension, and expect variation. Yarn usage scales roughly with the square of height and stuffing with the cube - buy generously for larger versions.

## Designer notes

- Why the legs join so low: back legs (16 rnd, 67 mm, sewn to Rnds 3-6) and front legs (sewn to Rnds 8-9) splay at the checked angles so all four hooves land level. This low join is the most common failure on sitting Highland cows.
- Bottom-heavy by design: stuff the lower body firmly and keep the shape squat. Hamish is meant to settle onto his base and stare.

## Care

Follow the labels for every yarn and component used. Before publishing a care claim or supplying finished Hamishes, clean and dry a complete sample by the proposed method, then remeasure it and inspect for dye transfer, fibre change, stuffing migration, loosened fringe, shifted eyes and opened seams. Until that sample test passes, recommend gentle surface cleaning with a damp cloth and drying flat away from heat. Check all eyes, knots and attachments again after cleaning.

## Terms of Use

### Copyright & ownership

This crochet pattern - including all instructions, stitch counts, editorial layout and design elements - is the original work and intellectual property of Novality Crochet Studio. Design Code NS 01.

© 2026 Novality Crochet Studio. All rights reserved.

This pattern is for personal use only. You may sell finished items made from this pattern, but you may not copy, redistribute, resell, share, translate, reproduce, or claim this pattern as your own. The pattern itself may not be uploaded, reproduced, or distributed in digital or printed form without permission from Novality Crochet Studio.

### You may

Make as many finished Hamishes as you like for yourself, gifts, or charity. Sell physical finished items made from this pattern in small batches, in shops, markets and online, provided credit is given to “Novality Crochet Studio”.

### You may not

Do not resell, share, redistribute, translate, rewrite, publish or upload this digital PDF or its contents in any form. Do not alter, copy or recolor the pattern and claim it as your own. Do not use the Novality Crochet Studio name, logo or photos beyond crediting the pattern. Do not mass-produce finished items commercially without written permission.

### Safety reminder

This pattern has not been tested to a toy-safety standard (ASTM F963 / EN 71) and uses 12 mm safety eyes and knotted yarn fringe. Finished items made for sale must be assessed by the seller against local toy-safety laws; for young children, embroider the eyes and secure every seam and knot.

## Happy crocheting!

Tag your makes with **#NovalityCrochetStudio** and **#HamishTheHighlandCow** - We love seeing your coos. Thank you for supporting an independent pattern designer.
