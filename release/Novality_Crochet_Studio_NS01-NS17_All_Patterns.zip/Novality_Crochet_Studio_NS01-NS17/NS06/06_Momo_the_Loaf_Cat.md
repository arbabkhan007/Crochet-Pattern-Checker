# Momo the Loaf Cat

> **No-sew body  ·  Advanced beginner  ·  2 - 2.5 hours**  —  Design Code NS 06

A cat folded into a perfect loaf. One no-sew piece on an oval base - ears crocheted onto the head and the tail worked off the body, so nothing is sewn on.

**FINISHED SIZE**  About 7.9 cm (3.1 in) long, 5.2 cm (2 in) wide and 4.3 cm (1.7 in) tall.  A low, wide loaf, wider than it is tall (about 1.2 : 1).

---

## Safety — read this first

Momo has two 8 mm safety eyes - small parts. Lock the washers firmly from the inside and pull-test each eye. Embroidering the eyes is safer, but it does not make Momo a tested toy: not tested to ASTM F963 or EN 71, so do not describe finished Momos as “baby-safe”. For a child under three, embroider and say “embroidered, no small parts”.

The ears and tail are worked into the body (stronger than sewing), but still weave every end in at least 5 cm and knot the embroidery floss inside.

## Materials

- Main yarn: worsted #4, about 10 g. Grey, ginger, cream or black - all sell equally well. One 25 g ball makes two.
- Contrast: small amounts of white for the chest and paws, pink for the nose and inner ears.
- Hook: 3.5 mm (US E-4) - tight gauge so stuffing cannot show.
- Eyes: 2 x 8 mm safety eyes, or embroider in black.
- Also needed: polyfill about 10 g; tapestry needle; stitch marker; black embroidery floss.

## Gauge & size

Gauge: about 4.5 mm per stitch and 4.3 mm per round. Finished size about 7.9 cm long, 5.2 cm wide and 4.3 cm tall - a low, wide loaf. The 48-stitch oval base sets the whole size of the cat.

## Abbreviations (US terms)

MR - magic ring  ·  ch - chain
sc - single crochet  ·  inc - increase (2 sc in one st)
dec - invisible decrease  ·  sl st - slip stitch
BLO - back loop only  ·  FO - fasten off
(n) - stitch count

Work in a continuous spiral unless a piece says otherwise - no joins, no chain 1 between rounds; move the marker up each round.

## Techniques used, in the order you will meet them

1. **Around a chain (oval base)** - THE step that makes the loaf. Crochet into BOTH sides of a starting chain: across the front, corner increases into the last chain, then back along the opposite side and into the last loop. That turns a chain into a flat oval instead of a strip. Do NOT use a magic-ring circle here - a round base gives a sphere every time.

2. **The magic ring** - Used for the tail's first stitches. Wrap yarn around two fingers, pull up a loop and work the round into the ring, then pull the tail tight.

3. **Working in a spiral** - No joins and no chain 1 between rounds; move the marker up each round - there is no join to count from.

4. **Back loop only (BLO)** - Work into the far loop only; the unused loops form a raised ridge - the visible edge where the oval base meets the walls. That ridge is what makes the loaf read as folded rather than moulded.

5. **The invisible decrease** - Front loops only of the next two stitches, yarn over and pull through both, then yarn over and pull through the remaining two. Every dec here is worked this way.

6. **Flat rows (ch 1, turn)** - The ears are not worked in the round: chain 1, turn, and work back along the row. Each row is shorter than the one before, forming the ear point.

7. **Working into body fabric** - The tail starts by pushing the hook through the finished body wall - go under a WHOLE stitch, not just one loop, or it will pull out.

## Instructions

### 1. Body - one no-sew piece

The base is worked up to 48 stitches before the walls begin; the base size sets the whole cat. Stopping at 36 gives a body about 34 mm across that comes out tall and round no matter how you stuff it.

| Rnd | Instruction | Sts | Note |
|---|---|---|---|
| Found. | ch 9 | - | - |
| R1 | sc in 2nd ch, sc in next 6, 3 sc in last ch, sc in next 6, 2 sc in last loop | (18) | around both sides of chain |
| R2 | inc, 6 sc, inc x 3, 6 sc, inc x 2 | (24) | - |
| R3 | sc, inc, 6 sc, [sc, inc] x 3, 6 sc, [sc, inc] x 2 | (30) | - |
| R4 | 2 sc, inc, 6 sc, [2 sc, inc] x 3, 6 sc, [2 sc, inc] x 2 | (36) | - |
| R5 | 3 sc, inc, 6 sc, [3 sc, inc] x 3, 6 sc, [3 sc, inc] x 2 | (42) | - |
| R6 | 4 sc, inc, 6 sc, [4 sc, inc] x 3, 6 sc, [4 sc, inc] x 2 | (48) | BASE AT FULL SIZE |
| R7 | BLO sc around | (48) | ridge = base edge |
| R8 | sc in each st around | (48) | eyes at R8 - R9 |
| R9 | sc in each st around | (48) | stuff firmly from here |
| R10 | [6 sc, dec] x 6 | (42) | - |
| R11 | [5 sc, dec] x 6 | (36) | - |
| R12 | [4 sc, dec] x 6 | (30) | ears worked onto R12 |
| R13 | [3 sc, dec] x 6 | (24) | - |
| R14 | [2 sc, dec] x 6 | (18) | - |
| R15 | [sc, dec] x 6 | (12) | top up stuffing |
| R16 | dec x 6 | (6) | close via front loops |

Finish: thread the tail through the front loop of each of the 6 remaining stitches, pull tight, knot and bury. Shape check: the base is an oval about 79 mm long and 52 mm across; the walls add ten rounds of height, so the finished loaf is about 43 mm tall - wider than it is tall.

### 2. Ears - worked onto the head (make 2)

Join the main yarn to the head at Rnd 12, leaving about 6 stitches between the two ears, and work each ear as three short rows:

| Rnd | Instruction | Sts | Note |
|---|---|---|---|
| Row 1 | sc in next 5, ch 1, turn | (5) | - |
| Row 2 | dec, sc, dec, ch 1, turn | (3) | - |
| Row 3 | dec, sc | (2) | the ear tip |

The row maths: Row 1 makes 5 stitches; Row 2 works dec, sc, dec (consumes 5, makes 3); Row 3 works dec, sc (consumes 3, makes 2) - those 2 stitches form the tip.

After Row 3, do NOT try to slip-stitch from the ear tip back to the head. Work 1 sl st into the next head stitch to anchor the ear flat, then FO with a short tail; pull it through the 2 tip stitches to close the point and bury inside the head. Embroider a small pink triangle on the front of each ear for lining.

### 3. Tail - worked off the body

Join the main yarn to the back of the body at about Rnd 9 on the centre line. Insert the hook under a whole body stitch, pull up a loop, and work the first 4 sc into the body fabric in a tight square; then continue in a normal spiral off those 4 stitches: Rnds 1-8 are 4 sc in each round. do not make a magic ring - the body fabric provides the tail's starting stitches. Do NOT stuff - a thin tail curls around the loaf far better than a stuffed one. FO and bury.

## Finishing & assembly

Face & markings:

Eyes: fix the 8 mm eyes between Rnds 8 and 9, about 7 stitches apart, LOW and wide on the front (7 sts is about 32 mm, roughly 60% of the body width). Low eyes read as a cat; high eyes read as a bear. Push the stems through and LOCK the washers from the inside BEFORE you stuff and close the loaf - the top closure is your last chance to reach inside.

Nose: a small pink triangle centred between and just below the eyes, with two short stitches angled down from the point for the mouth.

Whisker dots: three tiny black French knots on each side of the nose.

Chest & paws: with white yarn, embroider a soft oval on the chest and two small ovals at the front of the base for tucked paws - this is what turns a plain loaf into a cat.

Long, low and wide - the BLO ridge and tucked paws make the loaf read as a folded cat.

## Troubleshooting

- **It came out round.** You stopped increasing at Rnd 4 instead of Rnd 6, worked too many plain rounds at Rnds 8-9, or used a magic-ring base instead of the oval. The base must reach 48 stitches.
- **Tall and narrow.** The base did not reach 48. Count the stitches at Rnd 6 before the BLO round - that one number decides the whole shape.
- **Ears lean back.** Join the yarn one round lower and angle the first row slightly forward.
- **Tail falls off.** The first 4 sc must go through the body fabric under a whole stitch, not just one loop.
- **Stuffing shows.** Go down to a 3.0 mm hook - loose gauge on 3.5 mm is the usual cause.
- **Face looks like a bear.** Eyes too high and too close. Drop them a round and widen to 7 stitches.

## Colourways

Grey tabby  ·  Orange ginger  ·  Cream  ·  Black  ·  Calico

## Designer notes

- Grey tabby, orange ginger, cream, black, and calico (grey base with ginger and cream patches embroidered on afterwards). Listing all five as photos in one listing outperforms separate listings - buyers choose a cat, not a pattern.

## Care

Follow the labels for every yarn and component used. Before publishing a care claim or supplying finished Momos, clean and dry a complete sample by the proposed method, then remeasure it and inspect for dye transfer, fibre change, stuffing migration, shifted eyes and loosened surface-worked ears or tail. Until that sample test passes, recommend gentle surface cleaning with a damp cloth and drying flat away from heat. Check all facial components and yarn anchors again after cleaning.

## Terms of Use

### Copyright & ownership

This crochet pattern - including all instructions, stitch counts, editorial layout and design elements - is the original work and intellectual property of Novality Crochet Studio. Design Code NS 06.

© 2026 Novality Crochet Studio. All rights reserved.

This pattern is for personal use only. You may sell finished items made from this pattern, but you may not copy, redistribute, resell, share, translate, reproduce, or claim this pattern as your own. The pattern itself may not be uploaded, reproduced, or distributed in digital or printed form without permission from Novality Crochet Studio.

### You may

Make as many finished Momos as you like for yourself, gifts, or charity. Sell physical finished items made from this pattern in small batches, in shops, markets and online, provided credit is given to “Novality Crochet Studio”.

### You may not

Do not resell, share, redistribute, translate, rewrite, publish or upload this digital PDF or its contents in any form. Do not alter, copy or recolor the pattern and claim it as your own. Do not use the Novality Crochet Studio name, logo or photos beyond crediting the pattern. Do not mass-produce finished items commercially without written permission.

### Safety reminder

Not tested to a toy-safety standard (ASTM F963 / EN 71) and uses 8 mm safety eyes. Finished items sold for children must be assessed against local toy-safety laws; for young children, embroider the eyes and secure every end.

## Happy crocheting!

Tag your makes with **#NovalityCrochetStudio** and **#MomoTheLoafCat** - We love seeing your loaves. Thank you for supporting an independent pattern designer.
